from distutils.core import setup
import py2exe
import sys
sys.path.append(".\\modules")
setup(
    windows = [
        {
            "script": "RWDecal Reset.py",
            "icon_resources": [(0, "rwdecal.ico")]
        }
    ],
    options =
        {
            "py2exe": { "dll_excludes": ["POWRPROF.dll"]}
        }
    )
