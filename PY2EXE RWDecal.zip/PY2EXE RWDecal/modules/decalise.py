import threading
import pythoncom
import datetime
import win32com.client
import win32gui
import win32con
import win32com.client
import win32api
import copy # copy variables / objects
import time
import math
import Image # image manipulation
import ImageGrab  # Part of PIL
import os
import subprocess # calling other programs
import _subprocess
import urllib # update checking etc
import urllib2 # update checking etc
import shutil # file operations
import sys
import codecs
import traceback

#sys.path.append(".\\modules") # needed for python to find our custom modules
from ltm_to_utm import calc_rotation # rotation calculations

class make_decal(threading.Thread):
    def __init__(self,parent,do_bulk, version):
        self.parent = parent
        self.do_bulk = do_bulk
        self.version = version
    
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= _subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = _subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def check_for_cancel(self): # check if cancel has been clicked
        if self.parent.cancel_clicked == True : # if files exists break loop
            try:
                #self.parent.cancel_button.Enable(False)
                #if eval(self.parent.config["DELETE_TEMP_FILES"]) == True and os.path.exists(".\\temp\\") == True:
                #    os.system('rd .\\temp /S /Q') # Delete temp folder
            
                self.parent.lock_form("unlock")
                self.parent.main_window_status.SetLabel("Ready")
                
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
                if self.parent.rw_status_window:
                    self.parent.rw_status_window.Close(True)
                return True
            except:
                return True
            
        return False

    def check_camera_pos(self,alt,lat,lon, max_coord_deviation = 0.0001, log = True):
        try:
            win32gui.SetForegroundWindow(self.ge_window)
        except:
            pass
        if log == True:
            self.parent.log_output("Checking camera position .  .  .",
                                   self.parent.lang["log_cameraposition"])
        i = 0
        while True: # make sure camera is where it is meant to be
            i += 1
            if self.check_for_cancel():
                return False
            camera_pos = self.ge.GetCamera(True)
            # check if camera deviates from required pos by more than allowed margin
            if (camera_pos.Range < float(alt) - (float(alt) * max_coord_deviation) or camera_pos.Range > float(alt) + (float(alt) * max_coord_deviation)) or (lat - camera_pos.FocusPointLatitude > max_coord_deviation or camera_pos.FocusPointLatitude - lat > max_coord_deviation) or (lon - camera_pos.FocusPointLongitude > max_coord_deviation or camera_pos.FocusPointLongitude - lon > max_coord_deviation) :
                time.sleep(0.1)
                if i == 25 / self.speed: #camera not in right place and tried 50 times so force move to see if it fixes it
                    i = 0
                    self.ge.SetCameraParams (lat, lon, alt, 2, self.focus_distance, self.tilt, self.azimuth, self.speed)
                new_camera_pos = self.ge.GetCamera(True)
                # check if camera is stationary. If it is then set new camera location as camera not moving but still not in right place
                if new_camera_pos.Range == camera_pos.Range and new_camera_pos.FocusPointLatitude == camera_pos.FocusPointLatitude and new_camera_pos.FocusPointLongitude == camera_pos.FocusPointLongitude:
                    if i == 25 / self.speed: #camera not moving and can;t get to right position so change altitude to force movement
                        i = 0
                        self.ge.SetCameraParams (lat + 0.01, lon + 0.01, alt + 200, 2, self.focus_distance, self.tilt, self.azimuth, self.speed)
                    else:
                        self.ge.SetCameraParams (lat, lon, alt, self.alt_mode, self.focus_distance, self.tilt, self.azimuth, self.speed)
            else:
                if int(self.speed) == 5:
                    time.sleep(0.1)
                break
        return True

    def check_render_move(self,render_position):
        if self.parent.cancel_clicked == True:
            return False
        render_position_new = win32gui.GetWindowRect(self.render)
        if render_position_new != render_position:
            # make GEWindow minimized so we can see message
            win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
            self.parent.error_handler(self.parent.lang["message_gemove"], self.parent.lang["message_gemove_title"])
            self.parent.cancel_clicked = True
            if self.check_for_cancel():
                return False
        return True

    def check_stream_data(self):
        self.parent.log_output("Waiting for Google Earth to stream data .  .  .",
                               self.parent.lang["log_streamdata"])
        while self.ge.StreamingProgressPercentage < 100:
            if self.check_for_cancel():
                return False
            time.sleep(0.1)
        time.sleep(float(self.parent.config["GE_STREAM_DELAY"]))
        return True

    def crop(self, image, last_tile_lr, tile_width_height, capture_dimensions): # crop image to correct size
        full_map_dimensions = image.getbbox()
        
        # how much more long/lat is this than needed
        extra_lon = last_tile_lr.Longitude - float(self.form_settings["UR_LON"])
        extra_lat = float(self.form_settings["LL_LAT"]) - last_tile_lr.Latitude

        # calculate number of exta px this equates to
        x_pix_crop = (capture_dimensions[2] / tile_width_height[0]) * extra_lon
        y_pix_crop = (capture_dimensions[3] / tile_width_height[1]) * extra_lat

        # create crop box
        crop_box = [0, 0, int(round(full_map_dimensions[2] - x_pix_crop,0)), int(round(full_map_dimensions[3] - y_pix_crop,0))]

        # crop image
        image = image.crop(crop_box)

        if self.check_for_cancel():
            return False

        return image

    def resize(self, image): # resize image ready for ace conversion
        border = 1
        image_dimensions = image.getbbox()
        try:
            if(image_dimensions[2] >= 3072 or image_dimensions[3] >= 3072 ):
                resize_value = 4096
            elif(image_dimensions[2] >= 1536 or image_dimensions[3] >= 1536 ):
                resize_value = 2048
            elif(image_dimensions[2] >= 768 or image_dimensions[3] >= 768 ):
                resize_value = 1024
            else:
                resize_value = 512
        except:
            resize_value = 1024

        # restrict decal to limited size if exceeded
        if resize_value > int(self.parent.config["DECAL_QUALITY"]):
            resize_value = int(self.parent.config["DECAL_QUALITY"])
            
        self.x_rotate_scale_factor = (1/float(resize_value - (border*2))) * float(resize_value) # increase scale factor to take into account 6px border (3 each side)
        self.y_rotate_scale_factor = (1/float(resize_value - (border*2))) * float(resize_value) # increase scale factor to take into account 6px border (3 each side)


        # resize image to 1 pixels less than size we require
        if eval(self.parent.config["ANTIALIAS_DECALS"]) == True:
            image = image.resize((resize_value - (border*2),resize_value - (border*2)),Image.ANTIALIAS)
        else:
            image = image.resize((resize_value - (border*2),resize_value - (border*2)),Image.NEAREST)

        #if eval(self.form_settings["TRANSPARENCY"]) != False:
        #    image = self.transparency(image)
            
        # create a new image that is the correct size
        new_image = Image.new("RGBA", (resize_value,resize_value))

        # paste the image into the new image with the 3px border
        new_image.paste(image, (border, border))

        if self.check_for_cancel():
            return False

        return new_image

##    def transparency(self,image):
##        trans_freq = 4
##        image_dimensions = image.getbbox() # source image size
##        
##        # alpha image
##        alpha = Image.new("RGBA",(image_dimensions[2],image_dimensions[3]),)
##        
##        # chess board mask
##        # controls trans block size
##        # by dividing the mask and then scaleing to write size later we can get 1x1, 2x2 3x3 transparent pixel blocks etc
##        mask = Image.new("1", (image_dimensions[2],image_dimensions[3]), (255))
##
##        mask_checker = list() # define mask list
##        opaque_count = trans_freq # set initial opaque pixel count
##        col_start_opaque_count = trans_freq # set first row value to mask value
##        row = 1 # set start row number
##        for pixel in range(1, image_dimensions[2] * image_dimensions[3]): # loop through number of chunks on x axis
##            # 255 is opaque, 0 is transparent
##            if trans_freq == opaque_count:
##                mask_value = 0
##                opaque_count = 0
##            else:
##                mask_value = 255
##                opaque_count += 1 # increment opaque count
##
##            mask_checker.append(mask_value)
##            if row == image_dimensions[2]: # got to end of column
##                col_start_opaque_count += 1 # increment column start by 1
##                if col_start_opaque_count > trans_freq: # if execeeded trans frequency then go back to 0
##                    col_start_opaque_count = 0
##                    
##                opaque_count = col_start_opaque_count # set mask value to row start for first item in column
##                row = 0 # reset row value
##                
##            row += 1
##                
##        mask.putdata(mask_checker)
##
##        image = Image.composite(image, alpha, mask)
##        return image
    
## old variable trans not supported in RailWorks
##    def transparency(self, image, percent): # add partial transparency
##        return image
##        #if image.mode != 'RGBA':
##        #    image = image.convert('RGBA')
##        #image_dimensions = image.getbbox()
##        # crop image
##        #image = image.crop(image_dimensions)
##        #image_dimensions = image.getbbox()
##        
##        # resize alpha and mask to same size as rotated image
##        #alpha = Image.new("RGBA",(image_dimensions[2],image_dimensions[3]),)
##        # create mask same size as orignal
##        # 255 is opaque
##        # 0 is transparent
##
##        trans = int(round(255 / 100.0 * float(percent),0))
##        image.putalpha(trans)
##        #mask = Image.new("L", (image_dimensions[2],image_dimensions[3]), (255))
##        #image = Image.composite(image, alpha, mask)
##        return image
        
    def rotate_image(self, image, name):  # used to correct differences in Google Earth and Railworks interpretation of due north
        self.parent.log_output("Rotating " + name + " by " + str(self.form_settings["DUE_NORTH_FIX_DEGREES"]) + " degrees .  .  .",
                               self.parent.lang["log_decalrotate"].replace("~~name~~",name).replace("~~rotation~~",str(self.form_settings["DUE_NORTH_FIX_DEGREES"])))

        # rotate image
        orig_dimensions = image.getbbox()
        #if eval(self.parent.config["ANTIALIAS_DECALS"]) == True:
        image = image.rotate(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]),Image.BICUBIC,1) # also could do BILINEAR or BICUBIC
        #else:
        #    image = image.rotate(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]),Image.NEAREST,1) # also could do BILINEAR or BICUBIC
        new_dimensions = image.getbbox()
        
        # add transparency over black sections
        if image.mode != 'RGBA':
           image = image.convert('RGBA')

        # resize alpha and mask to same size as rotated image
        alpha = Image.new("RGBA",(new_dimensions[2],new_dimensions[3]),)

        # create mask same size as orignal
        mask = Image.new("1", (orig_dimensions[2],orig_dimensions[3]), (255))
        # rotate mask to create angleed corners same as original
        if eval(self.parent.config["ANTIALIAS_DECALS"]) == True:
            mask = mask.rotate(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]),Image.BICUBIC,1) # also could do BILINEAR or BICUBIC 
        else:
            mask = mask.rotate(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]),Image.NEAREST,1) # also could do BILINEAR or BICUBIC
            
        # create composite of image, alpha and mask
        try:
            image = Image.composite(image, alpha, mask)
        except:
            self.parent.error_handler(self.parent.lang["message_rotationfailed"],
                                      self.parent.lang["message_rotationfailed_status"])
            return False
            
        image = image.crop(image.getbbox())

        # calculate how much x and y dimensions have changed by
        #self.x_rotate_scale_factor = new_dimensions[2] / float(orig_dimensions[2])
        #self.y_rotate_scale_factor = new_dimensions[3] / float(orig_dimensions[3])

        if self.check_for_cancel():
            return False
        return image
        #im2.save(image_path)

##    def track_file_item(self,track,file_path):
##        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + track + ".dat")
##         
##        tracker = codecs.open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + track + ".dat", encoding="UTF-8", mode='a') #open for append
##        tracker.write(file_path + "\r\n")
##        tracker.close()

    def convert_to_ace(self,chunks = False, single = False):
        start_time = datetime.datetime.now()
        
        ace_path = self.parent.config["RAILWORKS_PATH"] + "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\"
        if single != False:
            if chunks == False:
                chunks = list()
            chunks.append(single)
            
        i = 1
        for chunk in chunks:
            if self.check_for_cancel():
                return False
            if single != False and i == len(chunks):
                self.parent.log_output("Converting full decal to ACE using RWAceTool by Ben Laws .  .  .",
                                       self.parent.lang["log_acefull"])
            else:
                self.parent.log_output("Converting chunk " + str(i) + " of " + str(len(chunks)) + " to ACE using RWAceTool by Ben Laws .  .  .",
                                       self.parent.lang["log_acechunk"].replace("~~amount~~",str(i)).replace("~~amount_of~~",str(len(chunks))))

            subprocess.call([self.parent.config["RW_ACE_PATH"],
                             chunk],
                             stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                            startupinfo=self.startupinfo)
            self.parent.check_path_exists(ace_path) # make sure path we need to copy ace into exists
            if os.path.exists(ace_path + os.path.basename(str(chunk.replace('.png','.ace')))):
                os.remove(ace_path + os.path.basename(str(chunk.replace('.png','.ace'))))
            shutil.move(str(chunk.replace('.png','.ace')),ace_path + os.path.basename(str(chunk.replace('.png','.ace'))))
            #os.system('move "' + str(chunk.replace('.png','.ace')) + '" "' + ace_path + '"') # move ace to correct path
            # track item generated
            #self.track_file_item("source_decals",ace_path + os.path.basename(str(chunk.replace('.png','.ace'))))
            i += 1
        end_time = datetime.datetime.now()
        self.ace_time_taken += end_time - start_time
        return True

    def check_license(self, image):
        # licensed so all good
        if self.parent.licensed == True:
            return image
        else:
            if self.altitude < 1000: # less than 1000 and not licensed so turn decal half black
                image_dimensions = image.getbbox() # dimensions of image
                black = Image.new("RGB",(image_dimensions[2],int(image_dimensions[3] / 2)),(1,1,1)) # create black image half height of decal, full width
                image.paste(black, (0, image_dimensions[3] - int(image_dimensions[3] / 2))) # past black onto chunk
                image_dimensions = image.getbbox()
            return image

    def chunk_image(self,image):
        start_time = datetime.datetime.now()
        full_map_dimensions = image.getbbox()
        
        chunk_path_list = list() # list for chunks
        blueprint_list = list() # list for blueprints

        # if we are using decal zoom feature we need to reduce the max decal size by the same factor
        if "decal_zoom" in self.parent.hidden_config and float(self.parent.hidden_config["decal_zoom"]) > 1.0:
            x_chunks = int(math.ceil(self.capture_area_dimensions[0] / (float(self.parent.config["MAX_DECAL_SIZE"]) / float(self.parent.hidden_config["decal_zoom"]))))
            y_chunks = int(math.ceil(self.capture_area_dimensions[1] / (float(self.parent.config["MAX_DECAL_SIZE"]) / float(self.parent.hidden_config["decal_zoom"]))))
        else:
            x_chunks = int(math.ceil(self.capture_area_dimensions[0] / float(self.parent.config["MAX_DECAL_SIZE"])))
            y_chunks = int(math.ceil(self.capture_area_dimensions[1] / float(self.parent.config["MAX_DECAL_SIZE"])))

        lon_part = (float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / float(x_chunks) # needed for auto rotate
        lat_part = (float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"])) / float(y_chunks) # needed for auto rotate

        # work out size of x and y for each decal so that we get even chunks
        decal_size_x_meters = self.capture_area_dimensions[0] / float(x_chunks)
        decal_size_y_meters = self.capture_area_dimensions[1] / float(y_chunks)
        decal_size_x_pixels = full_map_dimensions[2] / float(x_chunks)
        decal_size_y_pixels = full_map_dimensions[3] / float(y_chunks)

        # work out 1% overlap
        if eval(self.parent.config["CHUNK_OVERLAP"]): # overlap by 1%
            overlap_x = int(math.ceil(decal_size_x_pixels / 100.0 * 1.0)) # overlap pixels for single x edge
            overlap_y = int(math.ceil(decal_size_y_pixels / 100.0 * 1.0)) # overlap pixels for single y edge

            # workout what actual percent overlap we have (as it will not be exactly 1%)
            self.width_overlap_pc = (1.0 / float(decal_size_x_pixels)) * float(overlap_x) # overlap percent for single x edge
            self.height_overlap_pc = (1.0 / float(decal_size_y_pixels)) * float(overlap_y) # overlap percent for single y edge
        else:
            overlap_x = 0
            overlap_y = 0
            self.width_overlap_pc = 0.0
            self.height_overlap_pc = 0.0

        
        self.num_decals = x_chunks * y_chunks
        i = 1
        for y_chunk in range(1, y_chunks + 1): # loop through number of chunks on x axis
            upper = int(round(decal_size_y_pixels * float(y_chunk - 1),0)) # calc upper pixel position
            lower = int(min(round(decal_size_y_pixels * float(y_chunk),0), full_map_dimensions[3]))# calc lower pixel position

            total_height_overlap_pc = 1.0 # reset percentage increase
            if y_chunk > 1: # not first y so can extend upper
                upper -= overlap_y
                total_height_overlap_pc += self.height_overlap_pc # add percentage increase for upper
            if y_chunk != y_chunks: # not last y so can extend lower
                lower += overlap_y 
                total_height_overlap_pc += self.height_overlap_pc # add percentage increase for upper
                
            for x_chunk in range(1, x_chunks + 1): # loop through number of chunks on x axis
                self.prevent_scr()
                if self.check_for_cancel():
                    return False
                self.parent.log_output("Chunking decal. Processing " + str(i) + " of " + str(self.num_decals) + " .  .  .",
                                       self.parent.lang["log_chunking"].replace("~~amount~~", str(i)).replace("~~amount_of~~",str(self.num_decals)))

                left = int(round(decal_size_x_pixels * float(x_chunk - 1),0)) # calc left pixel position
                right = int(min(round(decal_size_x_pixels * float(x_chunk),0),full_map_dimensions[2])) # calc right ixel position

                total_width_overlap_pc = 1.0 # reset percentage increase
                if x_chunk > 1: # not first x so can extend left
                    left -= overlap_x
                    total_width_overlap_pc += self.width_overlap_pc # add percentage increase for left
                if x_chunk != x_chunks: # not last x so can extend right
                    right += overlap_x
                    total_width_overlap_pc += self.width_overlap_pc # add percentage increase for right
                
                coords = (float(self.form_settings["LL_LAT"]) + (lat_part * y_chunk) - (lat_part / 2.0),
                          float(self.form_settings["LL_LON"]) + (lon_part * x_chunk) - (lon_part / 2.0),
                          self.form_settings["UR_LAT"])

                box = [left, upper, right, lower] # crop box
                
                image_chunk = image.crop(box) # chunk image by cropping

                image_chunk = self.check_license(image_chunk) # add black half to image if not licensed
        
                m_width = decal_size_x_meters * total_width_overlap_pc
                m_height = decal_size_y_meters * total_height_overlap_pc

                # add transparency if wanted
                #if eval(self.form_settings["TRANSPARENCY"]) != False:
                    #image_chunk = self.transparency(image_chunk)
                    #image_chunk = self.transparency(image_chunk,int(self.form_settings["TRANSPARENCY"]))

                
                if eval(self.form_settings["DUE_NORTH_FIX"]) and (float(self.form_settings["DUE_NORTH_FIX_DEGREES"]) <> 0 or eval(self.form_settings["AUTO_ROTATE"])):
                    if eval(self.form_settings["AUTO_ROTATE"]): # using auto rotate feature so calc new rotation based on middle of decal
                        if eval(self.form_settings["AUTO_ROTATE_CHUNK_LOCK"]) == False: # not locking chunks so do chunk specific rotation
                            self.form_settings["DUE_NORTH_FIX_DEGREES"] = calc_rotation(coords[0],coords[1],coords[2],self.parent.route_start["LATITUDE"], self.parent.route_start["LONGITUDE"])
                        else: # recalc default as uses better accuracy
                            coords = (float(self.form_settings["LL_LAT"]) + ((float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"])) / 2.0),
                                      float(self.form_settings["LL_LON"]) + ((float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / 2.0),
                                      float(self.form_settings["UR_LAT"]))
                            self.form_settings["DUE_NORTH_FIX_DEGREES"] = calc_rotation(coords[0],coords[1],coords[2],self.parent.route_start["LATITUDE"], self.parent.route_start["LONGITUDE"])
                    
                    # update width and height to take rotation into account
                    m_width = abs((math.sin(math.radians(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]))) * m_height)) + abs((math.cos(math.radians(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]))) * m_width))
                    m_height = abs((math.cos(math.radians(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]))) * m_height)) + abs((math.sin(math.radians(float(self.form_settings["DUE_NORTH_FIX_DEGREES"]))) * m_width))

                    image_chunk = self.rotate_image(image_chunk,str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))))
                    if image_chunk == False:
                        return


                image_chunk = self.resize(image_chunk) # resize images ready for ace converson
                if image_chunk == False:
                    return False
                
                # update width and height to take alpha border into account
                
                m_width = m_width * self.x_rotate_scale_factor
                m_height = m_height * self.y_rotate_scale_factor

                # zoom in if value set in hidden config file
                if "decal_zoom" in self.parent.hidden_config and float(self.parent.hidden_config["decal_zoom"]) > 1.0:
                    m_width = round(m_width * float(self.parent.hidden_config["decal_zoom"]),2)
                    m_height = round(m_height * float(self.parent.hidden_config["decal_zoom"]),2)
                else:
                    m_width = round(m_width,2)
                    m_height = round(m_height,2)

                # calculate the path to save the chunk in
                chunk_path = self.parent.config["INSTALL_PATH"] + "\\temp\\chunks\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".png"

                chunk_path_list.append(chunk_path) # add this chunk to the list of chunks

                blueprint_list.append((str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))),(m_width, m_height)))# store width and height of this decal in a list for blueprint creation

                image_chunk.save(chunk_path)
                i +=1
        end_time = datetime.datetime.now()
        self.chunk_time_taken += end_time - start_time

        # convert chunks to ace
        if self.convert_to_ace(chunk_path_list) != True:
            return False

        # make blueprints for chunks
        if self.create_decal_blueprints(blueprint_list) != True:
            return False

        # export decal chunks
        if eval(self.form_settings["RAILWORKS_EXPORT"]):
            if self.export_decal_blueprints(blueprint_list) != True:
                return False
               
        return True

    def create_decal_blueprints(self, decal_list = False, decal_single = False):
        if decal_single != False:
            if decal_list == False:
                decal_list = list()
            decal_list.append(decal_single)
        blueprint_base = self.parent.config["RAILWORKS_PATH"] + \
                  "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + \
                  self.parent.config["PRODUCT"] + "\\" + \
                  self.parent.config["RW_DECALS_PATH"] + "\\"

        self.parent.check_path_exists(blueprint_base)

        for decal in decal_list:
            if self.check_for_cancel():
                return False
            blueprint_path =  blueprint_base + decal[0] + ".xml"
            
            template_blueprint = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\decal_blueprint.xml", encoding="UTF-8", mode="r") #open for read

            new_blueprint = codecs.open(blueprint_path, encoding="UTF-8", mode='w') #open for append
            for line in template_blueprint:
                line = line.replace("~~NAME~~", "GE: " + decal[0])
                line = line.replace("~~WIDTH~~", str(round(decal[1][0],2)))
                line = line.replace("~~HEIGHT~~", str(round(decal[1][1],2)))
                line = line.replace("~~ACE~~", 'aces\\' + decal[0] + ".ace")
                new_blueprint.write(line)
            template_blueprint.close()
                       
            # track item generated
            #self.track_file_item("source_decals",blueprint_path)
                       
            new_blueprint.close()
        self.parent.log_output("Created decal blueprints",
                               self.parent.lang["log_createdecalbp"])
        return True

    def export_decal_blueprints(self, decal_list = False, decal_single = False):
        start_time = datetime.datetime.now()
        if decal_single != False:
            if decal_list == False:
                decal_list = list()
            decal_list.append(decal_single)

        # work out base location for export
        blueprint_base = self.parent.config["RAILWORKS_PATH"] + \
                  "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + \
                  self.parent.config["PRODUCT"] + "\\" + \
                  self.parent.config["RW_DECALS_PATH"] + "\\"

        # make sure paths exist
        self.parent.check_path_exists(blueprint_base + "\\aces\\")

        i = 1
        # loop through each decal doing export
        for decal in decal_list:
            if self.check_for_cancel():
                return False
            self.parent.log_output("Exporting decal blueprints. Processing " + str(i) + " of " + str(len(decal_list)) + " .  .  .",
                                   self.parent.lang["log_exportingdecalbp"].replace("~~amount~~", str(i)).replace("~~amount_of~~", str(len(decal_list))))

            # create path to blueprint
            blueprint_path_export =  blueprint_base + decal[0] + ".xml"
            new_blueprint_export = codecs.open(blueprint_path_export, encoding="UTF-8", mode='w') #open for write

            # open template and parse it replacing relevent lines
            template_blueprint_export = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\decal_blueprint_export.xml",encoding="UTF-8", mode="r") #open for read
            for line in template_blueprint_export:
                line = line.replace("~~NAME~~", "GE: " + decal[0])
                line = line.replace("~~WIDTH~~", str(round(decal[1][0],2)))
                line = line.replace("~~HEIGHT~~", str(round(decal[1][1],2)))
                line = line.replace("~~ACE~~", self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\[00]" + decal[0])
                new_blueprint_export.write(line)

            # finished so close template and save new blueprint
            template_blueprint_export.close()
            new_blueprint_export.close()

            # track item generated
            #self.track_file_item("assets_decals",blueprint_path_export)

            # now we have exported the blueprint lets export the acet
            #print self.parent.config["RAILWORKS_PATH"] + "\\ConvertToTG.exe -i " + blueprint_base.replace("\\Assets\\","\\Source\\") + "aces\\" + decal[0] + ".ace -o " + blueprint_base + "aces\\" + decal[0] + ".ace -target pc -forcecompress -costXML " + blueprint_base + "aces\\" + decal[0] + ".ace.cost -r " + self.parent.config["RAILWORKS_PATH"] + "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"]
            # original command below before RW3
            # after RW 3 for what ever reason extra space required after -target pc and -forcecompres
            # WTF?
##            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\ConvertToTG.exe",
##                             "-i",
##                             blueprint_base.replace("\\Assets\\","\\Source\\") + "aces\\" + decal[0] + ".ace",
##                             "-o",
##                             blueprint_base + "aces\\" + decal[0] + ".ace",
##                             "-target",
##                             "pc",
##                             "-forcecompress",
##                             "-costXML",
##                             blueprint_base + "aces\\" + decal[0] + ".ace.cost",
##                             "-r",
##                             self.parent.config["RAILWORKS_PATH"] + "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"]],
##                             stdout=codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log", encoding="UTF-8", mode="w"),
##                             startupinfo=self.startupinfo)
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\ConvertToTG.exe",
                             "-i",
                             blueprint_base.replace("\\Assets\\","\\Source\\") + "aces\\" + decal[0] + ".ace",
                             "-o",
                             blueprint_base + "aces\\" + decal[0] + ".ace",
                             "-target pc ",
                             "-forcecompress ",
                             "-costXML",
                             blueprint_base + "aces\\" + decal[0] + ".ace.cost",
                             "-r",
                             self.parent.config["RAILWORKS_PATH"] + "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"]],
                             stdout=codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log", encoding="UTF-8", mode="w"),
                             startupinfo=self.startupinfo)

            # delete cost file
            if os.path.exists(blueprint_base + "aces\\" + decal[0] + ".ace.cost") == True:
                os.remove(blueprint_base + "aces\\" + decal[0] + ".ace.cost");


            # track items generated
            #self.track_file_item("assets_decals",blueprint_base + "aces\\" + decal[0] + ".TgPcDx")

            # and export the xml
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\Serz.exe",
                             blueprint_path_export,
                             "/bin:" + blueprint_path_export.replace(".xml",".bin")],
                             stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                            startupinfo=self.startupinfo)

            # delete xml file from assets folder as not needed
            if os.path.exists(blueprint_base + "\\" + decal[0] + ".xml") == True:
                os.remove(blueprint_base + "\\" + decal[0] + ".xml");

            # track item generated
            #self.track_file_item("assets_decals",blueprint_path_export.replace(".xml",".bin"))

            if eval(self.form_settings["DELETE_BLUEPRINTS"]):
                os.remove(blueprint_base.replace("\\Assets\\","\\Source\\") + "aces\\" + decal[0] + ".ace")
                os.remove(blueprint_path_export.replace("\\Assets\\","\\Source\\"))
                self.parent.log_output("Deleted decal source data",
                                       self.parent.lang["log_deletedecalbp"])

            i +=1

        if self.check_for_cancel():
            return False

        end_time = datetime.datetime.now()
        self.export_time_taken += end_time - start_time
        return True

    def create_marker_blueprint(self):
        blueprint_base = self.parent.config["RAILWORKS_PATH"] + \
                  "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + \
                  self.parent.config["PRODUCT"] + "\\" + \
                  self.parent.config["RW_MARKERS_PATH"] + "\\"
        blueprint_path = blueprint_base + self.form_settings["DECAL_NAME"] + ".xml"

        self.parent.check_path_exists(blueprint_base + "\\csv\\") # make sure path exists

        # create csv file for markers
        corners = self.create_markers_list()
        csv_file = codecs.open(blueprint_base + "csv\\" + self.form_settings["DECAL_NAME"] + ".csv", encoding="UTF-8", mode="w")
        for corner in corners:
            csv_file.write(str(corner[0]) + "," + str(corner[1]) + "," + corner[2] + "\n")
        csv_file.close()

        # track item generated
        #self.track_file_item("source_markers",blueprint_base + "csv\\" + self.form_settings["DECAL_NAME"] + ".csv")

        # create markers
        template_blueprint = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\marker_blueprint.xml", encoding="UTF-8", mode="r") #open for append
        new_blueprint = codecs.open(blueprint_path, encoding="UTF-8", mode='w') #open for append
        for line in template_blueprint:
            line = line.replace("~~NAME~~","GE: " + self.form_settings["DECAL_NAME"])
            line = line.replace("~~CSVFILE~~", self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.form_settings["DECAL_NAME"] + ".csv")
            new_blueprint.write(line)
        template_blueprint.close()
        new_blueprint.close

        # track item generated
        #self.track_file_item("source_markers",blueprint_path)

        if self.check_for_cancel():
            return False
        self.parent.log_output("Created marker blueprint",
                               self.parent.lang["log_createmarkerbp"])
        return True

    def export_marker_blueprint(self):
        self.parent.log_output("Exporting markers blueprint",
                               self.parent.lang["log_exportmarkerbp"])
        blueprint_base = self.parent.config["RAILWORKS_PATH"] + \
                  "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + \
                  self.parent.config["PRODUCT"] + "\\" + \
                  self.parent.config["RW_MARKERS_PATH"] + "\\"
        dcsv_path = blueprint_base + "csv\\" + self.form_settings["DECAL_NAME"] + ".dcsv"

        self.parent.check_path_exists(blueprint_base + "\\csv\\") # make sure temp folder for chunks exists

        # create csv array for markers
        corners = self.create_markers_list()

        # create dcsv
        new_dcsv = codecs.open(dcsv_path, encoding="UTF-8", mode='w') #open for append

        # add dcsv header
        new_dcsv.write(codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\\dcsv_header.xml", encoding="UTF-8", mode="r").read())
        
        # add each corner
        id_num = 0
        for corner in corners:
            default_dcsv_body = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\\dcsv_body.xml", encoding="UTF-8", mode="r")
            for line in default_dcsv_body:
                line = line.replace("~~LNG~~",str(corner[0]))
                line = line.replace("~~LAT~~",str(corner[1]))
                line = line.replace("~~NAME~~",corner[2])
                line = line.replace("~~ID~~",str(id_num).zfill(3))
                new_dcsv.write(line)
            default_dcsv_body.close()
            id_num += 12

        # add dcsv footer
        new_dcsv.write(codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\\dcsv_footer.xml", encoding="UTF-8", mode="r").read())

        # finished so close dcsv
        new_dcsv.close

        # track item generated
        #self.track_file_item("assets_markers",dcsv_path)

        # create exported blueprint for dcsv
        template_blueprint_export= codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\railworks\\marker_blueprint_export.xml", encoding="UTF-8", mode="r")      
        blueprint_path_export = blueprint_base + self.form_settings["DECAL_NAME"] + ".xml"
            
        new_blueprint_export = codecs.open(blueprint_path_export, encoding="UTF-8", mode='w') #open for writing
        for line in template_blueprint_export:
            line = line.replace("~~NAME~~","GE: " + self.form_settings["DECAL_NAME"])
            line = line.replace("~~CSVFILE~~",self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.form_settings["DECAL_NAME"])
            new_blueprint_export.write(line)

        # finsished creating XML export so close template and new xml
        template_blueprint_export.close()
        new_blueprint_export.close()

        # track item generated
        #self.track_file_item("assets_markers",blueprint_path_export)

        # export xml to bin
        subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\Serz.exe",
                         blueprint_path_export,
                         "/bin:" + blueprint_path_export.replace(".xml",".bin")],
                         stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                        startupinfo=self.startupinfo)

        # track item generated
        #self.track_file_item("assets_markers",blueprint_path_export.replace(".xml",".bin"))

        # delete xml file
        if os.path.exists(blueprint_base + "\\" + self.form_settings["DECAL_NAME"] + ".xml") == True:
            os.remove(blueprint_base + "\\" + self.form_settings["DECAL_NAME"] + ".xml");
            
        if eval(self.form_settings["DELETE_BLUEPRINTS"]):
            os.remove(blueprint_base.replace("\\Assets\\","\\Source\\") + "csv\\" +  self.form_settings["DECAL_NAME"] + ".csv")
            os.remove(blueprint_base.replace("\\Assets\\","\\Source\\") + self.form_settings["DECAL_NAME"] + ".xml")
            self.parent.log_output("Deleted marker source data",
                                   self.parent.lang["log_deletemarkerbp"])

        if self.check_for_cancel():
            return False
        
        return True

    def create_markers_list(self):
        # create csv array for markers
        corners = list()

        # work out how many chunks x and y we have
        x_chunks = int(math.ceil(self.capture_area_dimensions[0] / float(self.parent.config["MAX_DECAL_SIZE"])))
        y_chunks = int(math.ceil(self.capture_area_dimensions[1] / float(self.parent.config["MAX_DECAL_SIZE"])))

        num_markers_full = 0
        if int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 1: # full corners
            num_markers_full = 4
        elif int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 2: # full center 
            num_markers_full = 1
        elif int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 3: # Full & Center
            num_markers_full = 5

        num_markers_chunks = 0
        if int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) == 1: # chunk corners
            num_markers_chunks = 4
        elif int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) == 2: # full center 
            num_markers_chunks = 1
        elif int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) == 3: # Full & Center
            num_markers_chunks = 5

        if int(self.form_settings["CHUNK_CHOICE"]) == 0: # making chunks
            num_decals = x_chunks * y_chunks
            num_markers = x_chunks * y_chunks * num_markers_chunks + num_markers_full
        elif int(self.form_settings["CHUNK_CHOICE"]) == 1: # Full Only
            num_decals = 1
            num_markers = num_markers_full
        elif int(self.form_settings["CHUNK_CHOICE"]) == 2: # Full & Chunks Only
            num_decals = x_chunks * y_chunks + 1
            num_markers = x_chunks * y_chunks * num_markers_chunks + num_markers_full

        zeros_chunks = len(str(num_decals)) # number of zeros for chunks
        zeros_markers = len(str(num_markers)) # number of zeros for markers


        # do full first of all
        i = 0
        if int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 1 or int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 3: # create corner marker
            corners.append((self.form_settings["LL_LON"], self.form_settings["UR_LAT"], " " + str(i + 1).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " " + self.parent.lang["ul"]))
            corners.append((self.form_settings["UR_LON"], self.form_settings["UR_LAT"], " " + str(i + 2).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " " + self.parent.lang["ur"]))
            corners.append((self.form_settings["UR_LON"], self.form_settings["LL_LAT"], " " + str(i + 3).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " " + self.parent.lang["lr"]))
            corners.append((self.form_settings["LL_LON"], self.form_settings["LL_LAT"], " " + str(i + 4).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " " + self.parent.lang["ll"]))
            i = 4
            
        if int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) >= 2: # create center marker
            corners.append(((float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / 2.0 + float(self.form_settings["LL_LON"]),
                            (float(self.form_settings["LL_LAT"]) - float(self.form_settings["UR_LAT"])) / 2.0 + float(self.form_settings["UR_LAT"]),
                            " " + str(i + 1).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " " + self.parent.lang["c"]))
            if int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) == 3:
                i = 5
            else:
                i = 1

        # create chunk markers if we are asked to and there is more than 1 chunk
        if int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) >= 1:
            lon_part = (float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / float(x_chunks)
            lat_part = (float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"])) / float(y_chunks)

            # work out how much to moive markers by to handle overlap
            if eval(self.parent.config["CHUNK_OVERLAP"]):
                lon_overlap = lon_part * (self.width_overlap_pc) # overlap for single x edge
                lat_overlap = lat_part * (self.height_overlap_pc) # overlap for single y edge
            else:
                lon_overlap = 0.0
                lat_overlap = 0.0

            for x_chunk in range(1, x_chunks + 1): # loop through number of chunks on y axis
                left = float(self.form_settings["LL_LON"]) + (lon_part * float(x_chunk - 1)) - lon_overlap # calc left position
                    
                # anchor left to left of full decal
                if left < float(self.form_settings["LL_LON"]):
                    left = float(self.form_settings["LL_LON"])

                right = float(self.form_settings["LL_LON"]) + (lon_part * float(x_chunk)) + lon_overlap # calc right position
                # anchor right to right of full decal
                if right > float(self.form_settings["UR_LON"]):
                    right = float(self.form_settings["UR_LON"])

                x_center = (right - left) / 2.0 + left # get center x

                for y_chunk in range(1, y_chunks + 1): # loop through number of chunks on x axis
                    upper = float(self.form_settings["UR_LAT"]) - (lat_part * float(y_chunk - 1)) + lat_overlap # calc upper position
                    # anchor upper to upper of full decal
                    if upper > float(self.form_settings["UR_LAT"]):
                        upper = float(self.form_settings["UR_LAT"])

                    lower = float(self.form_settings["UR_LAT"]) - (lat_part * float(y_chunk)) - lat_overlap  # calc lower position
                    # anchor lower to lower of full decal
                    if lower < float(self.form_settings["LL_LAT"]):
                        lower = float(self.form_settings["LL_LAT"])

                    y_center = (lower - upper) / 2.0 + upper # get center y

                    if int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) == 1 or int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) == 3: # create corner markers
                        corners.append((left, upper, " " + str(i + 1).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " X" + str(x_chunk).zfill(len(str(x_chunks))) + " Y" + str(y_chunk).zfill(len(str(y_chunks))) + " " + self.parent.lang["ul"]))
                        corners.append((right, upper,  " " + str(i + 2).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " X" + str(x_chunk).zfill(len(str(x_chunks))) + " Y" + str(y_chunk).zfill(len(str(y_chunks))) + " " + self.parent.lang["ur"]))
                        corners.append((right, lower, " " + str(i + 3).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " X" + str(x_chunk).zfill(len(str(x_chunks))) + " Y" + str(y_chunk).zfill(len(str(y_chunks))) + " " + self.parent.lang["lr"]))
                        corners.append((left, lower, " " + str(i + 4).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " X" + str(x_chunk).zfill(len(str(x_chunks))) + " Y" + str(y_chunk).zfill(len(str(y_chunks))) + " " + self.parent.lang["ll"]))
                        i += 4

                    if int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) >= 2: # create center marker
                        corners.append((x_center, y_center, " " + str(i + 1).zfill(zeros_markers) + " " + self.form_settings["DECAL_NAME"] + " X" + str(x_chunk).zfill(len(str(x_chunks))) + " Y" + str(y_chunk).zfill(len(str(y_chunks))) + " " + self.parent.lang["c"]))
                        i += 1
        return corners
                    
        
    def configure_layers(self):
        # disable new GE Terrain option
        try:
            self.ge.ElevationExaggeration = float(0)
        except:
            pass
        configured = False
        while configured == False:
            if self.check_for_cancel():
                return False
            try:
                primary_database = self.ge.GetLayersDatabases()
                for features in primary_database:
                    layers = features.GetChildren()
                    for layer in layers:
                        if self.check_for_cancel():
                            return False
                        if eval(self.parent.config["DISABLE_ALL_GE_LAYERS"]) == True or layer.name == "Terrain" or layer.name == "3D Buildings":
                            layer.Visibility = False
                configured = True
            except:
                pass
        return True

    def disable_places(self,place):
        try:
            places = place.GetChildren()
            for item in places:
                try:
                    if self.places_callback(item):
                        return True
                    item.Visibility = False
                except:
                    item.Visibility = False
        except:
            item.Visibility = False
        return True

    def prevent_scr(self):
        win32api.keybd_event(win32con.VK_SCROLL, 0, 0, 0)
        win32api.keybd_event(win32con.VK_SCROLL, 0, win32con.KEYEVENTF_KEYUP, 0)
    
    def run(self):
        #try:
            if eval(self.parent.config["FIRST_USE"]) and self.parent.calibrate != True: # first use warning
                self.parent.error_handler(self.parent.lang["message_firstgerun"],
                                          self.parent.lang["message_firstgerun_title"])
                self.parent.config["FIRST_USE"] = "False"
                self.parent.save_config()
            
            pythoncom.CoInitialize()
            
           
            
            self.ge = win32com.client.Dispatch("GoogleEarth.ApplicationGE")
            self.parent.log_output("Google Earth initialising .  .  .",
                                   self.parent.lang["log_geinitialise"])
            self.focus_distance=0 # If not=0 camera will move backward from "range meters along the camera axis 
            self.alt_mode=1 #Altitude mode that defines altitude reference origin (1=above ground, 2=absolute)
            image_format="png" # jpg = lower quality but approx 9x smaller
            self.num_decals = 0 # reset number of decals
            self.calibrate_and_pass = False # no GE calibration unless detected we need to

            if self.do_bulk == False: # not doinf bulk so need to copy current form settings into array
                ge_placemarks = list()
                ge_placemarks.append(self.parent.form_settings["DECAL_NAME"])
            else:
                ge_placemarks = copy.copy(self.parent.bulk_create_decals)

            area_count = 1
            for placemark in ge_placemarks:
                start_time = datetime.datetime.now()
                # setup time trackers
                gather_time_taken = datetime.timedelta()
                self.chunk_time_taken = datetime.timedelta()
                self.ace_time_taken = datetime.timedelta()
                self.export_time_taken = datetime.timedelta()
                
                self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\full\\") # make sure temp folder for stitch exists
                self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\chunks\\") # make sure temp folder for chunks exists

                if self.do_bulk:
                    self.parent.marker_pairs_combo.SetStringSelection(placemark)# set the combo box to the marker
                    self.parent.evt_load_marker_pairs("",placemark) # load marker pairs
                
                self.form_settings = copy.copy(self.parent.form_settings) # transfer form settings into this fucntion so users can edit form and not affect decal creation
                #self.form_settings["TRANSPARENCY"] = "True"
                self.capture_area_dimensions = copy.copy(self.parent.capture_area_dimensions) # transfer form settings into this fucntion so users can edit form and not affect decal creation
                self.latitude = float(self.form_settings["UR_LAT"])
                self.longitude = float(self.form_settings["LL_LON"])
                if int(self.form_settings["ALTITUDE"]) > 19:
                    self.altitude = int(float(self.parent.altitude_options[int(self.form_settings["ALTITUDE"])].rstrip("km")) * 1000)
                else:
                    self.altitude = int(self.parent.altitude_options[int(self.form_settings["ALTITUDE"])].rstrip("m"))
                self.speed = int(self.form_settings["CAMERA_SPEED"]) + 1
                self.tilt=0 # looking to the horizon=90, looking to the center of Earth=0
                self.azimuth=0 # looking North=0, East=90, South=180, West=270

                while not self.ge.IsInitialized():
                    if self.check_for_cancel():
                        return
                    time.sleep(0.1)   

                self.render = self.ge.GetRenderHwnd()
                main = self.ge.GetMainHwnd()
                
                # set ge maximized and always on top
                self.ge_window = win32gui.FindWindow("QWidget","Google Earth")
                win32gui.ShowWindow(self.ge_window, win32con.SW_MAXIMIZE)
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOPMOST, 0,0,0,0,
                                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                rw_window = win32gui.FindWindow("wxWindowClassNR",self.parent.lang["status_window_title"])
                win32gui.SetWindowPos(rw_window, win32con.HWND_TOPMOST, 0,0,0,0,
                                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                self.parent.rw_status_window.Show(True)

                main_window_pos = win32gui.GetWindowRect(self.ge_window)

                # set googlearth to restored (window mode) and then position it slightly lower
                win32gui.ShowWindow(self.ge_window, win32con.SW_RESTORE)
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOP, 0,50,self.parent.screen_width,main_window_pos[3] + main_window_pos[1] - 50, win32con.SWP_FRAMECHANGED)

                # get size of the renbder area
                render_position = win32gui.GetWindowRect(self.render)
                render_width = render_position[2] - render_position[0]
                render_height = render_position[3] - render_position[1]

                # we need to allow approx 150 pixels from the height to prevent Google Branding so determine tile height based on render
                # area being greater than tiles size we want + 150
                if self.parent.config["REDUCED_CAPTURE"] != "1.0":
                    render_width_pix_adjust = int(round(render_width - (render_width * float(self.parent.config["REDUCED_CAPTURE"])),0)) + 5
                    render_height_pix_adjust = int(round(render_height - (render_height * float(self.parent.config["REDUCED_CAPTURE"])),0)) + 5
                else:
                    render_width_pix_adjust = 5
                    render_height_pix_adjust = 5
                pixel_per_google = 2 / float(render_width)
                # work out screen position in the way google needs it (-1 to 1) for size of tile we are using
                if self.parent.config["REDUCED_CAPTURE"] != "1.0": # avoiding nav
                    google_screen_cord_x = 2 * float(self.parent.config["REDUCED_CAPTURE"]) - 1 - pixel_per_google * 5.0
                    google_screen_cord_y = -2 * float(self.parent.config["REDUCED_CAPTURE"]) + 1 + pixel_per_google * 5.0
                else: # whole screen
                    google_screen_cord_x = 1 - pixel_per_google * 5.0
                    google_screen_cord_y = -1 + pixel_per_google * 5.0

                if self.configure_layers() != True:
                    return
                # check to see if render area changed at all If it has we must calibrate
                if self.parent.calibrate != True and (self.parent.config["GE_RENDER_DIMENSIONS"] != str(render_width) + "," + str(render_height) or len(self.parent.ge_calibration) != self.parent.num_calibrations):
                    time.sleep(2)
                    # make GEWindow minimized so we can see message
                    win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
                    
                    self.parent.error_handler(self.parent.lang["message_calibrategechange"],
                                              self.parent.lang["message_calibrategechange_title"])
                    self.calibrate_and_pass = True

                    # Restore GE Window
                    win32gui.ShowWindow(self.ge_window, win32con.SW_RESTORE)

                # calibratition cycle needs all above plus a loop through altitude
                if self.parent.calibrate == True or self.calibrate_and_pass == True:
                    if self.configure_layers() != True:
                        return
                    self.speed = 5
                    ge_calibration_data = codecs.open(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_calibration.dat", encoding="UTF-8", mode="w")
                    self.ge.SetCameraParams(52.793702, -2.550549, 1000, 2, 0, 0, 0, self.speed) # move camera to altitude area
                    time.sleep(2)
                    for altitude in self.parent.altitude_options: # loop through altitude
                        if self.configure_layers() != True:
                            return
                        if altitude.rstrip("km") != altitude.rstrip("m"):
                            altitude = int(float(altitude.rstrip("km")) * 1000) # get altitude
                        else:
                            altitude = int(altitude.rstrip("m")) # get altitude
                        if altitude > 1000:
                            altitude_text = str(altitude / 1000.0).replace(".0","") + "km"
                        else:
                            altitude_text = str(altitude) + "m"
                        self.parent.log_output("Calibrating at " + altitude_text.rstrip("m") + "m .  .  .",
                                               self.parent.lang["log_calibratealt"].replace("~~alt~~",altitude_text.rstrip("m")))
                        
                        self.ge.SetCameraParams(53.793702, -1.550549, altitude, self.alt_mode, 0, 0, 0, self.speed) # move camera to altitude area
                       
                        if self.check_camera_pos(altitude,53.793702,-1.550549,0.0001,False) != True:
                            return

                        # get ll and ur of rediced tile
                        calib_reduced_LL = self.ge.GetPointOnTerrainFromScreenCoords(-1 + pixel_per_google * 5.0,google_screen_cord_y)
                        calib_reduced_UR = self.ge.GetPointOnTerrainFromScreenCoords(google_screen_cord_x,1 - pixel_per_google * 5.0)

                        # vincenty
                        calib_width = self.parent.vinc_dist(calib_reduced_LL.Latitude,  calib_reduced_LL.Longitude,  calib_reduced_LL.Latitude,  calib_reduced_UR.Longitude )
                        calib_height = self.parent.vinc_dist(calib_reduced_LL.Latitude,  calib_reduced_LL.Longitude,  calib_reduced_UR.Latitude,  calib_reduced_LL.Longitude )

                        # haversine
                        #calib_width = self.parent.calc_seperation_in_meters(calib_reduced_LL.Latitude,  calib_reduced_LL.Longitude,  calib_reduced_LL.Latitude,  calib_reduced_UR.Longitude )
                        #calib_height = self.parent.calc_seperation_in_meters(calib_reduced_LL.Latitude,  calib_reduced_LL.Longitude,  calib_reduced_UR.Latitude,  calib_reduced_LL.Longitude )
                        
                            
                        ge_calibration_data.write(altitude_text + "=" + str(calib_width) + "," + str(calib_height) + "\r\n")

                        self.parent.ge_calibration[altitude_text] = str(calib_width) + "," + str(calib_height)

                        
                        time.sleep(0.2)
                        if self.check_for_cancel() == True:
                            return
                    
                    ge_calibration_data.close()

                    # store the dimensions of the render area so that detection of render area changes can be made
                    self.parent.config["GE_RENDER_DIMENSIONS"] = str(render_width) + "," + str(render_height)
                    self.parent.save_config()
                                              
                    # only stop if calibrate not triggered at start of a run
                    if self.parent.calibrate == True:
                        self.parent.cancel_clicked = True
                    
                    self.calibrate_and_pass = False

                    if self.check_for_cancel() == True:
                        return

                self.parent.log_output("Moving camera to start position .  .  .",
                                       self.parent.lang["log_camerastart"])
                if self.parent.calibrate != True:
                    self.ge.SetCameraParams (self.latitude, self.longitude, self.altitude, self.alt_mode, self.focus_distance, self.tilt, self.azimuth, self.speed)
                    if self.check_camera_pos(self.altitude,self.latitude,self.longitude)!= True:
                        return
                    if self.check_stream_data() != True:
                        return
                    
                    # disable places if configured
                    if eval(self.parent.config["DISABLE_ALL_GE_PLACES"]) == True and (self.disable_places(self.ge.GetMyPlaces()) != True or self.disable_places(self.ge.GetTemporaryPlaces())) != True:
                        return

                if self.check_camera_pos(self.altitude,self.latitude,self.longitude)!= True:
                    return

                if self.do_bulk:
                    extra_info = "\n" + self.parent.lang["bulk_extra_status"].replace("~num~",str(area_count)).replace("~num_of~",str(len(ge_placemarks)))
                    area_count = area_count + 1
                else:
                    extra_info = ""

                # get center of tile
                tile_middle_coords = self.ge.GetPointOnTerrainFromScreenCoords(1 - pixel_per_google * 5.0, -1 + pixel_per_google * 5.0)
                # get ll of tilearea_count = 1
                tile_coords_ll = self.ge.GetPointOnTerrainFromScreenCoords(-1 + pixel_per_google * 5.0,google_screen_cord_y)
                # get ur of tile
                tile_coords_ur = self.ge.GetPointOnTerrainFromScreenCoords(google_screen_cord_x,1 - pixel_per_google * 5.0)

                

                # get width of a tile in amount of lat / lon
                tile_width_height = (tile_coords_ur.Longitude - tile_coords_ll.Longitude,tile_coords_ur.Latitude - tile_coords_ll.Latitude)

                # calculate number of tiles required for our decal
                decal_width_height = (float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"]),float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"]))

                # work out new camera position so that upper left corner of screen capture will be on top of the upper left corner of decal
                self.longitude = tile_middle_coords.Longitude
                self.latitude = tile_middle_coords.Latitude

                gather_start_time = datetime.datetime.now()
                self.parent.log_output("Adjusting camera position for first tile .  .  .",
                                       self.parent.lang["log_camerafirsttile"])
                next_tile = (self.longitude, self.latitude)
                self.ge.SetCameraParams (next_tile[1], next_tile[0], self.altitude, self.alt_mode, self.focus_distance, self.tilt, self.azimuth, self.speed)

                tile_matrix = (int(math.ceil(decal_width_height[0] / tile_width_height[0])),int(math.ceil(decal_width_height[1] / tile_width_height[1])))

                self.parent.matrix_info.SetLabel(self.parent.lang["status_tilexofystart"].replace("~~number~~", str(tile_matrix[0] * tile_matrix[1])) + extra_info)
                
                if self.check_camera_pos(self.altitude,self.latitude,self.longitude) != True:
                    return
                if self.check_stream_data() != True:
                    return
                

                # recreate these settings as we have moved camera
                # get center of tile
                tile_middle_coords = self.ge.GetPointOnTerrainFromScreenCoords(0,0)
                # get bl of tile
                tile_coords_ll = self.ge.GetPointOnTerrainFromScreenCoords(-1 + pixel_per_google * 5.0,google_screen_cord_y)
                # get ur of tile
                tile_coords_ur = self.ge.GetPointOnTerrainFromScreenCoords(google_screen_cord_x,1 - pixel_per_google * 5.0)

                if self.check_render_move(render_position) != True:
                    return
                    
                screen = ImageGrab.grab((render_position[0] + 5,render_position[1] + 5, render_position[2] - render_width_pix_adjust, render_position[3] - render_height_pix_adjust))            
                capture_dimensions = screen.getbbox()
                #screen.save(".\\temp\\1.png")
                self.parent.log_output("X:0 Y:0 tile captured successfully",
                                       self.parent.lang["log_tilegather"].replace("~~number_x~~", "0".replace("~~number_y~~", "0")))

                mode = "RGB"

                num_tiles_x = tile_matrix[0]
                num_tiles_y = tile_matrix[1]

                stitched_map = Image.new(mode, (capture_dimensions[2] * num_tiles_x, capture_dimensions[3] * num_tiles_y))
                
                stitched_map.paste(screen, (0, 0))
                
                self.parent.log_output("Pasted X:0 Y:0 tile to master decal",
                                       self.parent.lang["log_tilepaste"].replace("~~number_x~~", "0").replace("~~number_y~~", "0"))
                tile = 1

                # makes sure windows are on top
                win32gui.ShowWindow(self.ge_window, win32con.SW_MAXIMIZE)
                win32gui.ShowWindow(self.ge_window, win32con.SW_RESTORE)
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOP, 0,50,self.parent.screen_width,main_window_pos[3] + main_window_pos[1] - 50, win32con.SWP_FRAMECHANGED)
                #win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOPMOST, 0,50,self.parent.screen_width,main_window_pos[3] + main_window_pos[1] - 50, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                #win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOPMOST, 0,50,0,0,
                #                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                rw_window = win32gui.FindWindow("wxWindowClassNR",self.parent.lang["status_window_title"])
                win32gui.SetWindowPos(rw_window, win32con.HWND_TOPMOST, 0,0,0,0,
                                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)

                for tile_y in range(0, num_tiles_y):
                    self.prevent_scr()
                    for tile_x in range(0, num_tiles_x):
                        if tile_x == 0 and tile_y == 0:
                            continue
                        if self.check_for_cancel():
                            return
                        tile += 1
                        if self.check_render_move(render_position) != True:
                            return
                        self.parent.matrix_info.SetLabel(self.parent.lang["status_tilexofy"].replace("~~number~~", str(tile)).replace("~~number_of~~", str(tile_matrix[0] * tile_matrix[1])) + extra_info)
                        next_tile = (tile_middle_coords.Longitude + tile_width_height[0] * tile_x, tile_middle_coords.Latitude - tile_width_height[1] * tile_y)
                        self.ge.SetCameraParams (next_tile[1], next_tile[0], self.altitude, self.alt_mode, self.focus_distance, self.tilt, self.azimuth, self.speed)

                        if self.check_camera_pos(self.altitude,next_tile[1],next_tile[0]) != True:
                            return

                        if self.check_stream_data() != True:
                            return

                        screen = ImageGrab.grab((render_position[0] + 5,render_position[1] + 5, render_position[2] - render_width_pix_adjust, render_position[3] - render_height_pix_adjust))
                        #screen.save(".\\temp\\" + str(tile) + ".png")
                        self.parent.log_output("X:" + str(tile_x) + " Y:" + str(tile_y) + " tile captured successfully",
                                               self.parent.lang["log_tilegather"].replace("~~number_x~~", str(tile_x)).replace("~~number_y~~", str(tile_y)))
                            
                        stitched_map.paste(screen, (capture_dimensions[2] * tile_x, capture_dimensions[3] * tile_y))
                        del screen # no longer needed so free up memory
                        self.parent.log_output("Pasted X:" + str(tile_x) + " Y:" + str(tile_y) + " tile to master decal",
                                               self.parent.lang["log_tilepaste"].replace("~~number_x~~", str(tile_x)).replace("~~number_y~~", str(tile_y)))

                last_tile_lr = self.ge.GetPointOnTerrainFromScreenCoords(google_screen_cord_x,google_screen_cord_y)
                # track gathering time
                gather_end_time = datetime.datetime.now()
                gather_time_taken = gather_end_time - gather_start_time
                
                # minimize google earth
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)

                # Stop RWDecal Status being always on top
                win32gui.SetWindowPos(rw_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                self.parent.rw_status_window.Show(False)

                self.parent.matrix_info.SetLabel(self.parent.lang["status_gathercomplete"] + extra_info)

                stitched_map_pixels = stitched_map.getbbox()


                # crop image decal area
                self.parent.log_output("Cropping image to correct area .  .  .",
                                       self.parent.lang["log_cropping"])
                stitched_map = self.crop(stitched_map, last_tile_lr, tile_width_height, capture_dimensions)

                if "save_stiches" in self.parent.hidden_config and eval(self.parent.hidden_config["save_stiches"]) == True:
                    objShell = win32com.client.Dispatch("WScript.Shell")
                    stiches_path = objShell.SpecialFolders("AllUsersDesktop") + "\\"
                    self.parent.check_path_exists(stiches_path)
                    if "stitch_format" in self.parent.hidden_config:
                        # jpg image
                        if self.parent.hidden_config["stitch_format"].lower() == "jpeg" or self.parent.hidden_config["stitch_format"].lower() == "jpg":
                            if "stitch_jpeg_quality" in self.parent.hidden_config and self.parent.hidden_config["stitch_jpeg_quality"].isdigit() == True:
                                self.parent.hidden_config["stitch_jpeg_quality"] = eval(self.parent.hidden_config["stitch_jpeg_quality"])
                            else:
                                self.parent.hidden_config["stitch_jpeg_quality"] = 80;
                            stitched_map.save(stiches_path + str(self.form_settings["DECAL_NAME"]) + "." + self.parent.hidden_config["stitch_format"].lower(), quality=self.parent.hidden_config["stitch_jpeg_quality"],optimized="True")

                        else: # other specified image
                            stitched_map.save(stiches_path + str(self.form_settings["DECAL_NAME"]) + "." + self.parent.hidden_config["stitch_format"].lower())
                    # forced PNG as no options
                    else:
                        stitched_map.save(stiches_path + str(self.form_settings["DECAL_NAME"]) + ".png")
                    
                if stitched_map == False:
                    return

                # chunk image
                if int(self.form_settings["CHUNK_CHOICE"]) != 1:
                    if self.chunk_image(stitched_map) != True:
                        return

                # chosen to keep master decal so resize and convert
                if int(self.form_settings["CHUNK_CHOICE"]) >= 1:
                    # make transparent if required
                    #if eval(self.form_settings["TRANSPARENCY"]) != False:
                        #stitched_map = self.transparency(stitched_map)
                        #stitched_map = self.transparency(stitched_map,int(self.form_settings["TRANSPARENCY"]))
                        
                    # rotate decal if due north fix enabled
                    if eval(self.form_settings["AUTO_ROTATE"]): # using auto rotate feature so calc new rotation based on middle of decal
                        coords = (float(self.form_settings["LL_LAT"]) + ((float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"])) / 2.0),
                                  float(self.form_settings["LL_LON"]) + ((float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / 2.0),
                                  float(self.form_settings["UR_LAT"]))
                        self.form_settings["DUE_NORTH_FIX_DEGREES"] = calc_rotation(coords[0],coords[1],coords[2],self.parent.route_start["LATITUDE"], self.parent.route_start["LONGITUDE"])
                    if eval(self.form_settings["DUE_NORTH_FIX"]) and float(self.form_settings["DUE_NORTH_FIX_DEGREES"]) <> 0:
                        stitched_map = self.rotate_image(stitched_map,
                                                         self.form_settings["DECAL_NAME"])
                        if stitched_map == False:
                            return
                    else: # need scale factor set anyway so set to 0
                        self.x_rotate_scale_factor = 1.0
                        self.y_rotate_scale_factor = 1.0
                    
                    self.num_decals += 1
                    stitched_map = self.check_license(stitched_map) # add black half to image if not licensed
                    self.parent.log_output("Resizing full decal .  .  .",
                                           self.parent.lang["log_resizefull"])
                    # work out rotation factor if there is any
                    if eval(self.form_settings["DUE_NORTH_FIX"]) and float(self.form_settings["DUE_NORTH_FIX_DEGREES"]) <> 0:
                        decal_size_x_meters = (math.sin(math.radians(abs(float(self.form_settings["DUE_NORTH_FIX_DEGREES"])))) * self.capture_area_dimensions[1]) + (math.cos(math.radians(abs(float(self.form_settings["DUE_NORTH_FIX_DEGREES"])))) * self.capture_area_dimensions[0])
                        decal_size_y_meters = (math.cos(math.radians(abs(float(self.form_settings["DUE_NORTH_FIX_DEGREES"])))) * self.capture_area_dimensions[1]) + (math.sin(math.radians(abs(float(self.form_settings["DUE_NORTH_FIX_DEGREES"])))) * self.capture_area_dimensions[0])
                    else:
                        decal_size_x_meters = self.capture_area_dimensions[0]
                        decal_size_y_meters = self.capture_area_dimensions[1]

                     # zoom in if value set in hidden config file
                    if "decal_zoom" in self.parent.hidden_config and float(self.parent.hidden_config["decal_zoom"]) > 1.0:
                        decal_size_x_meters = decal_size_x_meters * float(self.parent.hidden_config["decal_zoom"])
                        decal_size_y_meters = decal_size_y_meters * float(self.parent.hidden_config["decal_zoom"])
                        
                    stitched_map = self.resize(stitched_map) # resize full decal for ace conversion
                    if stitched_map == False:
                        return
                    if self.check_for_cancel():
                        return
                    path = self.parent.config["INSTALL_PATH"] + "\\temp\\full\\" + str(self.form_settings["DECAL_NAME"]) + ".png"
                    self.parent.log_output("Saving full decal .  .  .",
                                           self.parent.lang["log_savemaster"])
                    stitched_map.save(path)
                    if self.check_for_cancel():
                        return
                    if self.convert_to_ace(False, path) != True: # convert to ace format
                        return
                    if self.create_decal_blueprints(False,(self.form_settings["DECAL_NAME"], (decal_size_x_meters * self.x_rotate_scale_factor,decal_size_y_meters * self.y_rotate_scale_factor))) != True:
                        return
                    if eval(self.form_settings["RAILWORKS_EXPORT"]):
                        if self.export_decal_blueprints(False,(self.form_settings["DECAL_NAME"], (decal_size_x_meters * self.x_rotate_scale_factor,decal_size_y_meters * self.y_rotate_scale_factor))) != True:
                            return

                # Create markers
                if eval(self.form_settings["CREATE_MARKERS"]) and (int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]) > 0 or int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]) > 0):
                    self.create_markers_list()
                    if self.create_marker_blueprint() != True:
                        return False
                    if eval(self.form_settings["RAILWORKS_EXPORT"]): # exporting to railworks so export markers
                        if self.export_marker_blueprint() != True:
                            return False

                # delete blueprints.pak
                if eval(self.form_settings["RAILWORKS_EXPORT"]) == True:
                    if os.path.exists(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\Blueprints.pak") == True:
                        os.remove(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\Blueprints.pak")

                self.parent.log_output("Finished",
                                       self.parent.lang["log_finished"])
                end_time = datetime.datetime.now()
                processing_time_taken = end_time - start_time

                # if in improvement program the send data back to RWDecal
                if eval(self.parent.config["IMPROVEMENT_PROGRAM"]) == True:
                    url = 'http://www.rwdecal.co.uk/improvement_program.php'
                    try:
                        values = {'version' : str(self.version),
                                  'ts' : time.time(),
                                  'licensed' : str(self.parent.licensed),
                                  'username' : str(self.parent.license_details["USERNAME"]),
                                  'license_key' : str(self.parent.license_details["LICENSE_KEY"]),
                                  'decal_name' : str(self.form_settings["DECAL_NAME"]),
                                  'll_lat' : str(self.form_settings["LL_LAT"]),
                                  'll_lon' : str(self.form_settings["LL_LON"]),
                                  'ur_lat' : str(self.form_settings["UR_LAT"]),
                                  'ur_lon' : str(self.form_settings["UR_LON"]),
                                  'width' : str(round(self.capture_area_dimensions[0],2)),
                                  'height' : str(round(self.capture_area_dimensions[1],2)),
                                  'altitude' : str(self.altitude),
                                  'chunk_choice' : str(self.form_settings["CHUNK_CHOICE"]),
                                  'camera_speed' : str(self.form_settings["CAMERA_SPEED"]),
                                  'due_north_fix' : str(self.form_settings["DUE_NORTH_FIX"]),
                                  'due_north_fix_degrees' : str(self.form_settings["DUE_NORTH_FIX_DEGREES"]),
                                  'due_north_fix_auto' : str(self.form_settings["AUTO_ROTATE"]),
                                  'auto_rotate_chunk_lock' : str(self.form_settings["AUTO_ROTATE_CHUNK_LOCK"]),
                                  'create_markers' : str(self.form_settings["CREATE_MARKERS"]),
                                  'create_markers_choice_full' : str(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]),
                                  'create_markers_choice_chunks' : str(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]),
                                  'automatic_export' : str(self.form_settings["RAILWORKS_EXPORT"]),
                                  'delete_blueprints' : str(self.form_settings["DELETE_BLUEPRINTS"]),
                                  'num_tiles' : str(num_tiles_x * num_tiles_y),
                                  'num_decals' : str(self.num_decals),
                                  'gather_time' : str(gather_time_taken.seconds),
                                  'chunk_time' : str(self.chunk_time_taken.seconds),
                                  'ace_time' : str(self.ace_time_taken.seconds),
                                  'export_time' : str(self.export_time_taken.seconds),
                                  'processing_time' : str(processing_time_taken.seconds),
                                  'full_decal_px_width' : str(stitched_map_pixels[2]),
                                  'full_decal_px_height' : str(stitched_map_pixels[3]),
                                  'do_bulk' : str(self.do_bulk)}

                        data = urllib.urlencode(values)
                        req = urllib2.Request(url, data)
                        response = urllib2.urlopen(req,timeout=2)
                        outcome = response.read()
                        if outcome != "1":
                            self.parent.log_output("Failed to log usage data with RWDecal Improvement Program. Thank you for trying.",
                                                   self.parent.lang["log_failedimprovementlog"])
                        else:
                            self.parent.log_output("Usage data logged with RWDecal Improvement Program. Thank you for your support.",
                                                   self.parent.lang["log_successimprovementlog"])
                    except:
                        self.parent.log_output("Failed to log usage data with RWDecal Improvement Program. Thank you for trying.",
                                                   self.parent.lang["log_failedimprovementlog"])
                        pass

                if eval(self.parent.config["DELETE_TEMP_FILES"]) == True:
                    shutil.rmtree(self.parent.config["INSTALL_PATH"] + "\\temp\\", True)
                    #os.system('rd .\\temp /S /Q') # Delete temp folder

                self.parent.get_previous_runs(True, self.form_settings, self.do_bulk)

                # tidy up items to help with memory usage
                del stitched_map
                                      

            # finished so tidy up
            self.parent.lock_form("unlock")
            if self.parent.rw_status_window:
                self.parent.rw_status_window.Close(True)
            
            self.parent.get_previous_runs(True, self.form_settings)
            
            if self.parent.licensed or self.altitude >= 1000:
                self.parent.error_handler(self.parent.lang["message_decalcreatedlicensed"].replace("~~time~~",time.strftime("%H:%M:%S (HH:MM:SS)",time.gmtime(processing_time_taken.seconds))),
                                          self.parent.lang["message_decalcreatedlicensed_title"])
            else:
                self.parent.error_handler(self.parent.lang["message_decalcreatedunlicensed"].replace("~~time~~",time.strftime("%H:%M:%S (HH:MM:SS)",time.gmtime(processing_time_taken.seconds))),
                                          self.parent.lang["message_decalcreatedunlicensed_title"])

            self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])
            self.parent.bulk_creating = False
##        except MemoryError:
##            self.parent.log_output(traceback.format_exc())
##            try:
##                self.parent.rw_status_window.Close(True)
##                # minimize google earth
##                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
##                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
##            except:
##                pass
##        
##            self.parent.error_handler(self.parent.lang["message_fatalexceptionmemory"],
##                                      self.parent.lang["message_fatalexceptionmemory_title"])
##
##            self.parent.lock_form("unlock")
##            self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])
##                
##        except:
##            self.parent.log_output(traceback.format_exc())
##            try:
##                self.parent.rw_status_window.Close(True)
##                # minimize google earth
##                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
##                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
##            except:
##                pass
##        
##            self.parent.error_handler(self.parent.lang["message_fatalexception"],
##                                      self.parent.lang["message_fatalexception_title"])
##
##            self.parent.lock_form("unlock")
##            self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])

