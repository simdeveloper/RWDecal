import threading
import subprocess # calling other programs
from xml.dom import minidom # xml parsing
from ltm_to_utm import LLplus # calc box size
import pickle
import os
import math
import time
import wx # GUI
import pythoncom
import win32con
import win32com.client
import win32gui

class kml_marker_parse(threading.Thread):
    def __init__(self, parent, kml_file, decal_name, area, distance, primary_alt_index, secondary_alt_index):
        self.parent = parent
        self.kml_file = kml_file
        self.decal_name = decal_name
        self.area = area
        self.distance = distance
        self.primary_alt_index = primary_alt_index
        self.secondary_alt_index = secondary_alt_index

        if self.primary_alt_index > 19:
            self.primary_alt = int(float(self.parent.altitude_options[self.primary_alt_index].rstrip("km")) * 1000)
        else:
            self.primary_alt = int(float(self.parent.altitude_options[self.primary_alt_index].rstrip("m")))
            
        if self.secondary_alt_index > 19:
            self.secondary_alt = int(float(self.parent.altitude_options[self.secondary_alt_index].rstrip("km")) * 1000)
        else:
            self.secondary_alt = int(float(self.parent.altitude_options[self.secondary_alt_index].rstrip("m")))
        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def check_camera_pos(self,alt,lat,lon, max_coord_deviation = 0.0001, log = True):
        if log == True:
            self.parent.log_output("Checking camera position .  .  .",self.parent.lang["log_cameraposition"])
        while True: # make sure camera is where it is meant to be
            camera_pos = self.ge.GetCamera(True)
            # check if camera deviates from required pos by more than allowed margin
            if round(camera_pos.Range,2) != round(float(alt),2) or (float(lat) - camera_pos.FocusPointLatitude > max_coord_deviation or camera_pos.FocusPointLatitude - float(lat) > max_coord_deviation) or (float(lon) - camera_pos.FocusPointLongitude > max_coord_deviation or camera_pos.FocusPointLongitude - float(lon) > max_coord_deviation) :
                time.sleep(0.1)
                new_camera_pos = self.ge.GetCamera(True)
                # check if camera is stationary. If it is then set new camera location as camera not moving but still not in right place
                if new_camera_pos.Range == camera_pos.Range and new_camera_pos.FocusPointLatitude == camera_pos.FocusPointLatitude and new_camera_pos.FocusPointLongitude == camera_pos.FocusPointLongitude:
                    self.ge.SetCameraParams (lat, lon, alt, 1, 0, 0, 0, self.speed)
            else:
                if int(self.speed) == 5:
                    time.sleep(0.1)
                break
        return True

    def finish(self,unlock = True):
        self.parent.get_marker_pairs(True,True) # update mrker pairs list
        self.parent.get_auto_grab_delete_options()
        if unlock:
            self.parent.lock_form("unlock")
        self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])

    def save_areas(self,areas):
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat", "r")
            ge_placemarks = pickle.load(f)

        else:
            ge_placemarks = {}

        for key in areas.keys():
            ge_placemarks[key] = areas[key]

        data_file = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
        pickle.dump(ge_placemarks, data_file)
        data_file.close()

    def check_cancel(self):
        if self.parent.cancel_clicked:
            return True
        return False

    def go_up(self, coordinates, previous_ul, force = False):
        placemark = {}
        new_coordinates = LLplus(self,previous_ul[0],previous_ul[1],self.area)
        placemark["LL"] = previous_ul[0],previous_ul[1],1000
        placemark["UR"] = new_coordinates[0],new_coordinates[1],1000
        placemark["LR"] = previous_ul[0],new_coordinates[1],1000
        placemark["UL"] = new_coordinates[0],previous_ul[1],1000

        middle_coordinates = placemark["LL"][1] + ((placemark["UR"][1] - placemark["LL"][1]) / 2), placemark["LL"][0] + ((placemark["UR"][0] - placemark["LL"][0]) / 2)

        #print "checking up" , middle_coordinates
        if (force and not self.check_in_any_area(middle_coordinates,force)) or self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_right(self, coordinates, previous_lr, force = False):
        placemark = {}
        new_coordinates = LLplus(self,previous_lr[0],previous_lr[1],self.area)
        placemark["LL"] = previous_lr[0],previous_lr[1],1000
        placemark["UR"] = new_coordinates[0],new_coordinates[1],1000
        placemark["LR"] = previous_lr[0],new_coordinates[1],1000
        placemark["UL"] = new_coordinates[0],previous_lr[1],1000

        middle_coordinates = placemark["LL"][1] + ((placemark["UR"][1] - placemark["LL"][1]) / 2), placemark["LL"][0] + ((placemark["UR"][0] - placemark["LL"][0]) / 2)

        if (force and not self.check_in_any_area(middle_coordinates,force)) or self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False


    def go_left(self,coordinates, previous_ll, previous_ul, force = False):
        placemark = {}
        new_coordinates = LLplus(self,previous_ll[0],previous_ll[1],self.area*-1)
        placemark["LL"] = previous_ll[0],new_coordinates[1],1000
        new_coordinates1 = LLplus(self,previous_ll[0],new_coordinates[1],self.area)
        placemark["UR"] = previous_ul[0],previous_ul[1],1000
        placemark["LR"] = previous_ll[0],previous_ll[1],1000
        placemark["UL"] = new_coordinates1[0],new_coordinates[1],1000

        middle_coordinates = placemark["LL"][1] + ((placemark["UR"][1] - placemark["LL"][1]) / 2), placemark["LL"][0] + ((placemark["UR"][0] - placemark["LL"][0]) / 2)

        if (force and not self.check_in_any_area(middle_coordinates,force)) or self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_down(self,coordinates,previous_ll,previous_lr, force = False):
        placemark = {}
        new_coordinates = LLplus(self,previous_ll[0],previous_ll[1],self.area*-1)
        placemark["LL"] = new_coordinates[0],previous_ll[1],1000
        placemark["UR"] = previous_lr[0],previous_lr[1],1000
        placemark["LR"] = new_coordinates[0],previous_lr[1],1000
        placemark["UL"] = previous_ll[0],previous_ll[1],1000

        middle_coordinates = placemark["LL"][1] + ((placemark["UR"][1] - placemark["LL"][1]) / 2), placemark["LL"][0] + ((placemark["UR"][0] - placemark["LL"][0]) / 2)
        
        if (force and not self.check_in_any_area(middle_coordinates,force)) or self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_down_right(self, coordinates, previous_lr):
        placemark = {}
        new_coordinates = LLplus(self,previous_lr[0],previous_lr[1],self.area*-1)
        placemark["LL"] = new_coordinates[0],previous_lr[1],1000
        new_coordinates1 = LLplus(self,new_coordinates[0],previous_lr[1],self.area)
        placemark["UR"] = new_coordinates1[0],new_coordinates1[1],1000
        placemark["LR"] = new_coordinates[0],new_coordinates1[1],1000
        placemark["UL"] = previous_lr[0],previous_lr[1],1000

        
        if self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_down_left(self, coordinates, previous_ll):
        placemark = {}
        new_coordinates = LLplus(self,previous_ll[0],previous_ll[1],self.area*-1)
        placemark["LR"] = new_coordinates[0],previous_ll[1],1000
        new_coordinates1 = LLplus(self,new_coordinates[0],previous_ll[1],self.area*-1)
        placemark["UR"] = previous_ll[0],previous_ll[1],1000
        placemark["LL"] = new_coordinates[0],new_coordinates1[1],1000
        placemark["UL"] = previous_ll[0],new_coordinates1[1],1000

        
        if self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_up_left(self, coordinates, previous_ul):
        placemark = {}
        new_coordinates = LLplus(self,previous_ul[0],previous_ul[1],self.area*-1)
        placemark["LL"] = previous_ul[0],new_coordinates[1],1000
        new_coordinates1 = LLplus(self,previous_ul[0],new_coordinates[1],self.area)
        placemark["UR"] = new_coordinates1[0],previous_ul[1],1000
        placemark["UL"] = new_coordinates1[0],new_coordinates[1],1000
        placemark["LR"] = previous_ul[0],previous_ul[1],1000

        
        if self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def go_up_right(self, coordinates, previous_ur):
        placemark = {}
        new_coordinates = LLplus(self,previous_ur[0],previous_ur[1],self.area)
        placemark["LL"] = previous_ur[0],previous_ur[1],1000
        placemark["UR"] = new_coordinates[0],new_coordinates[1],1000
        placemark["UL"] = new_coordinates[0],previous_ur[1],1000
        placemark["LR"] = previous_ur[0],new_coordinates[1],1000

        
        if self.check_in_area(coordinates,placemark):
            self.placemark_tmp = placemark
            return True

        return False

    def get_offset(self,coordinates, previous_coordinates):
        horiz = self.parent.vinc_dist(previous_coordinates[0],  previous_coordinates[1],  previous_coordinates[0],  coordinates[1])
        if previous_coordinates[1] > coordinates[1]:
            horiz_real = horiz * -1
        else:
            horiz_real = horiz

        vert = self.parent.vinc_dist(previous_coordinates[0],  previous_coordinates[1],  coordinates[0],  previous_coordinates[1])
        if previous_coordinates[0] > coordinates[0]:
            vert_real = vert * -1
        else:
            vert_real = vert
        return (horiz,horiz_real),(vert,vert_real)

    def get_borders_distances(self,coordinates,area):
        ll_offset = self.get_offset((coordinates[1],coordinates[0]), area["LL"])
        ur_offset = self.get_offset((coordinates[1],coordinates[0]), area["UR"])
        return ll_offset, ur_offset

    def check_in_area(self,coordinates,area):
        if coordinates[0] > (area["LL"][1] - 0.001) and coordinates[0] < (area["LR"][1] + 0.001) and coordinates[1] > (area["LL"][0] - 0.001) and coordinates[1] < (area["UL"][0] + 0.001):
            return True
        return False

    def check_in_any_area(self, coordinates, areas):
        for key in sorted(areas.iterkeys(),key=lambda x: x.lower()):
            if self.check_in_area(coordinates,areas[key]):
                return key

        return False

    def choose_direction(self, i, name, previous_name, coordinates, ge_placemarks, altitude):
        #print i, name, coordinates[1],coordinates[0];
        # try each direction in turn to see if we can make a box containing the marker
        if self.go_left(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["UL"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Left"

        elif self.go_right(coordinates,ge_placemarks[previous_name]["LR"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Right"

        elif self.go_down(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["LR"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Down"

        elif self.go_up(coordinates,ge_placemarks[previous_name]["UL"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Up"

        elif self.go_down_right(coordinates,ge_placemarks[previous_name]["LR"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Down Right"
        
            # add an area up and down from previous area to get intersects
            if self.go_right(coordinates,ge_placemarks[previous_name]["LR"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i = i + 1
            
            if self.go_down(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["LR"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i + i + 1
        

        elif self.go_down_left(coordinates,ge_placemarks[previous_name]["LL"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Down Left"
        
            # add an area up and down from previous area to get intersects
            if self.go_left(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["UL"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i + i + 1
                
            if self.go_down(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["LR"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i + i + 1
            
        elif self.go_up_left(coordinates,ge_placemarks[previous_name]["UL"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = altitude
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Up Left"
        
            # add an area up and down from previous area to get intersects
            if self.go_left(coordinates,ge_placemarks[previous_name]["LL"],ge_placemarks[previous_name]["UL"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i = i + 1
            
            if self.go_up(coordinates,ge_placemarks[previous_name]["UL"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i = i + 1

        elif self.go_up_right(coordinates,ge_placemarks[previous_name]["UR"]):
            ge_placemarks[name] = self.placemark_tmp
            ge_placemarks[name]["ALTITUDE"] = self.primary_alt_index
            ge_placemarks[name]["AUTO"] = True
            ge_placemarks[name]["AUTO_SET_NAME"] = self.decal_name
            #print name, previous_name, "Up Right"
        
            # add an area up and down from previous area to get intersects
            if self.go_right(coordinates,ge_placemarks[previous_name]["LR"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i = i + 1
            
            if self.go_up(coordinates,ge_placemarks[previous_name]["UL"], ge_placemarks):
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)] = self.placemark_tmp
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["ALTITUDE"] = altitude
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO"] = True
                ge_placemarks[self.decal_name + " " + str(i+1).zfill(4)]["AUTO_SET_NAME"] = self.decal_name
                i = i + 1


        else:
            # save data as pickled object
            ge_placemarks.setdefault("Point Too Far",{})["LL"] = coordinates[1],coordinates[0],1000
            self.save_areas(ge_placemarks)
            result = self.parent.error_handler(self.parent.lang["kml_path_fail"].replace("~~area~~",str(self.area)),self.parent.lang["kml_path_fail_title"],wx.YES_NO)

            if result == wx.ID_YES:
                wx.CallAfter(self.parent.evt_grab_start, True, (coordinates[1],coordinates[0]))
##                self.parent.log_output("Google Earth initialising .  .  .",self.parent.lang["log_geinitialise"])
##                try:
##                    pythoncom.CoInitialize()
##                    self.ge = win32com.client.Dispatch("GoogleEarth.ApplicationGE")
##                    
##                    # make ge always on top and positioned right
##                    self.ge_window = win32gui.FindWindow("QWidget","Google Earth")
##                    win32gui.ShowWindow(self.ge_window, win32con.SW_MAXIMIZE)
##                    
##                    self.speed = 5
##                    
##                    self.check_camera_pos(2000,coordinates[1],coordinates[0], 0.0001, False)
##
##                     # check if network link already loaded
##                    rw_kml = self.ge.GetFeatureByName("RWDecal Objects")
##                    if rw_kml != None:
##                        rw_kml.Visibility = True
##                    else: # load kml
##                        self.ge.OpenKmlFile(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks_link.kml",True)
##                except:
##                    self.parent.error_handler(self.parent.lang["message_fatalexception"],
##                    self.parent.lang["message_fatalexception_title"])
##                    pass
            
            return (i,ge_placemarks,False)
        #print
        return (i,ge_placemarks)

    def run(self):
        self.parent.lock_form("lock")
        self.parent.cancel_clicked = False
        
        self.parent.log_output("Calulating KML Path Areas .  .  .",self.parent.lang["kml_path_status"])

        bin_xml = minidom.parse(self.kml_file)
        items = bin_xml.getElementsByTagName("LineString")
        if items.length != 1:
            self.parent.error_handler(self.parent.lang["kml_multiple_paths"],self.parent.lang["kml_multiple_paths_title"])
            self.finish()
            return
        else:
            ge_placemarks = {}
            
            coordinates = items[0].getElementsByTagName("coordinates") # make sure there is a co-ordiante set
            if coordinates.length != 1:
                self.parent.error_handler(self.parent.lang["kml_invalid_coordinates"],self.parent.lang["kml_invalid_coordinates_title"])
                self.finish()
                return
            
            coordinates_set = coordinates[0].firstChild.data.strip().split(" ")
            self.num_areas_per_point = int(math.ceil((self.distance - (self.area/2.0)) / float(self.area)) + 1)
            first = True
            created = False
            i = 1
            j = 1
            for coordinates in coordinates_set:
                percent = str(round((100.0 / float(len(coordinates_set)) * float(j)),2)) + "%"
                j = j + 1
                if self.check_cancel():
                    self.finish()
                    return
                in_an_area = False
                coordinates = coordinates.split(",")
                coordinates[0] = float(coordinates[0])
                coordinates[1] = float(coordinates[1])
            
                name = self.decal_name + " " + str(i).zfill(4)
                if first: # this is first point so need to find middle and then make sure we cover the area required
                    show_coordinates = coordinates
                    first = False
                    #print coordinates[1],coordinates[0], "First"
                    new_coordinates = LLplus(self,coordinates[1],coordinates[0],(self.area/2)*-1)
                    new_coordinates1 = LLplus(self,new_coordinates[0],coordinates[0],(self.area/2)*-1)
                    ge_placemarks.setdefault(name,{})["LL"] = new_coordinates[0],new_coordinates1[1],1000
                    new_coordinates2 = LLplus(self,new_coordinates[0],new_coordinates1[1],self.area)
                    ge_placemarks.setdefault(name,{})["UR"] = new_coordinates2[0],new_coordinates2[1],1000
                    ge_placemarks.setdefault(name,{})["UL"] = new_coordinates2[0],new_coordinates1[1],1000
                    ge_placemarks.setdefault(name,{})["LR"] = new_coordinates[0],new_coordinates2[1],1000
                    ge_placemarks.setdefault(name,{})["ALTITUDE"] = self.primary_alt_index
                    ge_placemarks.setdefault(name,{})["AUTO"] = True
                    ge_placemarks.setdefault(name,{})["AUTO_SET_NAME"] = self.decal_name
                    previous_name = name
                    previous_area_middle_coordinates = coordinates
                    previous_coordinates = coordinates
                    i = i + 1
                    #print name, "first", coordinates[1],coordinates[0]
                else:
                    # get horiz and vert to next point
                    offset = self.get_offset((coordinates[1],coordinates[0]),(previous_area_middle_coordinates[1],previous_area_middle_coordinates[0]))
                    if offset[0][0] < self.area/2.0 and offset[1][0] < self.area/2.0: # skip if within existing area
                        #print coordinates[1],coordinates[0], "Skipped";
                        continue

                    in_an_area = self.check_in_any_area(coordinates,ge_placemarks)
                    if in_an_area != False:
                        #print coordinates[1],coordinates[0], "In Area", name
                        #print name, "prim in area", coordinates[1],coordinates[0]
                        previous_name = in_an_area
                        # make sure altitude is that of a primary area
                        if ge_placemarks[previous_name]["ALTITUDE"] != self.primary_alt_index:
                            ge_placemarks[previous_name]["ALTITUDE"] = self.primary_alt_index
                            self.parent.log_output("Converted secondary decal area " + previous_name + " to primary decal area", self.parent.lang["kml_path_status_convert"].replace("~percent~", percent).replace("~previous_name~", previous_name))
                    else:
                        #print coordinates[1],coordinates[0], "Not In Area", name
                        #print name, "prim not in area", coordinates[1],coordinates[0]
                        self.parent.log_output("Created primary decal area " + str(i), self.parent.lang["kml_path_status_primary"].replace("~percent~", percent).replace("~decal_name~", name))
                        # first make sure try and get the point in a primary area
                        choose = self.choose_direction(i, name, previous_name, coordinates, ge_placemarks, self.primary_alt_index)
                        ge_placemarks = choose[1]
                        i = choose[0]

                        if len(choose) == 3:
                            #print "boo", coordinates
                            #print ge_placemarks[previous_name]
                            self.save_areas(ge_placemarks)
                            self.finish()
                            return

                        previous_name = name
                        previous_area_middle_coordinates = ge_placemarks[name]["LL"][1] + ((ge_placemarks[name]["UR"][1] - ge_placemarks[name]["LL"][1]) / 2), ge_placemarks[name]["LL"][0] + ((ge_placemarks[name]["UR"][0] - ge_placemarks[name]["LL"][0]) / 2)
                        previous_coordinates = coordinates

                        if in_an_area == False:
                            i = i + 1

                # now loop until we have areas to cover the distance from point we require
                degrees = 0
                previous_name_2nd = previous_name
                while degrees < 360:
                    distance_away = 0.0
                    previous_name_2nd = previous_name
                    while distance_away < self.distance:
                        name = self.decal_name + " " + str(i).zfill(4)
                        extra = self.parent.vinc_pt(coordinates[1], coordinates[0], degrees, min(self.distance,(distance_away + self.area)))
                        in_an_area_2nd = self.check_in_any_area((extra[1], extra[0]),ge_placemarks)
                        if in_an_area_2nd != False:
                            # print name, previous_name_2nd, "2nd in area", extra[0],extra[1]
                            name = in_an_area_2nd
                        else:
                            # first make sure try and get the point in a secondary area
                            # print name, previous_name_2nd, "2nd not in area", extra[0],extra[1]
                            self.parent.log_output("Created secondary decal area " + str(i) + " with distance: " + str(distance_away + self.area) + " angle: " + str(degrees) + " degrees", self.parent.lang["kml_path_status_secondary"].replace("~percent~", percent).replace("~decal_name~", name).replace("~degrees~", str(degrees)).replace("~distance~", str(min(self.distance,(distance_away + self.area)))))
                            choose = self.choose_direction(i, name, previous_name_2nd, (extra[1],extra[0]), ge_placemarks, self.secondary_alt_index)
                    
                            ge_placemarks = choose[1]
                            i = choose[0]

                            if len(choose) == 3:
                                #print "boo2"
                                self.save_areas(ge_placemarks)
                                self.finish()
                                return

                        previous_name_2nd = name
                        #previous_area_middle_coordinates_2nd = ge_placemarks[name]["LL"][1] + ((ge_placemarks[name]["UR"][1] - ge_placemarks[name]["LL"][1]) / 2), ge_placemarks[name]["LL"][0] + ((ge_placemarks[name]["UR"][0] - ge_placemarks[name]["LL"][0]) / 2)
                        #previous_coordinates = coordinates
                        if in_an_area_2nd == False:
                            i = i + 1
                        distance_away = distance_away + self.area
                    degrees = degrees + 1

            # save data as pickled object
            self.save_areas(ge_placemarks)

        self.parent.log_output("Succesfully created areas from a KML path", self.parent.lang["kml_path_success_status"])
        result = self.parent.error_handler(self.parent.lang["kml_path_success"],self.parent.lang["kml_path_success_title"],wx.YES_NO)
        if result == wx.ID_YES:
            wx.CallAfter(self.parent.evt_grab_start, True, (show_coordinates[1],show_coordinates[0]))
            self.finish(False)
        else:
            self.finish()
