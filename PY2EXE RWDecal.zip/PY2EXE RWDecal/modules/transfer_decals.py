import threading
import subprocess # calling other programs
import os
import codecs # unicode file handling
import re # regular expression support
from xml.dom import minidom # xml parsing
from get_used_decals_spider import get_used_decals_spider # route cache generator
import shutil


class transfer_decals(threading.Thread):
    def __init__(self, parent, routes_to_search, a, b, copy_or_transfer):
        self.parent = parent
        self.routes_to_search = routes_to_search
        self.a = a
        self.b = b
        tmp = self.a.split("\\")
        self.a_provider = tmp[0]
        self.a_product = tmp[1]
        tmp = self.b.split("\\")
        self.b_provider = tmp[0]
        self.b_product = tmp[1]
        self.copy_or_transfer = copy_or_transfer
                        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self):
        self.parent.lock_form("unlock")
        self.parent.log_output(self.parent.lang["status_ready"],self.parent.lang["status_ready"])
        

    def check_cancel(self):
        if self.parent.cancel_clicked:
            return True
        return False

    def list_decals(self,decal_path):
        decal_path = decal_path.rstrip("\\")
        decal_list = list()
        
        if not os.path.isdir(decal_path):
            return decal_list
        
        # get a list of all decals
        bin_files = os.listdir(decal_path)
      
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        for bin_file in bin_files: # loop through files
            bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
            if bin_file_parts[1] == ".bin": # make sure is a bin file
                if re.match(".*X\d+ Y\d+\.bin$",bin_file) != None: # is chunk so add to list
                    decal_list.append((bin_file_parts[0],bin_file,decal_path + "\\" + bin_file))
                        
                else: # not a chunk so must decode bin and check if we have a naem starting with GE:
                    # convert bin file to an xml file in the temp folder
                    self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                    decal_path + "\\" + bin_file,
                                    "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                    startupinfo=self.startupinfo)
                    
                    # parse xml finding decals
                    bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
                    items = bin_xml.getElementsByTagName("Name")
                    try:
                        decal_name = items[0].firstChild.data
                    except:
                            pass
                    if re.match("^GE: .*$",decal_name) != None:
                        decal_list.append((decal_name,bin_file,decal_path + "\\" + bin_file))
                                    
                    # remove xml file
                    os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
        return decal_list

    def run(self):
        if self.a == self.b:
            self.parent.error_handler(self.parent.lang["transfer_decals_a_b_same"], self.parent.lang["transfer_decals_a_b_same_title"])
            self.finish()
        self.parent.lock_form("lock")
        self.parent.cancel_clicked = False

        # first of all generate decal cache for each route users asked to search.
        # then when we modify a tile and after we have moved it we can look at the cache
        # which will tell us what decals are used in a route
        if self.copy_or_transfer == "transfer":
            i = 1
            for route_name in sorted(self.routes_to_search.iterkeys(),key=lambda x: x.lower()):
                status = self.parent.lang["transfer_decals_generate_cache"].replace("~~route~~",route_name).replace("~~number~~", str(i)).replace("~~number_max~~",str(len(self.routes_to_search)))
                self.parent.main_window_status.SetLabel(status)
                route_folder = self.routes_to_search[route_name]
                route_path = self.parent.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_folder  + "\\"
                get_used_decals_spider(self, route_folder, route_path,False,False,status)
                if self.check_cancel():
                    self.finish()
                    return
                i = i + 1
        

        # get location of assets in A
        a_decals = self.list_decals(self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.a + "\\" + self.parent.config["RW_DECALS_PATH"])

        a_decal_path = self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.a + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\"
        a_marker_path = self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.a + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"
        b_decal_path = self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\"
        b_marker_path = self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        self.parent.check_path_exists(b_decal_path + "aces\\")
        self.parent.check_path_exists(b_marker_path + "csv\\")

        # loop through each decal in location A and do renaming required        
        for bin_file in a_decals:
            if self.check_cancel():
                self.finish()
                return

            bin_file_parts = os.path.splitext(bin_file[1]) # split filename into name + extension
            self.parent.log_output(self.parent.lang["transfer_decals_transfer"].replace("~~decal~~",bin_file_parts[0]),self.parent.lang["transfer_decals_transfer"].replace("~~decal~~",bin_file_parts[0]))

            # first convert bin file to xml and change the texture entry
            # convert bin file to an xml file in the temp folder
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                            bin_file[2],
                            "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                            startupinfo=self.startupinfo)

            f = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()

            data = data.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
            lines = data.split("\n")

            output = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml", encoding="UTF-8", mode="w")
            #Loop through lines replacing texture entry
            modified = False
            for line in lines:
                if re.match("^[ \t]+<TextureID d:type=\"cDeltaString\">" + re.escape(self.a + "\\"),line) != None:
                    line = line.replace("<TextureID d:type=\"cDeltaString\">" + self.a + "\\","<TextureID d:type=\"cDeltaString\">" + self.b + "\\")
                    modified = True
                output.write(line + "\n")
            output.close()

            # Convert xml back to a bin only if it has been modified
            if modified:
                #print "modified", bin_file[1]
                # export decal back to bin
                if self.copy_or_transfer == "transfer":
                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                            self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml",
                                            "/bin:" + bin_file[2]],
                                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                            startupinfo=self.startupinfo)

                    # move decal to new location
                    shutil.move(bin_file[2], b_decal_path + bin_file[1])
                    if os.path.isfile(a_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx"):
                        shutil.move(a_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx", b_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx")

                    # remove temp xml decal file
                    os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")

                else: # copy
                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                            self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml",
                                            "/bin:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".bin"],
                                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                            startupinfo=self.startupinfo)
                    # copy decal to new location
                    shutil.copy(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".bin", b_decal_path + bin_file[1])
                    if os.path.isfile(a_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx"):
                        shutil.copy(a_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx", b_decal_path + "aces\\" + bin_file_parts[0] + ".TgPcDx")

                # now search for markers file for the decal set
                decal_set = re.sub("X\d+ Y\d+\.bin$","",bin_file[1]).strip()
                marker_path = self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.a + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"
                if os.path.isfile(marker_path + decal_set + ".bin"):
                    # first convert bin file to xml and change the texture entry
                    # convert bin file to an xml file in the temp folder
                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                    marker_path + decal_set + ".bin",
                                    "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml"],
                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                    startupinfo=self.startupinfo)

                    # now we need to read in xml and correct it
                    f = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml", encoding="UTF-8", mode="r")
                    data = f.read()
                    f.close()

                    data = data.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
                    lines = data.split("\n")

                    output = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml", encoding="UTF-8", mode="w")
                    #Loop through lines replacing texture entry
                    modified = False
                    for line in lines:
                        if re.match("^[ \t]+<CsvFile d:type=\"cDeltaString\">" + re.escape(self.a + "\\"),line) != None:
                            line = line.replace("<CsvFile d:type=\"cDeltaString\">" + self.a + "\\","<CsvFile d:type=\"cDeltaString\">" + self.b + "\\")
                            modified = True
                            #print "updated csv reference"

                        output.write(line + "\n")
                    output.close()

                    if self.copy_or_transfer == "transfer":
                        subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                            self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml",
                                            "/bin:" + marker_path + decal_set + ".bin"],
                                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                            startupinfo=self.startupinfo)
                        # move file to new location
                        shutil.move(marker_path + decal_set + ".bin", self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\" + decal_set + ".bin")
                        if os.path.isfile(marker_path + "csv\\" + decal_set + ".dcsv"):
                            shutil.move(marker_path + "csv\\" + decal_set + ".dcsv", self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + decal_set + ".dcsv")
                        os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml")
                        
                    else: # copy
                        subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                            self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + "_marker.xml",
                                            "/bin:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + ".bin"],
                                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                            startupinfo=self.startupinfo)
                        # move file to new location
                        shutil.move(self.parent.config["INSTALL_PATH"] + "\\temp\\" + decal_set + ".bin", self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\" + decal_set + ".bin")
                        if os.path.isfile(marker_path + "csv\\" + decal_set + ".dcsv"):
                            shutil.copy(marker_path + "csv\\" + decal_set + ".dcsv", self.parent.config["RAILWORKS_PATH"] + "\\assets\\" + self.b + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + decal_set + ".dcsv")
                    
                    
                    #print "exported marker", decal_set

            if self.copy_or_transfer == "transfer":
                # now for each route we are going to update reload the cache
                for route_name in sorted(self.routes_to_search.iterkeys(),key=lambda x: x.lower()):
                    route_folder = self.routes_to_search[route_name]
                    route_path = self.parent.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_folder  + "\\"
                    used_decals = get_used_decals_spider(self, route_folder, route_path,False,True)
                    if self.a + "\\" + bin_file[1].lower() in used_decals: # is the bin file in the cache of tiles that contain the bin file
                        if self.check_cancel():
                            self.finish()
                            return
                        for tile in used_decals[self.a + "\\" + bin_file[1].lower()]: # for each tile in the cache modify the entries
                            tile_parts = os.path.splitext(tile) # split filename into name + extension
                            self.parent.log_output("Finding " + bin_file_parts[0] + " references in  " + route_name + " route","Finding " + bin_file_parts[0] + " references in  " + route_name + " route")
                            # first convert bin file to xml and change the texture entry
                            # convert bin file to an xml file in the temp folder
                            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                            route_path + "Scenery\\" + tile,
                                            "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml"],
                                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                            startupinfo=self.startupinfo)

                            # parse xml updating decals
                            bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml")
                            items = bin_xml.getElementsByTagName("cDynamicEntity")
                            for i in range(items.length): # loop through the routes
                                if items[i].getElementsByTagName("cDecalComponent").length == 1: # make sure it is a decal
                                    provider = ""
                                    try:
                                        provider = items[i].getElementsByTagName("Provider")[0].firstChild.data
                                    except:
                                        pass
                                    product = ""
                                    try:
                                        product = items[i].getElementsByTagName("Product")[0].firstChild.data
                                    except:
                                        pass

                                    blueprint_id = ""
                                    try:
                                        blueprint_id = items[i].getElementsByTagName("BlueprintID")[1].firstChild.data
                                    except:
                                        pass
                                    if provider == self.a_provider and product == self.a_product and blueprint_id == self.parent.config["RW_DECALS_PATH"].lower() + "\\" + re.sub("\.bin$",".xml",bin_file[1].lower()):
                                        items[i].getElementsByTagName("iBlueprintLibrary-cBlueprintSetID")[0].removeChild(items[i].getElementsByTagName("Provider")[0])
                                        items[i].getElementsByTagName("iBlueprintLibrary-cBlueprintSetID")[0].removeChild(items[i].getElementsByTagName("Product")[0])

                                        new_provider = bin_xml.createElement("Provider")  # creates <foo />
                                        new_provider.setAttribute("d:type", "cDeltaString")
                                        provider_value = bin_xml.createTextNode(self.b_provider)  # creates provider value
                                        new_provider.appendChild(provider_value)  # add value to provider
                                        items[i].getElementsByTagName("iBlueprintLibrary-cBlueprintSetID")[0].appendChild(new_provider)  # add provider

                                        new_product = bin_xml.createElement("Product")  # creates
                                        new_product.setAttribute("d:type", "cDeltaString")
                                        product_value = bin_xml.createTextNode(self.b_product)  # creates product value
                                        new_product.appendChild(product_value)  # add value to product
                                        items[i].getElementsByTagName("iBlueprintLibrary-cBlueprintSetID")[0].appendChild(new_product)  # add product

                                        fp = codec.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","w","UTF-8")
                                        bin_xml.writexml(fp, "", "", "", "UTF-8")
                                        fp.close()

                                        output = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","r").read()

                                        # remove any blank lines
                                        lines = output.split("\n")
                                        output = ""
                                        
                                        #Loop through lines to remove empty lines left by the removeChild call and correct self closing tags (serz errors)
                                        for line in lines:
                                            # correct closing tags on name nodes
                                            self_close = re.search("<[^>]+?/>",line)
                                            if self_close:
                                                if self_close.group(0).find(" ") == -1:
                                                    item_end = self_close.group(0).find("/>")
                                                else:
                                                    item_end = self_close.group(0).find(" ")
                                                item = self_close.group(0)[1:item_end]
                                                line = line.replace("/","") + "</" + item + ">"
                                                
                                            if len(line.strip()) == 0:
                                                continue;
                                            output += line + "\n"

                                        # save xml
                                        fp = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","w")
                                        fp.write(output)
                                        fp.close()

                                        subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                                        self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml",
                                                        "/bin:" + route_path + "Scenery\\" + tile],
                                                        stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                                        startupinfo=self.startupinfo)

                                        os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml")
                                        self.parent.log_output(self.parent.lang["transfer_decals_corrected_ref"].replace("~~decal~~",bin_file_parts[0]).replace("~~tile~~",tile_parts[0]),self.parent.lang["transfer_decals_corrected_ref"].replace("~~decal~~",bin_file_parts[0]).replace("~~tile~~",tile_parts[0]))
                                        #print "Updated tile " + tile + " correcting " + bin_file[1]
                                        #updated = True
                           # if decal == "GE: " + bin_file_parts[0]:
                           #     print decal + " is used in " + tile + " tile"
                    #print used_decals
            
        #self.parent.log_output(message, update_status = False, fatal = False):
        # remove blueprints.pak file if exists
        if os.path.exists(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.a_provider + "\\" + self.a_product + "\\Blueprints.pak") == True:
            os.remove(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.a_provider + "\\" + self.a_product + "\\Blueprints.pak")

        if os.path.exists(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.b_provider + "\\" + self.b_product + "\\Blueprints.pak") == True:
            os.remove(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.b_provider + "\\" + self.b_product + "\\Blueprints.pak")

        self.parent.error_handler(self.parent.lang["transfer_decals_complete"].replace("~~method~~",self.copy_or_transfer).replace("~~location_b~~",self.b),self.parent.lang["transfer_decals_complete_title"])
            
        self.finish()
        return
                     
