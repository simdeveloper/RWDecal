import threading
import codecs
import pythoncom
import subprocess # calling other programs
import datetime
import os
from xml.dom import minidom # xml parsing
import re # regular expression support
import time
import shutil # file operations

class clean_up(threading.Thread):
    def __init__(self, parent, wX, wY, backup_only = False):
        self.parent = parent
        self.wX = wX
        self.wY = wY
        self.backup_only = backup_only

        # needed if not doing backup only
        if self.backup_only == False:
            # what is being deleted
            self.decal_asset_check = self.parent.decal_asset_check.GetValue()
            self.decal_source_check = self.parent.decal_source_check.GetValue()
            self.marker_asset_check = self.parent.marker_asset_check.GetValue()
            self.marker_source_check = self.parent.marker_source_check.GetValue()

            # what is being backed up
            self.backup_route_check = self.parent.backup_route_check.GetValue()
            self.backup_assets_check = self.parent.backup_assets_check.GetValue()
            self.backup_source_check = self.parent.backup_source_check.GetValue()
                
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self): # check if cancel has been clicked
        self.parent.gauge_panel.Show(False)
        self.parent.main_panel.Show(True)
        self.parent.lock_form("unlock")

        # needed tp get screen to update
        self.parent.Layout()
        #self.parent.SetSize((1, 1))
        #self.parent.SetSize((self.wX, self.wY))

    def run(self):
                    
        # get all items to backup
        if self.backup_only != False or self.backup_route_check == True:
            if self.backup_only != False:
                backup_items = self.parent.spider_folder(self.backup_only,False,True)
            else:
                folders_to_spider = {}
                folders_to_spider[self.parent.route_path] = "\\Content\\Routes\\" + self.parent.route_folder
                if self.backup_assets_check:
                    folders_to_spider[self.parent.assets_path] = "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"]
                if self.backup_source_check:
                    folders_to_spider[self.parent.source_path] = "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"]
                backup_items = self.parent.spider_folder(folders_to_spider,False,True)
            self.parent.gauge.SetRange(len(backup_items))
           
            backup_name = re.sub(r'\W+', '', self.parent.route_name) + ", " + self.parent.config["DEVELOPER"] + ", " + self.parent.config["PRODUCT"] + ", " + str(datetime.datetime.now()).replace(":",".")[0:len(str(datetime.datetime.now()))-7]
            backup_path = self.parent.config["INSTALL_PATH"] + "\\backups\\" + backup_name + ".zip"
            result = self.parent.make_archive(backup_items, backup_name, self.parent.gauge, self.parent.title)

            if result == False:
                self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                self.finish()
                return

            self.parent.error_handler(self.parent.lang["backup_created"].replace("~~num~~",str(len(backup_items))).replace("~~backup_path~~",backup_path), self.parent.lang["backup_created_title"])
            if self.backup_only != False:
                self.finish()
                return
                    
        bin_files = os.listdir(self.parent.route_path + "Scenery\\")
        confirmed_bins = list()
        
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        for bin_file in bin_files: # loop through files
            bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
            if bin_file_parts[1] == ".bin": # make sure is a bin file
                confirmed_bins.append(bin_file)
        num_bin = 0
        if len(confirmed_bins) == 0:
            self.parent.error_handler(self.parent.lang["clean_up_decals_no_bins"], self.parent.lang["clean_up_decals_no_bins_title"])
            self.finish()
            return False
        else:
            self.parent.gauge.SetValue(0)
            self.parent.gauge.SetRange(len(confirmed_bins))

            for bin_file in confirmed_bins: # loop through files
                bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
                if self.parent.cancel_clicked:
                    self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                    self.finish()
                    return
                self.parent.gauge.SetValue(self.parent.gauge.GetValue() + 1)
                self.parent.title.SetLabel(self.parent.lang["clean_up_bin_status"].replace("~~num~~",str(self.parent.gauge.GetValue())).replace("~~num_of~~",str(len(confirmed_bins))))
                updated = False
                # convert bin file to an xml file in the temp folder
                subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                self.parent.route_path + "Scenery\\" + bin_file,
                                "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                                stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                startupinfo=self.startupinfo)


                # parse xml removing decals
                bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
                items = bin_xml.getElementsByTagName("cDynamicEntity")
                for i in range(items.length): # loop through the routes
                    if items[i].getElementsByTagName("cDecalComponent").length == 1: # make sure it is a decal
                        decal_name = ""
                        try:
                            decal_name = items[i].getElementsByTagName("Name")[0].firstChild.data
                        except:
                            pass
                        if re.match("^GE: .*$",decal_name) != None:
                            bin_xml.getElementsByTagName("Record")[0].removeChild(items[i])
                            updated = True

                if updated:
                    num_bin += 1
                    fp = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml","w", "UTF-8")
                    # writexml(self, writer, indent='', addindent='', newl='', encoding=None)
                    bin_xml.writexml(fp, "", "", "", "UTF-8")
                    fp.close()

                    output = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml","r").read()

                    # remove any blank lines
                    lines = output.split("\n")
                    output = ""
                    
                    #Loop through lines to remove empty lines left by the removeChild call and correct self closing tags (serz errors)
                    for line in lines:
                        # correct closing tags on name nodes
                        self_close = re.search("<[^>]+?/>",line)
                        if self_close:
                            if self_close.group(0).find(" ") == -1:
                                item_end = self_close.group(0).find("/>")
                            else:
                                item_end = self_close.group(0).find(" ")
                            item = self_close.group(0)[1:item_end]
                            line = line.replace("/","") + "</" + item + ">"
                            
                        if len(line.strip()) == 0:
                            continue;
                        output += line + "\n"

                    # save xml
                    fp = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml","w")
                    fp.write(output)
                    fp.close()

                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                    self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml",
                                    "/bin:" + self.parent.route_path + "Scenery\\" + bin_file],
                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                    startupinfo=self.startupinfo)

                # remove xml file
                os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")

        confirmed_assets = list()
        num_asset = 0
        if self.decal_asset_check == True:
            if self.parent.cancel_clicked:
                self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                self.finish()
                return
            self.parent.title.SetLabel(self.parent.lang["clean_up_decals_asset_status"])
            self.parent.gauge.SetValue(0)
            self.parent.gauge.SetRange(1)
            
            self.parent.assets_path += self.parent.config["RW_DECALS_PATH"] + "\\"

            if os.path.isdir(self.parent.assets_path):
                shutil.rmtree(self.parent.assets_path)
            self.parent.gauge.SetValue(1)

        if self.decal_source_check == True:
            if self.parent.cancel_clicked:
                self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                self.finish()
                return
            self.parent.title.SetLabel(self.parent.lang["clean_up_decals_source_status"])
            self.parent.gauge.SetValue(0)
            self.parent.gauge.SetRange(1)
            
            self.parent.source_path += self.parent.config["RW_DECALS_PATH"] + "\\"

            if os.path.isdir(self.parent.source_path):
                shutil.rmtree(self.parent.source_path)
            self.parent.gauge.SetValue(1)

        if self.marker_asset_check == True:
            if self.parent.cancel_clicked:
                self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                self.finish()
                return
            self.parent.title.SetLabel(self.parent.lang["clean_up_markers_asset_status"])
            self.parent.gauge.SetValue(0)
            self.parent.gauge.SetRange(1)
            
            marker_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"

            if os.path.isdir(marker_path):
                shutil.rmtree(marker_path)
            self.parent.gauge.SetValue(1)

        if self.marker_source_check == True:
            if self.parent.cancel_clicked:
                self.parent.error_handler(self.parent.lang["action_cancelled"],self.parent.lang["action_cancelled_title"])
                self.finish()
                return
            self.parent.title.SetLabel(self.parent.lang["clean_up_markers_source_status"])
            self.parent.gauge.SetValue(0)
            self.parent.gauge.SetRange(1)
            
            marker_path = self.parent.config["RAILWORKS_PATH"] + "\\Source\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"

            if os.path.isdir(marker_path):
                shutil.rmtree(marker_path)
            self.parent.gauge.SetValue(1)

        self.parent.error_handler(self.parent.lang["clean_up_decals_finished"].replace("~~num_bin~~",str(num_bin)), self.parent.lang["clean_up_decals_finished_title"])
            
        self.finish()
