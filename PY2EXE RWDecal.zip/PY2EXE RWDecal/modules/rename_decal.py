import threading
import subprocess # calling other programs
import os
import re # regular expression support
import codecs # unicode file handling
import shutil
import pickle
from xml.dom import minidom # xml parsing
from get_used_decals_spider import get_used_decals_spider # route cache generator

class rename_decal(threading.Thread):
    def __init__(self, parent, old_decal, new_decal, routes_to_search):
        self.parent = parent
        self.old_decal = old_decal
        self.new_decal = new_decal
        self.routes_to_search = routes_to_search
        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self):
        self.parent.lock_form("unlock")
        self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])

    def check_cancel(self):
        if self.parent.cancel_clicked:
            return True
        return False

    def find_decals(self,decal_path,decal_name):
        decal_path = decal_path.rstrip("\\")
        decal_list = list()
        
        if not os.path.isdir(decal_path):
            return decal_list
        
        # get a list of all decals
        bin_files = os.listdir(decal_path)
      
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        for bin_file in bin_files: # loop through files
            bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
            if bin_file_parts[1] == ".bin": # make sure is a bin file
                if re.match(decal_name + " X\d+ Y\d+\.bin$",bin_file) != None or re.match(decal_name + "\.bin$",bin_file) != None: # is chunk so add to list
                    decal_list.append((bin_file_parts[0],bin_file,decal_path + "\\" + bin_file))

        return decal_list

    def run(self):
        self.parent.lock_form("lock")
        self.parent.cancel_clicked = False

        # first of all generate decal cache for each route users asked to search.
        # then when we modify a tile and after we have moved it we can look at the cache
        # which will tell us what decals are used in a route
        i = 1
        for route_name in sorted(self.routes_to_search.iterkeys(),key=lambda x: x.lower()):
            status = self.parent.lang["transfer_decals_generate_cache"].replace("~~route~~",route_name).replace("~~number~~", str(i)).replace("~~number_max~~",str(len(self.routes_to_search)))
            self.parent.main_window_status.SetLabel(status)
            route_folder = self.routes_to_search[route_name]
            route_path = self.parent.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_folder  + "\\"
            get_used_decals_spider(self, route_folder, route_path,False,False,status)
            if self.check_cancel():
                self.finish()
                return
            i = i + 1

        decals_to_rename = self.find_decals(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"],self.old_decal)

        files_to_rename = list()
        # loop through each decal to rename and do rename
        for decal_to_rename in decals_to_rename:
            self.parent.log_output("Renaming " + decal_to_rename[0] + " decal","Renaming " + decal_to_rename[0] + " decal")
            if self.check_cancel():
                self.finish()
                return

            bin_file_parts = os.path.splitext(decal_to_rename[1]) # split filename into name + extension

            # first convert bin file to xml and change the texture entry
            # convert bin file to an xml file in the temp folder
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                            decal_to_rename[2],
                            "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                            startupinfo=self.startupinfo)

            f = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()

            data = data.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
            lines = data.split("\n")

            output = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml", encoding="UTF-8", mode="w")
            for line in lines:
                # deal with the name lines
                if re.match(".*d:type=\"cDeltaString\">" + re.escape("GE: " + decal_to_rename[0] + "</"),line) != None:
                    line = line.replace("GE: " + self.old_decal,"GE: " + self.new_decal)

                # deal with the texture
                if re.match("^[ \t]+<TextureID d:type=\"cDeltaString\">" + re.escape(self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\[00]" + decal_to_rename[0]),line) != None:
                    line = line.replace("<TextureID d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\[00]" + self.old_decal,"<TextureID d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\[00]" + self.new_decal)
                output.write(line + "\n")
            output.close()

            # export decal back to bin
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                    self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml",
                                    "/bin:" + decal_to_rename[2]],
                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                    startupinfo=self.startupinfo)

            # remove temp xml decal file
            os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")

            # bin file
            old_file = decal_to_rename[2]
            new_file = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\" + decal_to_rename[1].replace(self.old_decal,self.new_decal)
            files_to_rename.append((old_file,new_file))
            # texture file
            texture_old = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\" + decal_to_rename[0] + ".TgPcDx"
            texture_new = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\aces\\" + decal_to_rename[0].replace(self.old_decal,self.new_decal) + ".TgPcDx"
            files_to_rename.append((texture_old,texture_new))

        if self.check_cancel():
            self.finish()
            return

        # now search for markers file for the decal set
        marker_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\"
        if os.path.isfile(marker_path + self.old_decal + ".bin"):
            self.parent.log_output("Renaming " + self.old_decal + " marker","Renaming " + self.old_decal + " marker")
            # first convert bin file to xml and change the texture entry
            # convert bin file to an xml file in the temp folder
            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                            marker_path + self.old_decal + ".bin",
                            "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + self.old_decal + "_marker.xml"],
                            stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                            startupinfo=self.startupinfo)

            # now we need to read in xml and correct it
            f = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + self.old_decal + "_marker.xml", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()

            data = data.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
            lines = data.split("\n")

            output = codecs.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + self.old_decal + "_marker.xml", encoding="UTF-8", mode="w")
            # loop through lines
            for line in lines:
                # deal with the name lines
                if re.match(".*d:type=\"cDeltaString\">" + re.escape("GE: " + decal_to_rename[0] + "</"),line) != None:
                    line = line.replace("GE: " + decal_to_rename[0],"GE: " + self.new_decal)

                # deal with csv reference
                if re.match("^[ \t]+<CsvFile d:type=\"cDeltaString\">" + re.escape(self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.old_decal),line) != None:
                    line = line.replace("<CsvFile d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.old_decal,"<CsvFile d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.new_decal)
                output.write(line + "\n")
            output.close()

            subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                self.parent.config["INSTALL_PATH"] + "\\temp\\" + self.old_decal + "_marker.xml",
                                "/bin:" + marker_path + self.old_decal + ".bin"],
                                stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                startupinfo=self.startupinfo)

            # parse the DCSV
            f = codecs.open(marker_path + "csv\\" + self.old_decal + ".dcsv", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()

            data = data.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
            lines = data.split("\n")

            output = codecs.open(marker_path + "csv\\" + self.old_decal + ".dcsv", encoding="UTF-8", mode="w")
            # loop through lines
            for line in lines:
                # deal with the name lines
                if re.match("^[ \t]+<Name d:type=\"cDeltaString\"> \d+ " + self.old_decal,line) != None:
                    line = line.replace(" " + self.old_decal + " "," " + self.new_decal + " ")

                # deal with csv reference
                if re.match("^[ \t]+<CsvFile d:type=\"cDeltaString\">" + re.escape(self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.old_decal),line) != None:
                    line = line.replace("<CsvFile d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.old_decal,"<CsvFile d:type=\"cDeltaString\">" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + self.parent.config["RW_MARKERS_PATH"] + "\\csv\\" + self.new_decal)
                output.write(line + "\n")
            output.close()

            marker_old = marker_path + self.old_decal + ".bin"
            marker_new = marker_path + self.new_decal + ".bin"
            files_to_rename.append((marker_old,marker_new))

            csv_old = marker_path + "csv\\" + self.old_decal + ".dcsv"
            csv_new = marker_path + "csv\\" + self.new_decal + ".dcsv"
            files_to_rename.append((csv_old,csv_new))

            
            os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + self.old_decal + "_marker.xml")

        # loop through files to rename and rename them
        for file_to_rename in files_to_rename:
            if self.check_cancel():
                self.finish()
                return
            shutil.move(file_to_rename[0],file_to_rename[1])


        ########################
        # still need to do the modifying of the route files to reflect decal renames
        if os.path.exists(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\Blueprints.pak"):
            self.parent.log_output("Removing Blueprint.pak")
            os.remove(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\Blueprints.pak")

        #<BlueprintID d:type="cDeltaString">environment\terrain\decals\renamed test decal 1 x1 y1.xml</BlueprintID>
        # now for each route we are going to update reload the cache
        for route_name in sorted(self.routes_to_search.iterkeys(),key=lambda x: x.lower()):
            if self.check_cancel():
                self.finish()
                return
            route_folder = self.routes_to_search[route_name]
            route_path = self.parent.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_folder  + "\\"
            used_decals = get_used_decals_spider(self, route_folder, route_path,False,True)
            # loop through each decal that needs renaming
            for decal_to_rename in decals_to_rename:
                if self.check_cancel():
                    self.finish()
                    return
                self.parent.log_output("Finding " + decal_to_rename[0] + " references in  " + route_name + " route","Finding " + decal_to_rename[0] + " references in  " + route_name + " route")
                if self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + decal_to_rename[1].lower() in used_decals: # is the bin file in the cache of tiles that contain the bin file
                    for tile in used_decals[self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + decal_to_rename[1].lower()]: # for each tile in the cache modify the entries
                        tile_parts = os.path.splitext(tile) # split filename into name + extension
                        # first convert bin file to xml and change the texture entry
                        # convert bin file to an xml file in the temp folder
                        subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                        route_path + "Scenery\\" + tile,
                                        "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml"],
                                        stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                        startupinfo=self.startupinfo)

                        # parse xml updating decals
                        bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml")
                        items = bin_xml.getElementsByTagName("cDynamicEntity")
                        for i in range(items.length): # loop through the routes
                            if items[i].getElementsByTagName("cDecalComponent").length == 1: # make sure it is a decal
                                provider = ""
                                try:
                                    provider = items[i].getElementsByTagName("Provider")[0].firstChild.data
                                except:
                                    pass
                                product = ""
                                try:
                                    product = items[i].getElementsByTagName("Product")[0].firstChild.data
                                except:
                                    pass

                                blueprint_id = ""
                                try:
                                    blueprint_id = items[i].getElementsByTagName("BlueprintID")[1].firstChild.data
                                except:
                                    pass
                                if provider == self.parent.config["DEVELOPER"] and product == self.parent.config["PRODUCT"] and blueprint_id == self.parent.config["RW_DECALS_PATH"].lower() + "\\" + re.sub("\.bin$",".xml",decal_to_rename[1].lower()):
                                    # correct file reference
                                    items[i].getElementsByTagName("iBlueprintLibrary-cAbsoluteBlueprintID")[0].removeChild(items[i].getElementsByTagName("BlueprintID")[1])
                                    new_blueprint = bin_xml.createElement("BlueprintID")  # creates <foo />
                                    new_blueprint.setAttribute("d:type", "cDeltaString")
                                    blueprint_value = bin_xml.createTextNode(self.parent.config["RW_DECALS_PATH"].lower() + "\\" + re.sub("^" + re.escape(self.old_decal.lower()),self.new_decal.lower(), decal_to_rename[0].lower(),1).lower() + ".xml")  # creates provider value
                                    new_blueprint.appendChild(blueprint_value)  # add value to provider
                                    items[i].getElementsByTagName("iBlueprintLibrary-cAbsoluteBlueprintID")[0].appendChild(new_blueprint)  # add decal

                                    # Correct name
                                    items[i].removeChild(items[i].getElementsByTagName("Name")[0])
                                    new_name = bin_xml.createElement("Name")  # creates <foo />
                                    new_name.setAttribute("d:type", "cDeltaString")
                                    name_value = bin_xml.createTextNode("GE: " + re.sub("^" + re.escape(self.old_decal), self.new_decal, decal_to_rename[0], 1))  # creates provider value
                                    new_name.appendChild(name_value)  # add value
                                    items[i].appendChild(new_name)  # add decal

                                    fp = codec.open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","w","UTF-8")
                                    bin_xml.writexml(fp, "", "", "", "UTF-8")
                                    fp.close()

                                    output = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","r").read()

                                    # remove any blank lines
                                    lines = output.split("\n")
                                    output = ""
                                    
                                    #Loop through lines to remove empty lines left by the removeChild call and correct self closing tags (serz errors)
                                    for line in lines:
                                        # correct closing tags on name nodes
                                        self_close = re.search("<[^>]+?/>",line)
                                        if self_close:
                                            if self_close.group(0).find(" ") == -1:
                                                item_end = self_close.group(0).find("/>")
                                            else:
                                                item_end = self_close.group(0).find(" ")
                                            item = self_close.group(0)[1:item_end]
                                            line = line.replace("/","") + "</" + item + ">"
                                            
                                        if len(line.strip()) == 0:
                                            continue;
                                        output += line + "\n"

                                    # save xml
                                    fp = open(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml","w")
                                    fp.write(output)
                                    fp.close()

                                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                                    self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml",
                                                    "/bin:" + route_path + "Scenery\\" + tile],
                                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                                    startupinfo=self.startupinfo)

                                    os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + tile_parts[0] + ".xml")

                    self.parent.log_output(decal_to_rename[0] + " reference found and corrected in " + used_decals[self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + decal_to_rename[1].lower()][0] + " tile",decal_to_rename[0] + " reference found and corrected in " + used_decals[self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\" + decal_to_rename[1].lower()][0] + " tile")
        
        # rename any decal references in the load markers data
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat","r")
            #Parse data string.
            try:
                self.marker_pairs = pickle.load(f)
            except:
                self.marker_pairs = {}
        else:
            self.marker_pairs = {}
                
        try:
            self.marker_pairs[self.new_decal] = self.marker_pairs[self.old_decal]
            del self.marker_pairs[self.old_decal]
        except:
            pass

        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat")
        # save data as pickled object
        data_file = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat","w")
        pickle.dump(self.marker_pairs, data_file)
        data_file.close()
        
        # update marker pairs combo
        self.parent.get_marker_pairs(True)
        

        # rename any decal references in the previous runs data
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\previous_runs.dat") == True:
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\previous_runs.dat","r")
            #Parse data string.
            try:
                self.previous_runs = pickle.load(f)
            except:
                self.previous_runs = {}
        else:
            self.previous_runs = {}
                
        try:
            self.previous_runs[self.new_decal] = self.previous_runs[self.old_decal]
            del self.previous_runs[self.old_decal]
        except:
            pass

        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\previous_runs.dat")
        # save data as pickled object
        data_file = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\previous_runs.dat","w")
        pickle.dump(self.previous_runs, data_file)
        data_file.close()

        # update previous runs combo
        self.parent.get_previous_runs(True)
        


        self.parent.error_handler(self.parent.lang["rename_decal_success"].replace("~~old_name~~",self.old_decal).replace("~~new_name~~",self.new_decal), self.parent.lang["rename_decal_success_title"])
        self.finish()
