import threading
import subprocess # calling other programs
import re
import os

class hide_decals(threading.Thread):
    def __init__(self, parent, wX, wY, decals_to_hide):
        self.parent = parent
        self.decals_to_hide = decals_to_hide
                        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self): # check if cancel has been clicked
        return

    def run(self):
        print "boo"
        for key in sorted(self.decals_to_hide.iterkeys(),key=lambda x: x.lower()):
            decal_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.decals_to_hide[key][0] + "\\" + self.decals_to_hide[key][1] + "\\" + re.sub(".xml$",".bin",self.decals_to_hide[key][2])
            decal_path_split = decal_path.split("\\")
            if os.path.exists(decal_path):
                os.rename(decal_path,re.sub(decal_path_split[len(decal_path_split)-1], re.sub("^GE: ","",key) + ".hidden", decal_path))
                self.parent.log_output(key + " decal hidden")

                # remove blueprints.pak file if exists
                if os.path.exists(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.decals_to_hide[key][0] + "\\" + self.decals_to_hide[key][1] + "\\Blueprints.pak") == True:
                    os.remove(self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + self.decals_to_hide[key][0] + "\\" + self.decals_to_hide[key][1] + "\\Blueprints.pak")
                          
        self.finish()
