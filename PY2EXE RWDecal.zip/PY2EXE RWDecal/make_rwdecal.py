from distutils.core import setup
import py2exe
import sys
sys.path.append(".\\modules")
setup(
    windows = [
        {
            "script": "RWDecal.py",
            "icon_resources": [(0,"rwdecal.ico")]
        }
    ],
    options =
        {
            "py2exe": { "dll_excludes": ["POWRPROF.dll"]}
        }
    #,
    #data_files = [ 
    #    ('',
    #         [
    #        'DLLs/msvcm90.dll',
    #        'DLLs/msvcp90.dll',
    #        'DLLs/msvcr90.dll',
    #        ],
    #    ),
    # ],
    )
