# -*- coding: cp1252 -*-
import os
import wx # GUI
import sys
import shutil
import ctypes # is user an admin
from win32api import CloseHandle, GetLastError # for single instance detection
from winerror import ERROR_ALREADY_EXISTS # for single instance detection
from win32event import CreateMutex # for single instance detection

app = wx.PySimpleApp()

def we_are_frozen():
    """Returns whether we are frozen via py2exe.
    This will affect how we find out where we are located."""

    return hasattr(sys, "frozen")


def module_path():
    """ This will get us the program's directory,
    even if we are frozen using py2exe"""

    if we_are_frozen():
        return os.path.dirname(unicode(sys.executable, sys.getfilesystemencoding( )))

    return os.path.dirname(unicode(__file__, sys.getfilesystemencoding( )))

INSTALL_PATH = module_path()

class single_instance:
    """ Limits application to single instance """

    def __init__(self):
        self.mutexname = "RWDecal"
        self.mutex = CreateMutex(None, False, self.mutexname)
        self.lasterror = GetLastError()
    
    def alreadyrunning(self):
        return (self.lasterror == ERROR_ALREADY_EXISTS)
        
# do this at beginnig of your application
myapp = single_instance()

if myapp.alreadyrunning():
    md = wx.MessageDialog(None,"RWDecal is already running!\n"\
                          "RWDecal k�rer allerede!\n"\
                          "RWDecal wordt al uitgevoerd!\n"\
                          "RWDecal est d�j� lanc�!\n"\
                          "RWDecal l�uft bereits!\n"\
                          "RWDecal � gi� in esecuzione!\n"\
                          "�RWDecal est� a�n en ejecuci�n!\n"\
                          "RWDecal k�rs redan!",
                          "RWDecal is already running!",wx.OK)
    result = md.ShowModal()
    sys.exit()

class main_window(wx.Frame):
    def __init__(self, parent, id, title):  
        wx.Frame.__init__(self, parent, wx.ID_ANY, title, wx.DefaultPosition, wx.Size(wX, wY), wx.MINIMIZE_BOX|wx.SYSTEM_MENU|wx.CAPTION|wx.CLOSE_BOX|wx.CLIP_CHILDREN|wx.WS_EX_PROCESS_UI_UPDATES)
        hspace = 4
        self.fW = wX - 5 - 22 - hspace # width used in form layout
        self.run()
        sys.exit()
        return

        

    def run(self):
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if ctypes.windll.shell32.IsUserAnAdmin() != True:
                md = wx.MessageDialog(None,"You do not appear to be using RWDecal as an Administrator. Please set RWDecal to run as an administrator or logon and use an account which is a member of the administrators group.\n\n"\
                                      "Det ser ikke ud som om du k�rer RWDecal som administrator. Indstil RWDecal til at k�re som administrator eller log p� en konto med administrator rettigheder.\n\n"\
                                      "U blijkt RWDecal niet te gebruiken met Administrator (Beheerder) rechten. Laat RWDecal uitvoeren als Administrator of meldt u aan als een gebruiker die lid is van de Administrator groep.\n\n"\
                                      "Vous n'utilisez pas RWDecal en mode administrateur. Configurez RWDecal pour que le programme soit �xecut� en mode administrateur ou connecter vous � un compte administrateur a.\n\n"\
                                      "Sie haben anscheinend keine Administratorenrechte. Bitte geben Sie RWDecal Administratorenrechte oder loggen Sie sich selbst mit drei Benutzeraccount ein, der Administratorenrechte besitzt\n\n"\
                                      "Sembra che tu non stia usando Decal come Amministratore. Avvia RWDecal come Amministratore o collegati ed una un account che faccia parte del gruppo dell'Amministratore.\n\n"\
                                      "Parece que no est� usando RWDecal como administrador. Por favor, ejecute RWDecal como administrador o use una cuenta como miembro de un grupo de administradores.\n\n"\
                                      "Du verkar inte anv�nda RWDecal som en administrat�r. V�nligen st�ll in RWDecal att k�ras som en adminstrat�r eller logga in p� ett anv�ndarkonto som �r medlem i en administrat�rsgrupp.",
                                      "RWDecal must be run as an Administrator",
                                      wx.OK | wx.ICON_EXCLAMATION)
                result = md.ShowModal()
                sys.exit()
                
            choose_lang = wx.Dialog(self, title="Press OK to Reset RWDecal", size=(750,220),style=wx.CAPTION)

            logo = wx.Image(INSTALL_PATH + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
            logo = wx.StaticBitmap(choose_lang, -1, logo, (10 + logo.GetWidth(), 5), (logo.GetWidth(), logo.GetHeight()))


            label = wx.StaticText(choose_lang, -1, "Press OK to reset all RWDecal settings back to defaults:\n"\
                                  "Tryk OK for at gendanne RWDecals standardindstillinger:\n"\
                                  "Druk op OK om alle instellingen van RWDecal terug te zetten naar de standaardwaarden:\n"\
                                  "Cliquez sur OK pour r�initialiser tous les param�tres par d�faut de RWDecal:\n"\
                                  "Klicken Sie auf OK um die Einstellungen von RWDecal zur�ckzusetzen:\n"\
                                  "Pulse Aceptar para volver a la configuraci�n por defecto de RWDecal:\n"\
                                  "Premere OK per riportare tutte le impostazioni di RWDecal ai valori di default.\n"\
                                  "Tryck OK f�r att �terst�lla alla RWDecal inst�llningar till standard",
                                  size=(550,-1),
                                  style=wx.ALIGN_CENTER)
            font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
            label.SetFont(font)

            buttons = choose_lang.CreateButtonSizer(wx.OK|wx.CANCEL)

            content_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
            content_sizer.Add(label, -1, wx.ALIGN_CENTER)
            content_sizer.Add(buttons, -1, wx.ALIGN_CENTER)
            
            choose_lang_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4,)
            choose_lang_sizer.AddMany([logo, content_sizer])
            
            choose_lang.SetSizer(choose_lang_sizer)

            if choose_lang.ShowModal() == wx.ID_OK:
                if os.path.exists(INSTALL_PATH + "\\settings\\assets_decals.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\assets_decals.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\assets_markers.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\assets_markers.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\config.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\config.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\ge_calibration.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\ge_calibration.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\ge_placemarks.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\ge_placemarks.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\last_settings.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\last_settings.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\source_decals.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\source_decals.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\source_markers.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\source_markers.dat")
                if os.path.exists(INSTALL_PATH + "\\settings\\previous_runs.dat"):
                    os.remove(INSTALL_PATH + "\\settings\\previous_runs.dat")
                    
                for f in os.listdir(INSTALL_PATH + "\\settings\\"):
                    if os.path.isdir(INSTALL_PATH + "\\settings\\" + f):
                        shutil.rmtree(INSTALL_PATH + "\\settings\\" + f)


            choose_lang.Destroy

# Frame dimensions
wX = 435
wY = 725

# border width
bW = 20

frame = main_window(None, -1, "RWDecal tool for RailWorks/RailSimulator by Nobkins")
frame.Show(True)
_icon = wx.Icon('rwdecal.ico', wx.BITMAP_TYPE_ICO)
frame.SetIcon(_icon)

app.MainLoop()

sys.exit()
