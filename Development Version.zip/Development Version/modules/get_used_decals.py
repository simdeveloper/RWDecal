import threading
import subprocess # calling other programs
import os
import wx # GUI
from xml.dom import minidom # xml parsing
import re # regular expression support
import time
import traceback
import pickle
from get_used_decals_spider import get_used_decals_spider # route cache generator

class get_used_decals(threading.Thread):
    def __init__(self, parent, wX, wY, call_after = "update_hide_checks"):
        self.parent = parent
        self.wX = wX
        self.wY = wY
        self.call_after = call_after
                        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self): # check if cancel has been clicked
        self.parent.gauge_panel.Show(False)
        return

    def run(self):
        try:
            used_decals = {}
            try:
                self.parent.bulk_select_panel.Show(False)
            except:
                pass
            
            #self.parent.check_boxes_sizer.Clear(True)
            if self.parent.route_choices_combo.GetCurrentSelection() == 0: # ignore first item
                wx.CallAfter(getattr(self.parent, self.call_after), used_decals)
                
            self.parent.route_folder = self.parent.route_details[self.parent.route_choices_combo.GetLabel()][2]
            self.parent.route_path = self.parent.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + self.parent.route_folder  + "\\"
            used_decals = get_used_decals_spider(self, self.parent.route_folder, self.parent.route_path)


            #evt = CountEvent(myEVT_COUNT, -1, used_decals)
            wx.CallAfter(getattr(self.parent, self.call_after), used_decals)
            self.parent.bulk_select_panel.Show(True)

            self.parent.gauge_panel.Show(False)
        except:
            self.parent.log_output(traceback.format_exc())
            pass

        return
