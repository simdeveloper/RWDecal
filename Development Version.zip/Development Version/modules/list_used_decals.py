import threading
import subprocess # calling other programs
import os
import wx # GUI
from xml.dom import minidom # xml parsing
#import re # regular expression support
#import time
import traceback
import pickle
import re # regular expression support
import time
from get_used_decals_spider import get_used_decals_spider # route cache generator

class list_used_decals(threading.Thread):
    def __init__(self, parent, route_name, route_folder, route_path, sets_only = False):
        self.parent = parent
        self.route_name = route_name
        self.route_folder = route_folder
        self.route_path = route_path
        self.sets_only = sets_only
                        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self):
        self.parent.lock_form("unlock")
        self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])

    def run(self):
        self.parent.lock_form("lock")
        self.parent.cancel_clicked = False
        
        status = self.parent.lang["transfer_decals_generate_cache"].replace("~~route~~",self.route_name).replace("~~number~~", "1").replace("~~number_max~~","1")
        self.parent.main_window_status.SetLabel(status)
        decal_list = get_used_decals_spider(self, self.route_folder, self.route_path,False,False,status)

        if self.sets_only == True:
            decal_sets = {}
            for decal in sorted(decal_list.iterkeys(),key=lambda x: x.lower()):
                decal_set = re.sub("X\d+ Y\d+$","",decal).strip()
                decal_set = re.sub("^GE: ","",decal_set).strip()
                if decal_set not in decal_sets:
                    decal_sets[decal_set] = 1
                else:
                    decal_sets[decal_set] = decal_sets[decal_set] + 1
            decal_list = decal_sets
        wx.CallAfter(self.parent.decals_to_csv, self.route_name, self.sets_only, decal_list)
        self.finish()
        return
