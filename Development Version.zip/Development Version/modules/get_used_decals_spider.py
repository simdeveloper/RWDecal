import subprocess # calling other programs
import os
from xml.dom import minidom # xml parsing
import re # regular expression support
import traceback
import pickle

                        
def get_used_decals_spider(self, route_folder, route_path, do_guage = True, return_tile_cache = False,update_status = False):
    try:
        used_decals = {}
        tile_cache = {}

        # get a list of all decals used in a route
        if not os.path.exists(route_path + "Scenery\\"):
            return
     
        bin_files = os.listdir(route_path + "Scenery\\")
        confirmed_bins = list()
        
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        for bin_file in bin_files: # loop through files
            bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
            if bin_file_parts[1] == ".bin": # make sure is a bin file
                confirmed_bins.append(bin_file)
        num_bin = 0

        # load scenery cache
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\cache\\decals_used_in_routes\\" + route_folder + ".dat"):
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\cache\\decals_used_in_routes\\" + route_folder + ".dat","r")
            #Parse data string.
            try:
                bin_mod_cache = pickle.load(f)
            except:
                bin_mod_cache = {}
        else:
            bin_mod_cache = {}

        for cache_bin in bin_mod_cache:
            if cache_bin not in confirmed_bins:
                bin_mod_cache[cache_bin] = {}
                self.parent.log_output(cache_bin + " removed from cache as no longer exists")

        if len(confirmed_bins) > 0:
            if do_guage:
                self.parent.gauge.SetValue(0)
                self.parent.gauge.SetRange(len(confirmed_bins))
                self.parent.gauge_panel.Show(True)
            i2 = 1
            for bin_file in confirmed_bins: # loop through files
                try:
                    if self.parent.cancel_clicked:
                        return False
                except:
                    pass
                if update_status != False:
                    self.parent.log_output(update_status + "\n\n" + bin_file + " (" + str(round(100.0/len(confirmed_bins)*i2,1)) + "%)",update_status + "\n\n" + bin_file + " (" + str(round(100.0/len(confirmed_bins)*i2,1)) + "%)")
                i2 = i2 + 1
                bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension

                
                bin_mod_time = os.path.getmtime(route_path + "Scenery\\" + bin_file)
                if bin_file in bin_mod_cache and "mtime" in bin_mod_cache[bin_file] and (bin_mod_time == bin_mod_cache[bin_file]["mtime"] or return_tile_cache): # has scenery changed
                    self.parent.log_output(bin_file + " loading from cache as modified time not changed")
                    if "used_decals" in bin_mod_cache[bin_file]:
                        for key in bin_mod_cache[bin_file]["used_decals"]: # no change so load from cache
                            used_decals[key] = bin_mod_cache[bin_file]["used_decals"][key]
                            provider = used_decals[key][0]
                            product = used_decals[key][1]
                            decal_blueprint = used_decals[key][2]
                            decal_name = used_decals[key][4]
                            file_name = used_decals[key][5]
                            decal_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + provider + "\\" + product + "\\" + re.sub(".xml$",".bin",decal_blueprint)

                            # check to see if files have changed their hidden status
                            if os.path.exists(decal_path): # exists
                                used_decals[key] = (provider, product, decal_blueprint, True, decal_name, file_name, bin_file)
                            elif os.path.exists(re.sub(".bin$",".hidden",decal_path)):
                                 used_decals[key] = (provider, product, decal_blueprint, False, decal_name, file_name, bin_file)

                            bin_mod_cache[bin_file]["used_decals"][key] = used_decals[key]
                            if provider + "\\" + product + "\\" + file_name not in tile_cache: # initialise tilecache for decal if not exist
                                tile_cache[provider + "\\" + product + "\\" + file_name] = list()
                            if bin_file not in tile_cache[provider + "\\" + product + "\\" + file_name]: # add entry to decal tile cache if this tile not in the cache
                                tile_cache[provider + "\\" + product + "\\" + file_name].append(bin_file)
                    if do_guage:
                        self.parent.gauge.SetValue(self.parent.gauge.GetValue() + 1)
                    continue

                # scenery changed so need to refresh cache
                bin_mod_cache[bin_file] = {}
                bin_mod_cache.setdefault(bin_file,{})["mtime"] = bin_mod_time

                self.parent.log_output(bin_file + " no cache or out of date so generating it")

                self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
                # convert bin file to an xml file in the temp folder
                subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                route_path + "Scenery\\" + bin_file,
                                "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                                stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                startupinfo=self.startupinfo)

                # parse xml finding decals
                bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
                items = bin_xml.getElementsByTagName("cDynamicEntity")
                for i in range(items.length): # loop through the routes
                    if items[i].getElementsByTagName("cDecalComponent").length == 1: # make sure it is a decal
                        decal_name = ""
                        try:
                            decal_name = items[i].getElementsByTagName("Name")[0].firstChild.data
                        except:
                            pass
                        if re.match("^GE: .*$",decal_name) != None:
                            try:
                                provider = items[i].getElementsByTagName("Provider")[0].firstChild.data
                                product = items[i].getElementsByTagName("Product")[0].firstChild.data
                                decal_blueprint = items[i].getElementsByTagName("BlueprintID")[1].firstChild.data
                                decal_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\" + provider + "\\" + product + "\\" + re.sub(".xml$",".bin",decal_blueprint)
                                file_name = os.path.basename(decal_path)
                                if os.path.exists(decal_path): # exists
                                    used_decals[decal_name] = (provider, product, decal_blueprint, True, decal_name, file_name, bin_file)
                                elif os.path.exists(re.sub(".bin$",".hidden",decal_path)):
                                    used_decals[decal_name] = (provider, product, decal_blueprint, False, decal_name, file_name, bin_file)
                                bin_mod_cache[bin_file].setdefault("used_decals",{})[decal_name] = used_decals[decal_name]
                                
                                if provider + "\\" + product + "\\" + file_name not in tile_cache: # initialise tilecache for decal if not exist
                                    tile_cache[provider + "\\" + product + "\\" + file_name] = list()
                                if bin_file not in tile_cache[provider + "\\" + product + "\\" + file_name]: # add entry to decal tile cache if this tile not in the cache
                                    tile_cache[provider + "\\" + product + "\\" + file_name].append(bin_file)
                            except:
                                pass
                # remove xml file
                os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")

                if do_guage:
                    try:
                        self.parent.gauge.SetValue(self.parent.gauge.GetValue() + 1)
                    except:
                        pass

        # save data as pickled object
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\settings\\cache\\decals_used_in_routes\\")
        f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\cache\\decals_used_in_routes\\" + route_folder + ".dat", "w")
        pickle.dump(bin_mod_cache, f)
        f.close()

        if return_tile_cache:
            return tile_cache
        else:
            return used_decals

    except:
        self.parent.log_output(traceback.format_exc(),traceback.format_exc())
        pass

    return
