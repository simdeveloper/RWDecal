import threading
import subprocess # calling other programs
import os
import wx # GUI
from xml.dom import minidom # xml parsing
#import re # regular expression support
#import time
import traceback
import pickle
import re # regular expression support
import time

class list_products(threading.Thread):
    def __init__(self, parent):
        self.parent = parent
                        
        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = subprocess.SW_HIDE 
        threading.Thread.__init__(self)

    def finish(self): # check if cancel has been clicked
        self.parent.gauge_panel.Show(False)
        return

    def list_decals(self,decal_path):
        decal_list = list()
        
        if not os.path.isdir(decal_path):
            return decal_list
        
        # get a list of all decals used in a route
        bin_files = os.listdir(decal_path)
      
        self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
        max_len = 0
        for bin_file in bin_files: # loop through files
            bin_file_parts = os.path.splitext(bin_file) # split filename into name + extension
            if bin_file_parts[1] == ".bin": # make sure is a bin file
                if re.match(".*X\d+ Y\d+\.bin$",bin_file) != None: # is chunk so add to list
                    decal_list.append(bin_file_parts[0])
                        
                else: # not a chunk so must decode bin and check if we have a naem starting with GE:
                    # convert bin file to an xml file in the temp folder
                    self.parent.check_path_exists(self.parent.config["INSTALL_PATH"] + "\\temp\\")
                    subprocess.call([self.parent.config["RAILWORKS_PATH"] + "\\serz.exe",
                                    decal_path.rstrip("\\") + "\\" + bin_file,
                                    "/xml:" + self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml"],
                                    stdout=open(self.parent.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
                                    startupinfo=self.startupinfo)
                    
                    # parse xml finding decals
                    bin_xml = minidom.parse(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
                    items = bin_xml.getElementsByTagName("Name")
                    try:
                        decal_name = items[0].firstChild.data
                    except:
                            pass
                    if re.match("^GE: .*$",decal_name) != None:
                            decal_list.append(decal_name)
                                    
                    # remove xml file
                    os.remove(self.parent.config["INSTALL_PATH"] + "\\temp\\" + bin_file_parts[0] + ".xml")
        return decal_list
 

    def run(self):    
        product_list = {}
            
        asset_path = self.parent.config["RAILWORKS_PATH"] + "\\Assets\\"
        
        # get a list of all decals used in a route
        developers = os.listdir(asset_path)

        self.parent.gauge.SetValue(0)
        self.parent.gauge.SetRange(len(developers))
        self.parent.gauge.Show(True)

        for developer in developers: # loop through developer folders
            if os.path.isdir(asset_path + developer): # make sure is a folder
                products = os.listdir(asset_path + developer + "\\")
                for product in products: # loop through product folders
                    num_decals = 0
                    if os.path.isdir(asset_path + developer + "\\" + product):# make sure is a folder
                        num_decals = self.list_decals(asset_path + developer + "\\" + product + "\\" + self.parent.config["RW_DECALS_PATH"] + "\\")
                        product_list[developer + "\\" + product] = len(num_decals)
                        
            self.parent.gauge.SetValue(self.parent.gauge.GetValue() + 1)

        self.parent.gauge.Show(False)
        wx.CallAfter(self.parent.update_product_list, product_list)

        return
                     
