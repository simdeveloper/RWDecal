import threading
import pythoncom
import win32com.client
import win32gui
import win32con
import os
import time
import pickle
import codecs
import traceback
from ltm_to_utm import LLplus # calc box size

class grab_location(threading.Thread):
    def __init__(self,parent):
        self.parent = parent
        threading.Thread.__init__(self)

    def check_for_cancel(self): # check if cancel has been clicked
        if self.parent.cancel_clicked == True: # if files exists break loop
            try:
                self.parent.get_marker_pairs(True) # update mrker pairs list
                self.parent.lock_form("unlock")
                self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])
                self.parent.evt_validate_form("")
                self.parent.rw_status_window.Destroy()
                
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
                return True
            except:
                return True
        return False

##    def places_callback(self,place):
##        try:
##            places = place.GetChildren()
##            for item in places:
##                try:
##                    if self.places_callback(item):
##                        return True
##                    if item.Name == "RWDecal Objects":
##                        item.Visibility = True
##                        return True
##                except:
##                    if item.Name == "RWDecal Objects":
##                        item.Visibility = True
##                        return True
##        except:
##            if place.Name == "RWDecal Objects":
##                item.Visibility = True
##                return True
##        return False

    def get_camera_start(self):
        if int(self.parent.form_settings["ALTITUDE"]) > 19:
            alt = int(float(self.parent.altitude_options[int(self.parent.form_settings["ALTITUDE"])].rstrip("km")) * 1000)
        else:
            alt = int(self.parent.altitude_options[int(self.parent.form_settings["ALTITUDE"])].rstrip("m"))
        if self.parent.grab_latitude == "" and self.parent.grab_longitude == "":
            return (alt,self.parent.grab_latitude,self.parent.grab_longitude,alt,False)
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat", "r")
            #Parse data string.
            try:
                ge_placemarks = pickle.load(f)
            except:
                ge_placemarks = {}
        else:
            self.parent.log_output("ge_calibration.dat file missing")
            ge_placemarks = {}

        if self.parent.form_settings["DECAL_NAME"] in ge_placemarks:
            if type(self.parent.start_corner) is str and self.parent.start_corner.upper() in ge_placemarks[self.parent.form_settings["DECAL_NAME"]]:
                value = ge_placemarks[self.parent.form_settings["DECAL_NAME"]][self.parent.start_corner.upper()]
                if "ALTITUDE" in ge_placemarks[self.parent.form_settings["DECAL_NAME"]]:
                    alt = int(ge_placemarks[self.parent.form_settings["DECAL_NAME"]]["ALTITUDE"]) # get altitude
                    self.parent.grab_altitude_choice.SetSelection(alt) # set altitude combo value (grab_status)
                    self.parent.altitude_choice.SetSelection(alt) # set altitude combo value (main_gui)
                    if int(alt) > 19:
                        try:
                            alt = int(float(self.parent.altitude_options[int(alt)].rstrip("km")) * 1000)
                        except:
                            alt = int(float(self.parent.altitude_options[7].rstrip("m")) * 1000)
                    else:
                        alt = int(self.parent.altitude_options[int(alt)].rstrip("m"))
                return (value[2],value[0],value[1],alt,True)
            else:
                return (alt,self.parent.grab_latitude,self.parent.grab_longitude,alt,True)
        else:
            return (alt,self.parent.grab_latitude,self.parent.grab_longitude,alt,True)
    
    def create_placemark(self,refresh = False, box = False):
        # check if network link already loaded
        rw_kml = self.ge.GetFeatureByName("RWDecal Objects")
        if rw_kml != None:
            rw_kml.Visibility = True
        else: # load kml
            self.ge.OpenKmlFile(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks_link.kml",True)
        
        # first grab camera position (center screen)
        camera_pos = self.ge.GetCamera(True)

        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat", "r")
            ge_placemarks = pickle.load(f)

        else:
            ge_placemarks = {}


        if refresh == False:
            # set altitude
            ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["ALTITUDE"] = int(self.parent.form_settings["ALTITUDE"])
            if box != False: #using box method so we need to calc the LL and UR from what ever corner chosen
                # get size of box
                if int(self.parent.config["BOX_SIZE"]) > 9:
                    box_size = int(float(self.parent.box_options[int(self.parent.config["BOX_SIZE"])].rstrip("km")) * 1000)
                else:
                    box_size = int(float(self.parent.box_options[int(self.parent.config["BOX_SIZE"])].rstrip("m")))
                if self.parent.box_name == "LL":
                    new = LLplus(self,camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,box_size)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["LL"] = camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,camera_pos.Range
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["UR"] = new[0],new[1],camera_pos.Range
                elif self.parent.box_name == "UL":
                    new = LLplus(self,camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,box_size*-1)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["LL"] = new[0],camera_pos.FocusPointLongitude,camera_pos.Range
                    new = LLplus(self,new[0],camera_pos.FocusPointLongitude,box_size)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["UR"] = camera_pos.FocusPointLatitude,new[1],camera_pos.Range                    
                elif self.parent.box_name == "LR":
                    new = LLplus(self,camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,box_size*-1)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["LL"] = camera_pos.FocusPointLatitude,new[1],camera_pos.Range
                    new = LLplus(self,camera_pos.FocusPointLatitude,new[1],box_size)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["UR"] = new[0],camera_pos.FocusPointLongitude,camera_pos.Range
                    
                elif self.parent.box_name == "UR":
                    new = LLplus(self,camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,box_size*-1)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["UR"] = camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,camera_pos.Range
                    new1 = LLplus(self,new[0],camera_pos.FocusPointLongitude,box_size*-1)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["LL"] = new[0],new1[1],camera_pos.Range

                elif self.parent.box_name == "MID":
                    new = LLplus(self,camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,(box_size/2)*-1)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["LL"] = new[0],new[1],camera_pos.Range
                    new = LLplus(self,new[0],new[1],box_size)
                    ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})["UR"] = new[0],new[1],camera_pos.Range

                    
            else:                
                # add this marker to placemark dictionary (overwrites if it exists already)
                ge_placemarks.setdefault(self.parent.form_settings["DECAL_NAME"],{})[self.parent.marker_name] = camera_pos.FocusPointLatitude,camera_pos.FocusPointLongitude,camera_pos.Range

            
        # create missing two corners just for sake of it
        for key in sorted(ge_placemarks.iterkeys(),key=lambda x: x.lower()):
            if "LL" in ge_placemarks[key] and "UR" in ge_placemarks[key]: # have both LL and UR so create UL and LR
                if eval(self.parent.config["CENTER_4CORNERMARKERS"]):
                    ge_placemarks.setdefault(key,{})["LR"] = ge_placemarks[key]["LL"][0],ge_placemarks[key]["UR"][1],camera_pos.Range
                    ge_placemarks.setdefault(key,{})["UL"] = ge_placemarks[key]["UR"][0],ge_placemarks[key]["LL"][1],camera_pos.Range
                else:
                    if "LR" in ge_placemarks[key]:
                        del ge_placemarks[key]["LR"]
                    if "UL" in ge_placemarks[key]:
                        del ge_placemarks[key]["UL"]
                if eval(self.parent.config["CENTER_MARKERS"]):
                    ge_placemarks.setdefault(key,{})["C"] = ge_placemarks[key]["LL"][0] + ((ge_placemarks[key]["UR"][0] - ge_placemarks[key]["LL"][0]) / 2),ge_placemarks[key]["LL"][1] + ((ge_placemarks[key]["UR"][1] - ge_placemarks[key]["LL"][1]) / 2),camera_pos.Range
                elif "C" in ge_placemarks[key]:
                    if "C" in ge_placemarks[key]:
                        del ge_placemarks[key]["C"]
                

        # save data as pickled object
        data_file = open(self.parent.config["INSTALL_PATH"] + "\\settings\\" + self.parent.config["DEVELOPER"] + "\\" + self.parent.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
        pickle.dump(ge_placemarks, data_file)
        data_file.close()

        # get header and footer for KML
        template_kml_header = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\kml_header.kml",encoding="UTF-8", mode='r').read()
        template_kml_footer = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\kml_footer.kml",encoding="UTF-8", mode='r').read()

        # get footer for placemark folders
        template_placemark_folder_footer = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\placemark_folder_footer.kml", encoding="UTF-8", mode='r').read()

        # get header and footer for placemarks
        template_placemark_header = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\placemark_header.kml", encoding="UTF-8", mode='r').read()
        template_placemark_footer = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\placemark_footer.kml", encoding="UTF-8", mode='r').read()

        # get header and footer for polygons
        template_polygon_header = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\polygon_header.kml", encoding="UTF-8", mode='r').read()
        template_polygon_footer = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\polygon_footer.kml", encoding="UTF-8", mode='r').read()
        
        new_kml = codecs.open(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml",encoding='UTF-8',mode='w') #open for append
        new_kml.write(template_kml_header) # add kml header
        new_kml.write(template_placemark_header) # add placemark header
        for key in sorted(ge_placemarks.iterkeys(),key=lambda x: x.lower()):
            # folder names for placemarks
            template_placemark_folder_header = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\placemark_folder_header.kml", encoding="UTF-8", mode='r')
            for line in template_placemark_folder_header:
                line = line.replace("~~PLACEMARK_NAME~~",key)
                new_kml.write(line)
            for corner in sorted(ge_placemarks[key].iterkeys(),key=lambda x: x.lower()): # each corner placemark
                if corner == "ALTITUDE" or corner == "AUTO" or corner == "AUTO_SET_NAME":
                    continue
                value = eval(str(ge_placemarks[key][corner]))
                template_body = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\placemark_body.kml",encoding='UTF-8',mode='r')
                for line in template_body:
                    line = line.replace("~~PLACEMARK_NAME~~",key + " " + self.parent.lang[corner.lower()])
                    line = line.replace("~~LATITUDE~~",str(value[0]))
                    line = line.replace("~~LONGITUDE~~",str(value[1]))
                    line = line.replace("~~ALTITUDE~~",str(value[2]))
                    new_kml.write(line)
            new_kml.write(template_placemark_folder_footer) # add placemark folder footer
        new_kml.write(template_placemark_footer) # add placemark footer


        # sort out polygons
        if eval(self.parent.config["CREATE_GE_POLYGONS"]):
            new_kml.write(template_polygon_header) # add polygon header
            for key in sorted(ge_placemarks.iterkeys(),key=lambda x: x.lower()):
                # check to see if we have a pair of LL and UR so we can make polygon
                if "LL" in ge_placemarks[key] and "UR" in ge_placemarks[key]:
                    value_ll = eval(str(ge_placemarks[key]["LL"]))
                    value_ur = eval(str(ge_placemarks[key]["UR"]))
                    template_body = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\polygon_body.kml", encoding="UTF-8", mode='r')
                    for line in template_body:
                        line = line.replace("~~PLACEMARK_NAME~~",key + " Polygon")
                        line = line.replace("~~LATITUDE_UL~~",str(value_ur[0]))
                        line = line.replace("~~LATITUDE_UR~~",str(value_ur[0]))
                        line = line.replace("~~LATITUDE_LR~~",str(value_ll[0]))
                        line = line.replace("~~LATITUDE_LL~~",str(value_ll[0]))
                        line = line.replace("~~LONGITUDE_UL~~",str(value_ll[1]))
                        line = line.replace("~~LONGITUDE_UR~~",str(value_ur[1]))
                        line = line.replace("~~LONGITUDE_LR~~",str(value_ur[1]))
                        line = line.replace("~~LONGITUDE_LL~~",str(value_ll[1]))
                        new_kml.write(line)
            new_kml.write(template_polygon_footer) # add polygon header
                
        new_kml.write(template_kml_footer) # add kml footer
        new_kml.close()

        self.parent.set_placemark = False
        self.parent.set_box = False
        self.parent.log_output("Successfully created placemark")

    def check_camera_pos(self,alt,lat,lon, max_coord_deviation = 0.0001, log = True):
        if log == True:
            self.parent.log_output("Checking camera position .  .  .",self.parent.lang["log_cameraposition"])
        while True: # make sure camera is where it is meant to be
            if self.check_for_cancel():
                return False
            camera_pos = self.ge.GetCamera(True)
            # check if camera deviates from required pos by more than allowed margin
            if round(camera_pos.Range,2) != round(float(alt),2) or (float(lat) - camera_pos.FocusPointLatitude > max_coord_deviation or camera_pos.FocusPointLatitude - float(lat) > max_coord_deviation) or (float(lon) - camera_pos.FocusPointLongitude > max_coord_deviation or camera_pos.FocusPointLongitude - float(lon) > max_coord_deviation) :
                time.sleep(0.1)
                new_camera_pos = self.ge.GetCamera(True)
                # check if camera is stationary. If it is then set new camera location as camera not moving but still not in right place
                if new_camera_pos.Range == camera_pos.Range and new_camera_pos.FocusPointLatitude == camera_pos.FocusPointLatitude and new_camera_pos.FocusPointLongitude == camera_pos.FocusPointLongitude:
                    self.ge.SetCameraParams (lat, lon, alt, 1, 0, 0, 0, self.speed)
            else:
                if int(self.speed) == 5:
                    time.sleep(0.1)
                break
        return True

    def check_camera_moving(self):
        while True:
            camera_pos = self.ge.GetCamera(True)
            time.sleep(0.1)
            new_camera_pos = self.ge.GetCamera(True)
            if new_camera_pos.Range == camera_pos.Range and new_camera_pos.FocusPointLatitude == camera_pos.FocusPointLatitude and new_camera_pos.FocusPointLongitude == camera_pos.FocusPointLongitude:
                return True
        return False

    def configure_layers(self):
        try:
            self.ge.ElevationExaggeration = float(0)
        except:
            pass
        configured = False
        while configured == False:
            if self.check_for_cancel():
                return False
            try:
                primary_database = self.ge.GetLayersDatabases()
                for features in primary_database:
                    layers = features.GetChildren()
                    for layer in layers:
                        if self.check_for_cancel():
                            return False
                        if eval(self.parent.config["DISABLE_ALL_GE_LAYERS"]) == True or layer.name == "Terrain" or layer.name == "3D Buildings":
                            layer.Visibility = False
                configured = True
            except:
                pass
        return True

    def basic_kml(self): # create the basic kml if it does not exist
        if os.path.exists(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml") != True:
            # get header and footer for KML
            template_kml_header = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\kml_header.kml", encoding="UTF-8", mode='r').read()
            template_kml_footer = codecs.open(self.parent.config["INSTALL_PATH"] + "\\templates\\googleearth\\kml_footer.kml", encoding="UTF-8", mode='r').read()
            
            new_kml = codecs.open(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml", encoding="UTF-8", mode='w') #open for append
            new_kml.write(template_kml_header) # add kml header
            new_kml.write(template_placemark_footer) # add placemark footer
            new_kml.close
        return

    def run(self):
        try:
            pythoncom.CoInitialize()
            self.ge = win32com.client.Dispatch("GoogleEarth.ApplicationGE")
            self.parent.log_output("Google Earth initialising .  .  .",self.parent.lang["log_geinitialise"])
     
            while not self.ge.IsInitialized():
                if self.check_for_cancel():
                    return
                time.sleep(0.1)

            # turn off terrain and 3D Buildings
            primary_database = self.ge.GetLayersDatabases()
            if self.configure_layers() != True:
                return
            
            # make ge always on top and positioned right
            self.ge_window = win32gui.FindWindow("QWidget","Google Earth")
            win32gui.ShowWindow(self.ge_window, win32con.SW_MAXIMIZE)
            win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOPMOST, 0,0,0,0,
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
            main_window_pos = win32gui.GetWindowRect(self.ge_window)
            win32gui.ShowWindow(self.ge_window, win32con.SW_RESTORE)
            win32gui.SetWindowPos(self.ge_window, win32con.HWND_TOP, 0,100,self.parent.screen_width,main_window_pos[3] + main_window_pos[1] - 100, win32con.SWP_FRAMECHANGED)

            # make status always on top
            rw_window = win32gui.FindWindow("wxWindowClassNR",self.parent.lang["status_window_title"])
            win32gui.SetWindowPos(rw_window, win32con.HWND_TOPMOST, 0,0,0,0,
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)

            
            self.speed = 5

            camera_start = self.get_camera_start()

            if camera_start[4]:
                if self.check_camera_pos(camera_start[0],camera_start[1],camera_start[2], 0.0001, False) != True:
                    return

            self.altitude = camera_start[3]

            self.create_placemark(True) # refresh KML file

            self.parent.log_output("Centre on a location and click a \"Grab\" button",self.parent.lang["log_grabcentre"])

            # enable buttons
            self.parent.set_UR_placemark.Enable(True)
            self.parent.go_UR_placemark.Enable(True)
            self.parent.grab_UR.Enable(True)
            self.parent.grab_current_UR.Enable(True)
            self.parent.set_LL_placemark.Enable(True)
            self.parent.go_LL_placemark.Enable(True)
            self.parent.grab_LL.Enable(True)
            self.parent.grab_current_LL.Enable(True)
            self.parent.box_LL.Enable(True)
            self.parent.box_LR.Enable(True)
            self.parent.box_UR.Enable(True)
            self.parent.box_UL.Enable(True)
            self.parent.box_MID.Enable(True)
            

            # check if network link already loaded
            rw_kml = self.ge.GetFeatureByName("RWDecal Objects")
            if rw_kml != None:
                rw_kml.Visibility = True
            else: # load kml
                self.ge.OpenKmlFile(self.parent.config["INSTALL_PATH"] + "\\settings\\ge_placemarks_link.kml",True)

            while True:
                time.sleep(0.1)
                if self.parent.go_placemark == True: # goto placemark
                    # get placemark using href
                    placemark = self.ge.GetFeatureByHref(self.parent.go_href)
                    if placemark != None and placemark.HasView:
                        self.ge.SetFeatureView(placemark,4.0)
                    self.parent.go_placemark = False
                    self.parent.log_output("Successfully went to placemark")
                    win32gui.SetForegroundWindow(self.ge_window) # make ge active

                    
                elif self.parent.set_placemark == True: # create a placemark
                    self.create_placemark()
                    win32gui.SetForegroundWindow(self.ge_window) # make ge active

                elif self.parent.set_box == True: # create a placemark
                    self.create_placemark(False,True)
                    win32gui.SetForegroundWindow(self.ge_window) # make ge active
                    
                elif self.parent.grab_now == True: # grab a placemark
                    if self.parent.grab_move == True: # move camera to placemark before doing a grab
                        # get placemark using href
                        placemark = self.ge.GetFeatureByHref(self.parent.go_href)
                        if placemark != None and placemark.HasView:
                            self.ge.SetFeatureView(placemark,4.0)

                        self.check_camera_moving()


                    camera_pos = self.ge.GetCamera(True)
                    if self.parent.grab_name == "LL":
                        self.parent.latLL_text.SetLabel(str(camera_pos.FocusPointLatitude))
                        self.parent.lonLL_text.SetLabel(str(camera_pos.FocusPointLongitude))
                        if eval(self.parent.config["GRAB_WARNINGS"]):
                            self.parent.error_handler(self.parent.lang["message_grabsuccessll"].replace("~~name~~",str(self.parent.form_settings["DECAL_NAME"])),
                                                      self.parent.lang["message_grabsuccessll_title"])
                        win32gui.SetForegroundWindow(self.ge_window) # make ge active
                    else:
                        self.parent.latUR_text.SetLabel(str(camera_pos.FocusPointLatitude))
                        self.parent.lonUR_text.SetLabel(str(camera_pos.FocusPointLongitude))
                        if eval(self.parent.config["GRAB_WARNINGS"]):
                            self.parent.error_handler(self.parent.lang["message_grabsuccessur"].replace("~~name~~",str(self.parent.form_settings["DECAL_NAME"])),
                                                      self.parent.lang["message_grabsuccessur_title"])
                        win32gui.SetForegroundWindow(self.ge_window) # make ge active

                    if self.parent.grab_move == False:
                        self.parent.log_output("Successfully Grabbed Current to " + self.parent.lang[self.parent.grab_name.lower()])
                    else:
                        self.parent.log_output("Successfully Grabbed " + self.parent.lang[self.parent.grab_name.lower()] + " Placemark")
                    
                    self.parent.grab_now = False # no more grab
                    self.parent.grab_move = False # no more camera move

                    # re-enable buttons
                    self.parent.grab_LL.Enable(True)
                    self.parent.grab_UR.Enable(True)
                    self.parent.grab_current_LL.Enable(True)
                    self.parent.grab_current_UR.Enable(True)
                    self.parent.set_LL_placemark.Enable(True)
                    self.parent.set_UR_placemark.Enable(True)
                    self.parent.go_LL_placemark.Enable(True)
                    self.parent.go_UR_placemark.Enable(True)
                if self.check_for_cancel() == True:
                    return
        except:
            self.parent.log_output(traceback.format_exc())
            try:
                self.parent.rw_status_window.Destroy()
                # minimize google earth
                win32gui.SetWindowPos(self.ge_window, win32con.HWND_NOTOPMOST, 0,0,0,0,win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                win32gui.ShowWindow(self.ge_window, win32con.SW_MINIMIZE)
            except:
                pass
        
            self.parent.error_handler(self.parent.lang["message_fatalexception"],
                                      self.parent.lang["message_fatalexception_title"])

            self.parent.lock_form("unlock")
            self.parent.main_window_status.SetLabel(self.parent.lang["status_ready"])
