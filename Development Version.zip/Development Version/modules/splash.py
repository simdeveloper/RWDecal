import wx
import Image # image manipulation
import ImageDraw
import ImageFont

class splash(wx.SplashScreen):
    def __init__(self, parent, overlay_text = "", duration=2000):
        image_file = 'splash'
        image = Image.open(parent.config["INSTALL_PATH"] + "\\images\\" + image_file + ".jpg")
        image_size = image.getbbox()

        font = ImageFont.truetype("arial.ttf", 15)

        text = ImageDraw.Draw(image)
        text_size = text.textsize(overlay_text,font)
        text.text((image_size[2]-text_size[0], image_size[3]-text_size[1]), overlay_text,  font=font, fill=(255,255,255))
        image.save(parent.config["INSTALL_PATH"] + "\\images\\" +image_file + "_user.jpg")

        bmp = wx.Bitmap(parent.config["INSTALL_PATH"] + "\\images\\" +image_file + "_user.jpg")
        # covers the parent frame
        wx.SplashScreen(bmp, wx.SPLASH_CENTRE_ON_SCREEN|wx.SPLASH_TIMEOUT,
            duration, parent, wx.ID_ANY)
