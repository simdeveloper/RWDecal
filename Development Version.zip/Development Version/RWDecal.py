# -*- coding: cp1252 -*-
import wx # GUI
from wx.lib.buttons import GenBitmapTextButton # image based buttons
import wx.lib.scrolledpanel # scrolling panel (debug)
import time
import os
import sys
import datetime
import re # regular expression support
import hashlib # license decode (md5)
import math
import cmath
import ctypes # is user an admin
import subprocess # calling other programs
import _subprocess
import urllib # update checking etc
import urllib2 # update checking etc
import random # generate random number - update check avoid cachingimport webbrowser
import pickle
import traceback
from win32api import CloseHandle, GetLastError # for single instance detection
from winerror import ERROR_ALREADY_EXISTS # for single instance detection
from win32event import CreateMutex # for single instance dtection
from win32api import GetSystemMetrics # get screen size etc
import shutil
from xml.dom import minidom # xml parsing
import codecs # unicode file handling
import win32com.client
import zipfile
import glob
import webbrowser
from elementtree import ElementTree

 
def we_are_frozen():
    """Returns whether we are frozen via py2exe.
    This will affect how we find out where we are located."""

    return hasattr(sys, "frozen")


def module_path():
    """ This will get us the program's directory,
    even if we are frozen using py2exe"""

    if we_are_frozen():
        return os.path.dirname(unicode(sys.executable, sys.getfilesystemencoding( )))

    return os.path.dirname(unicode(__file__, sys.getfilesystemencoding( )))

INSTALL_PATH = module_path()
sys.path.append(INSTALL_PATH + "\\modules") # needed for python to find our custom modules

from grabbing import grab_location # load grabbing code
from decalise import make_decal # load decal code
from ltm_to_utm import calc_rotation # rotation calculations
from splash import splash # splash screen
from clean_up import clean_up # clean_up
from hide_decals import hide_decals # hide decals
from unhide_decals import unhide_decals # restore decals
from rename_decal import rename_decal # rename decals
from get_used_decals import get_used_decals # hide / show decals
from list_decals import list_decals # get list of all decals in a folder
from list_products import list_products # array of all products in a folder
from transfer_decals import transfer_decals # actually transfer decals
from list_used_decals import list_used_decals # decals used in a route
from kml_markers import kml_marker_parse # used for markers from KML



MAJOR_VERSION = 2
MINOR_VERSION = 2
BUILD = 16
RELEASE = "Stable"
VERSION = str(MAJOR_VERSION) + "." + str(MINOR_VERSION) + "." + str(BUILD) + " " + str(RELEASE)

# control the production of lang_keys.dat and ordered lang files
LANG_KEYS = False
LANG_ORDERED = False

app = wx.PySimpleApp()

class single_instance:
    """ Limits application to single instance """

    def __init__(self):
        self.mutexname = "RWDecal"
        self.mutex = CreateMutex(None, False, self.mutexname)
        self.lasterror = GetLastError()
    
    def alreadyrunning(self):
        return (self.lasterror == ERROR_ALREADY_EXISTS)
        
    def __del__(self):
        if self.mutex:
            CloseHandle(self.mutex)

# do this at beginnig of your application
myapp = single_instance()


class main_window(wx.Frame):
    def __init__(self, parent, id, title):
        # check is another instance of same program running
        if myapp.alreadyrunning():
            md = wx.MessageDialog(None,"RWDecal is already running!\n"\
                                  "RWDecal k�rer allerede!\n"\
                                  "RWDecal wordt al uitgevoerd!\n"\
                                  "RWDecal est d�j� lanc�!\n"\
                                  "RWDecal l�uft bereits!\n"\
                                  "RWDecal � gi� in esecuzione!\n"\
                                  "�RWDecal est� a�n en ejecuci�n!\n"\
                                  "RWDecal k�rs redan!",
                                  "RWDecal is already running!",wx.OK)
            result = md.ShowModal()
            sys.exit()

        # not running, safe to continue...
        
        wx.Frame.__init__(self, parent, wx.ID_ANY, title, wx.DefaultPosition, wx.Size(wX, wY), wx.MINIMIZE_BOX|wx.SYSTEM_MENU|wx.CAPTION|wx.CLOSE_BOX|wx.CLIP_CHILDREN|wx.WS_EX_PROCESS_UI_UPDATES|wx.RESIZE_BORDER)
        self.Bind(wx.EVT_CLOSE, self.evt_quit)

        self.config = {}
        self.hidden_config = {}
        self.license_details = {}
        self.config["INSTALL_PATH"] = INSTALL_PATH
        self.form_settings = {}
        self.route_start = {}
        self.lang = {}
        self.check_path_exists(self.config["INSTALL_PATH"] + "\\settings\\") # make sure settings folder exists

        self.screen_width = GetSystemMetrics(0)
        self.screen_height = GetSystemMetrics(1)

        self.startupinfo = subprocess.STARTUPINFO()
        self.startupinfo.dwFlags |= _subprocess.STARTF_USESHOWWINDOW
        self.startupinfo.wShowWindow = _subprocess.SW_HIDE
        hspace = 4

        self.fW = wX - 15 - 22 - hspace # width used in form layout

        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        if ctypes.windll.shell32.IsUserAnAdmin() != True:
            md = wx.MessageDialog(None,"You do not appear to be using RWDecal as an Administrator. Please set RWDecal to run as an administrator or logon and use an which is a member of the administrators group.\n\n"\
                                  "Det ser ikke ud som om du k�rer RWDecal som administrator. Indstil RWDecal til at k�re som administrator eller log p� en konto med administrator rettigheder.\n\n"\
                                  "U blijkt RWDecal niet te gebruiken met Administrator (Beheerder) rechten. Laat RWDecal uitvoeren als Administrator of meldt u aan als een gebruiker die lid is van de Administrator groep.\n\n"\
                                  "Vous n'utilisez pas RWDecal en mode administrateur. Configurez RWDecal pour que le programme soit �xecut� en mode administrateur ou connecter vous � un compte administrateur a.\n\n"\
                                  "Sie haben anscheinend keine Administratorenrechte. Bitte geben Sie RWDecal Administratorenrechte oder loggen Sie sich selbst mit drei Benutzeraccount ein, der Administratorenrechte besitzt\n\n"\
                                  "Sembra che tu non stia usando Decal come Amministratore. Avvia RWDecal come Amministratore o collegati ed una un account che faccia parte del gruppo dell'Amministratore.\n\n"\
                                  "Parece que no est� usando RWDecal como administrador. Por favor, ejecute RWDecal como administrador o use una cuenta como miembro de un grupo de administradores.\n\n"\
                                  "Du verkar inte anv�nda RWDecal som en administrat�r. V�nligen st�ll in RWDecal att k�ras som en adminstrat�r eller logga in p� ett anv�ndarkonto som �r medlem i en administrat�rsgrupp.",
                                  "RWDecal must be run as an Administrator",
                                  wx.OK | wx.ICON_EXCLAMATION)
            result = md.ShowModal()
            sys.exit()
        
        self.get_config() # get configuration settings from config file
        self.get_last_use_settings() # get any saved last use settings
        self.check_flag() # check the RWDecal flag exists and is up to date
        objShell = win32com.client.Dispatch("WScript.Shell")
        
        self.fix_shortcut(objShell.SpecialFolders("AllUsersDesktop") + "\\RWDecal " + str(MAJOR_VERSION) + "." + str(MINOR_VERSION) + "." + str(BUILD) + ".lnk",self.config["INSTALL_PATH"] + "\\rwdecal.ico") # fix icon for desktop shortcut
        self.fix_shortcut(objShell.SpecialFolders("AllUsersDesktop") + "\\RWDecal " + str(MAJOR_VERSION) + "." + str(MINOR_VERSION) + "." + str(BUILD) + " " + str(RELEASE) + ".lnk",self.config["INSTALL_PATH"] + "\\rwdecal.ico") # fix icon for desktop shortcut
        self.fix_shortcut(objShell.SpecialFolders("AllUsersDesktop") + "\\RWDecal " + str(MAJOR_VERSION) + "." + str(MINOR_VERSION) + "." + str(BUILD) + " (" + str(RELEASE) + ").lnk",self.config["INSTALL_PATH"] + "\\rwdecal.ico") # fix icon for desktop shortcut

        # Title
        if self.licensed:
            text = "RWDecal " + VERSION + " " + self.lang["licensed_to"] + " " + self.license_details["USERNAME"]
        else:
            text = "RWDecal " + VERSION + " Unrestricted and 100% Free!"

        if eval(self.config["SHOW_SPLASH"]):
            splash(self,text,duration=5000)
        
        screen_width = GetSystemMetrics(0)
        screen_height = GetSystemMetrics(1)

        if screen_width < 1024 or screen_height < 768:
            self.error_handler(self.lang["low_screen_resolution"],
                               self.lang["low_screen_resolution_title"])


        


        # menu bar options
        menubar = wx.MenuBar()

        # File menu
        self.file = wx.Menu()
        self.file.Append(100,self.lang["file_quit"],self.lang["file_quit_status"])
        self.file.Append(101,self.lang["file_recalibrate"],self.lang["file_recalibrate_status"])
        self.file.Append(103,self.lang["file_make_backup"],self.lang["file_make_backup_status"])
        self.file.AppendSeparator()
        self.file.Append(106,self.lang["file_opensource"],self.lang["file_opensource_status"])
        self.file.Append(107,self.lang["file_openassets"],self.lang["file_openassets_status"])
        self.file.Append(108,self.lang["file_openbackups"],self.lang["file_openbackups_status"])
        self.file.AppendSeparator()
        self.file.Append(102,self.lang["file_clean_up_decals"],self.lang["file_clean_up_decals_status"])
        self.file.AppendSeparator()
        self.file.Append(104,self.lang["file_hide_decals"],self.lang["file_hide_decals_title"])
        self.file.Append(109,self.lang["file_restore_decals"],self.lang["file_restore_decals_title"])
        self.file.AppendSeparator()
        self.file.Append(105,self.lang["file_rename_decals"],self.lang["file_rename_decals_title"])
        self.file.Append(111,self.lang["file_transfer_decals"],self.lang["file_transfer_decals_title"])
        self.file.Append(110,self.lang["file_list_used_decals"],self.lang["file_list_used_decals_title"])
        self.file.AppendSeparator()
        self.file.Append(112,self.lang["file_kml_path"],self.lang["file_kml_path_title"])
        
        # Pref Menu
        self.prefs = wx.Menu()

        # Language sub menu
        self.language = wx.Menu()
        self.construct_language_menu()
##        self.language.Append(229, 'Dansk',"Skift sprog til dansk",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "DA":
##             self.language.Check(229,True)
##        self.language.Append(221, 'Deutsch',"Sprache zu Deutsch",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "DE":
##             self.language.Check(221,True)
##        self.language.Append(222, 'English British',"Change language to English British",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "EN_GB":
##            self.language.Check(222,True)
##        self.language.Append(223, 'Espa�ol',"Cambiar de idioma a espa�ol",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "ES":
##            self.language.Check(223,True)
##        self.language.Append(224, 'Fran�ais',"Changer la langue au fran�ais",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "FR":
##            self.language.Check(224,True)
##        # lang comment out #
##        
##        #self.language.Append(225, 'Portugu�s',"Alterar o idioma para Portugu�s",wx.ITEM_RADIO)
##        #if self.config["LANGUAGE"] == "PT":
##        #    self.language.Check(225,True)
##        self.language.Append(226, 'Nederlands',"Verander taal in Nederlands",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "NL":
##            self.language.Check(226,True)
##        self.language.Append(227, 'Italiano',"Cambiare lingua a Italiano",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "IT":
##            self.language.Check(227,True)
##        self.language.Append(228, 'Svenska',"�ndra spr�k till svenska",wx.ITEM_RADIO)
##        if self.config["LANGUAGE"] == "SW":
##            self.language.Check(228,True)
        #
        
        
            
        self.prefs.AppendMenu(220,self.lang["prefs_changelanguage"],self.language)
        self.prefs.AppendSeparator()
        
            
        # settings submenu
        self.settings = wx.Menu()
        self.settings.Append(254, self.lang["prefs_showsourcepath"], self.lang["prefs_showsourcepath_status"])
        self.settings.AppendSeparator()
        self.settings.Append(250, self.lang["prefs_railworkspath"], self.lang["prefs_railworkspath_status"])
        self.settings.Append(251, self.lang["prefs_developerfolder"],self.lang["prefs_developerfolder_status"])
        self.settings.Append(252, self.lang["prefs_productfolder"],self.lang["prefs_productfolder_status"])
        self.settings.Append(253, self.lang["prefs_rwacetoolpath"],self.lang["prefs_rwacetoolpath_status"])
        self.prefs.AppendMenu(200, self.lang["prefs_setprogramlocations"], self.settings)
        
        
        # debug sub menu
        self.debug = wx.Menu()
        self.debug.Append(260, self.lang["prefs_debugmode"], self.lang["prefs_debugmode_status"], wx.ITEM_CHECK).Check(eval(self.config["DEBUG"]))
        self.debug.Append(261, self.lang["prefs_debugclearpanel"], self.lang["prefs_debugclearpanel_status"])
        self.debug.Append(262, self.lang["prefs_debugclearlog"], self.lang["prefs_debugclearlog_status"])
        self.prefs.AppendMenu(201, self.lang["prefs_debug"], self.debug)

        # reduced capture area submenu
        self.reduced_capture = wx.Menu()
        self.reduced_capture.Append(270, '50%',self.lang["prefs_reducedcapture50"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.5":
            self.reduced_capture.Check(270,True)
        self.reduced_capture.Append(271, '55%',self.lang["prefs_reducedcapture55"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.55":
            self.reduced_capture.Check(271,True)
        self.reduced_capture.Append(272, '60%',self.lang["prefs_reducedcapture60"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.6":
            self.reduced_capture.Check(272,True)
        self.reduced_capture.Append(273, '65%',self.lang["prefs_reducedcapture65"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.65":
            self.reduced_capture.Check(273,True)
        self.reduced_capture.Append(274, '70%',self.lang["prefs_reducedcapture70"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.7":
            self.reduced_capture.Check(274,True)
        self.reduced_capture.Append(275, '75%',self.lang["prefs_reducedcapture75"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.75":
            self.reduced_capture.Check(275,True)
        self.reduced_capture.Append(276, '80%' + " " + self.lang["default"],self.lang["prefs_reducedcapture80"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.8":
            self.reduced_capture.Check(276,True)
        self.reduced_capture.Append(277, '85%',self.lang["prefs_reducedcapture85"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.85":
            self.reduced_capture.Check(277,True)
        self.reduced_capture.Append(278, '90%',self.lang["prefs_reducedcapture90"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.9":
            self.reduced_capture.Check(278,True)
        self.reduced_capture.Append(279, '95%',self.lang["prefs_reducedcapture95"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "0.95":
            self.reduced_capture.Check(279,True)
        self.reduced_capture.Append(280, '100%',self.lang["prefs_reducedcapture100"],wx.ITEM_RADIO)
        if self.config["REDUCED_CAPTURE"] == "1.0":
            self.reduced_capture.Check(280,True)
        self.prefs.AppendMenu(205,self.lang["prefs_reducedcapture"],self.reduced_capture)

        # reduced capture area submenu
        self.google_earth_stream_delay = wx.Menu()
        self.google_earth_stream_delay.Append(1001, self.lang["prefs_gestreamdelay0"],self.lang["prefs_gestreamdelay0_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "0":
            self.google_earth_stream_delay.Check(1001,True)
        self.google_earth_stream_delay.Append(1002, self.lang["prefs_gestreamdelay0.1"],self.lang["prefs_gestreamdelay0.1_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "0.1":
            self.google_earth_stream_delay.Check(1002,True)
        self.google_earth_stream_delay.Append(1003, self.lang["prefs_gestreamdelay0.25"],self.lang["prefs_gestreamdelay0.25_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "0.25":
            self.google_earth_stream_delay.Check(1003,True)
        self.google_earth_stream_delay.Append(1004, self.lang["prefs_gestreamdelay0.5"],self.lang["prefs_gestreamdelay0.5_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "0.5":
            self.google_earth_stream_delay.Check(1004,True)
        self.google_earth_stream_delay.Append(1005, self.lang["prefs_gestreamdelay0.75"],self.lang["prefs_gestreamdelay0.75_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "0.75":
            self.google_earth_stream_delay.Check(1005,True)
        self.google_earth_stream_delay.Append(1006, self.lang["prefs_gestreamdelay1"],self.lang["prefs_gestreamdelay1_status"],wx.ITEM_RADIO)
        if self.config["GE_STREAM_DELAY"] == "1":
            self.google_earth_stream_delay.Check(1006,True)
        self.prefs.AppendMenu(1000,self.lang["prefs_gestreamdelay"],self.google_earth_stream_delay)

        # decal quality
        self.decal_quality = wx.Menu()
        self.decal_quality.Append(290, self.lang["prefs_decalqualityverylow"], self.lang["prefs_decalqualityverylow_status"], wx.ITEM_RADIO)
        if self.config["DECAL_QUALITY"] == "512":
            self.decal_quality.Check(290,True)
        self.decal_quality.Append(291, self.lang["prefs_decalqualitylow"], self.lang["prefs_decalqualitylow_status"], wx.ITEM_RADIO)
        if self.config["DECAL_QUALITY"] == "1024":
            self.decal_quality.Check(291,True)
        self.decal_quality.Append(292, self.lang["prefs_decalqualitymedium"], self.lang["prefs_decalqualitymedium_status"], wx.ITEM_RADIO)
        if self.config["DECAL_QUALITY"] == "2048":
            self.decal_quality.Check(292,True)
        # self.decal_quality.Append(293, self.lang["prefs_decalqualityhigh"], self.lang["prefs_decalqualityhigh_status"],wx.ITEM_RADIO)
        if self.config["DECAL_QUALITY"] == "4096":
            self.decal_quality.Check(292,True)
            self.config["DECAL_QUALITY"] = "2048"
            self.save_config()
        self.prefs.AppendMenu(212,self.lang["prefs_decalquality"],self.decal_quality)

        # decal max size
        self.decal_max_size = wx.Menu()
        self.decal_max_size.Append(285, self.lang["prefs_decalsize300"], self.lang["prefs_decalsize300_status"], wx.ITEM_RADIO)
        if self.config["MAX_DECAL_SIZE"] == "300":
            self.decal_max_size.Check(285,True)
        self.decal_max_size.Append(286, self.lang["prefs_decalsize400"], self.lang["prefs_decalsize400_status"], wx.ITEM_RADIO)
        if self.config["MAX_DECAL_SIZE"] == "400":
            self.decal_max_size.Check(286,True)
        self.decal_max_size.Append(287, self.lang["prefs_decalsize500"], self.lang["prefs_decalsize500_status"],wx.ITEM_RADIO)
        if self.config["MAX_DECAL_SIZE"] == "500":
            self.decal_max_size.Check(287,True)
        self.decal_max_size.Append(288, self.lang["prefs_decalsize600"], self.lang["prefs_decalsize600_status"],wx.ITEM_RADIO)
        if self.config["MAX_DECAL_SIZE"] == "600":
            self.decal_max_size.Check(288,True)
        self.prefs.AppendMenu(289,self.lang["prefs_decalsize"],self.decal_max_size)
        

        # Tile Limit
        self.tile_limit = wx.Menu()
        self.tile_limit.Append(295, '150 ' + self.lang["default"], self.lang["prefs_tilelimit150"], wx.ITEM_RADIO)
        if self.config["TILE_LIMIT"] == "150":
            self.tile_limit.Check(295,True)
        self.tile_limit.Append(296, '250', self.lang["prefs_tilelimit250"], wx.ITEM_RADIO)
        if self.config["TILE_LIMIT"] == "250":
            self.tile_limit.Check(296,True)
        self.tile_limit.Append(297, '500',self.lang["prefs_tilelimit500"], wx.ITEM_RADIO)
        if self.config["TILE_LIMIT"] == "500":
            self.tile_limit.Check(297,True)
        self.tile_limit.Append(298, '750',self.lang["prefs_tilelimit750"], wx.ITEM_RADIO)
        if self.config["TILE_LIMIT"] == "750":
            self.tile_limit.Check(298,True)
        self.tile_limit.Append(299, self.lang["prefs_tilelimitunlimited_option"], self.lang["prefs_tilelimitunlimited"], wx.ITEM_RADIO)
        if self.config["TILE_LIMIT"] == "-1":
            self.tile_limit.Check(299,True)
        self.prefs.AppendMenu(213,self.lang["prefs_tilelimit"],self.tile_limit)
        self.prefs.AppendSeparator()
        self.prefs.Append(216, self.lang["prefs_routestart"], self.lang["prefs_routestart_status"])
        self.prefs.AppendSeparator()
        
        self.prefs.Append(202, self.lang["prefs_saveform"], self.lang["prefs_saveform_status"], wx.ITEM_CHECK).Check(eval(self.config["SAVE_FORM"]))
        self.prefs.Append(204, self.lang["prefs_deletetempfiles"], self.lang["prefs_deletetempfiles_status"], wx.ITEM_CHECK).Check(eval(self.config["DELETE_TEMP_FILES"]))
        self.prefs.Append(211, self.lang["prefs_antialiasdecals"], self.lang["prefs_antialiasdecals_status"], wx.ITEM_CHECK).Check(eval(self.config["ANTIALIAS_DECALS"]))
        self.prefs.Append(218, self.lang["prefs_chunkoverlap"], self.lang["prefs_chunkoverlap_status"], wx.ITEM_CHECK).Check(eval(self.config["CHUNK_OVERLAP"]))
        self.prefs.AppendSeparator()
        self.prefs.Append(208, self.lang["prefs_disablegelayers"], self.lang["prefs_disablegelayers_status"], wx.ITEM_CHECK).Check(eval(self.config["DISABLE_ALL_GE_LAYERS"]))
        self.prefs.Append(209, self.lang["prefs_disablegeplaces"], self.lang["prefs_disablegeplaces_status"], wx.ITEM_CHECK).Check(eval(self.config["DISABLE_ALL_GE_PLACES"]))
        self.prefs.Append(214, self.lang["prefs_createpolygons"], self.lang["prefs_createpolygons_status"],wx.ITEM_CHECK).Check(eval(self.config["CREATE_GE_POLYGONS"]))
        self.prefs.Append(2202, self.lang["prefs_create4cornermarkers"], self.lang["prefs_create4cornermarkers_status"],wx.ITEM_CHECK).Check(eval(self.config["CENTER_4CORNERMARKERS"]))
        self.prefs.Append(219, self.lang["prefs_createcentermarkers"], self.lang["prefs_createcentermarkers_status"],wx.ITEM_CHECK).Check(eval(self.config["CENTER_MARKERS"]))
        self.prefs.Append(215, self.lang["prefs_tidystraymarkers"], self.lang["prefs_tidystraymarkers_status"])
        self.prefs.AppendSeparator()
        self.prefs.Append(217, self.lang["prefs_deletepreviousruns"], self.lang["prefs_deletepreviousruns_status"])
        self.prefs.Append(210, self.lang["prefs_deletegrabmarkers"], self.lang["prefs_deletegrabmarkers_status"])

        self.load_marker_pairs()
        self.auto_delete = wx.Menu()
        self.get_auto_grab_delete_options()
        #self.auto_delete.Append(2204, self.lang["prefs_showsourcepath"], self.lang["prefs_showsourcepath_status"])        
        self.prefs.AppendMenu(2203, self.lang["prefs_deletegrabmarkers_auto"], self.auto_delete)
        self.prefs.AppendSeparator()
        
        self.prefs.Append(203, self.lang["prefs_overwritewarning"], self.lang["prefs_overwritewarning_status"], wx.ITEM_CHECK).Check(eval(self.config["OVERWRITE_WARNING"]))
        self.prefs.Append(207, self.lang["prefs_grabconfirmation"], self.lang["prefs_grabconfirmation_status"], wx.ITEM_CHECK).Check(eval(self.config["OVERWRITE_WARNING"]))
        self.prefs.Append(2201, self.lang["prefs_showsplash"], self.lang["prefs_showsplash_status"],wx.ITEM_CHECK).Check(eval(self.config["SHOW_SPLASH"]))
        self.prefs.AppendSeparator()
        
        self.prefs.Append(206, self.lang["prefs_improvementprogram"], self.lang["prefs_improvementprogram_status"], wx.ITEM_CHECK).Check(eval(self.config["IMPROVEMENT_PROGRAM"]))


        # help menu
        self.help = wx.Menu()
        self.help.Append(300, self.lang["help_about"], self.lang["help_about_status"])

        # updates
        self.update = wx.Menu()
        self.update.Append(310, self.lang["help_updatenow"], self.lang["help_updatenow_status"]) # check now
        self.update.AppendSeparator()
        self.update.Append(311, self.lang["help_updatedisable"], self.lang["help_updatedisable_status"],wx.ITEM_RADIO) # disable
        if self.config["UPDATE_CHECK_FREQUENCY"] == "-1":
            self.update.Check(311,True)
        self.update.Append(312, self.lang["help_updateonload"], self.lang["help_updateonload_status"],wx.ITEM_RADIO) # onload
        if self.config["UPDATE_CHECK_FREQUENCY"] == "0":
            self.update.Check(312,True)
        self.update.Append(313, self.lang["help_updatedaily"], self.lang["help_updatedaily_status"],wx.ITEM_RADIO) # daily
        if self.config["UPDATE_CHECK_FREQUENCY"] == "86400":
            self.update.Check(313,True)
        self.update.Append(314, self.lang["help_updateweekly"] + " " + self.lang["default"], self.lang["help_updateweekly_status"],wx.ITEM_RADIO) # weekly
        if self.config["UPDATE_CHECK_FREQUENCY"] == "604800":
            self.update.Check(314,True)
        self.help.AppendMenu(301,self.lang["help_update"],self.update)
        
        if self.licensed:
            self.help.Append(302, self.lang["help_donate"], self.lang["help_donate_status"])
        else:
            self.help.Append(303, self.lang["help_requestlicense"], self.lang["help_requestlicense_status"])
            self.help.Append(304, self.lang["help_enterlicense"], self.lang["help_enterlicense_status"])
            
        self.help.AppendSeparator()
        self.help.Append(305, self.lang["help_support"], self.lang["help_support_status"])
        self.help.Append(306, self.lang["help_manual"], self.lang["help_manual_status"])

        # add menus to menubar
        menubar.Append(self.file, self.lang["file"])
        menubar.Append(self.prefs, self.lang["prefs"])
        menubar.Append(self.help, self.lang["help"])

        self.SetMenuBar(menubar)
        self.CreateStatusBar()     
      
        # File menu events
        wx.EVT_MENU(self, 100, self.evt_quit)
        wx.EVT_MENU(self, 101, self.evt_calibrate)
        wx.EVT_MENU(self, 102, self.evt_clean_up_decals)
        wx.EVT_MENU(self, 103, self.evt_take_backup)
        wx.EVT_MENU(self, 104, self.evt_hide_decals)
        wx.EVT_MENU(self, 105, self.evt_rename_decals)
        wx.EVT_MENU(self, 106, self.evt_opensource)
        wx.EVT_MENU(self, 107, self.evt_openassets)
        wx.EVT_MENU(self, 108, self.evt_openbackups)
        wx.EVT_MENU(self, 109, self.evt_unhide_decals)
        wx.EVT_MENU(self, 110, self.evt_list_used_decals)
        wx.EVT_MENU(self, 111, self.evt_transfer_decals)
        wx.EVT_MENU(self, 112, self.evt_kml_path)
        #self.Bind(wx.EVT_MENU, lambda evt, temp="source_decals": self.delete_tracked_items(evt, temp), delete_source_decals)
        #self.Bind(wx.EVT_MENU, lambda evt, temp="source_markers": self.delete_tracked_items(evt, temp), delete_source_markers)
        #self.Bind(wx.EVT_MENU, lambdgraba evt, temp="assets_decals": self.delete_tracked_items(evt, temp), delete_assets_decals)
        #self.Bind(wx.EVT_MENU, lambda evt, temp="assets_markers": self.delete_tracked_items(evt, temp), delete_assets_markers)

        # Pref menu events
        wx.EVT_MENU(self, 216, self.evt_route_start)
        wx.EVT_MENU(self, 202, self.evt_save_form)
        wx.EVT_MENU(self, 203, self.evt_overwrite_warning)
        wx.EVT_MENU(self, 204, self.evt_delete_temp_files)
        # language
        #wx.EVT_MENU(self, 221, self.evt_change_language)
        #wx.EVT_MENU(self, 222, self.evt_change_language)
        #wx.EVT_MENU(self, 223, self.evt_change_language)
        #wx.EVT_MENU(self, 224, self.evt_change_language)
        # lang comment out
        #wx.EVT_MENU(self, 225, self.evt_change_language)
        #wx.EVT_MENU(self, 226, self.evt_change_language)
        #wx.EVT_MENU(self, 227, self.evt_change_language)
        #wx.EVT_MENU(self, 228, self.evt_change_language)
        #wx.EVT_MENU(self, 229, self.evt_change_language)
        
        # reduced capture
        wx.EVT_MENU(self, 270, self.evt_reduced_capture)
        wx.EVT_MENU(self, 271, self.evt_reduced_capture)
        wx.EVT_MENU(self, 272, self.evt_reduced_capture)
        wx.EVT_MENU(self, 273, self.evt_reduced_capture)
        wx.EVT_MENU(self, 274, self.evt_reduced_capture)
        wx.EVT_MENU(self, 275, self.evt_reduced_capture)
        wx.EVT_MENU(self, 276, self.evt_reduced_capture)
        wx.EVT_MENU(self, 277, self.evt_reduced_capture)
        wx.EVT_MENU(self, 278, self.evt_reduced_capture)
        wx.EVT_MENU(self, 279, self.evt_reduced_capture)
        wx.EVT_MENU(self, 280, self.evt_reduced_capture)
        # stream delay
        wx.EVT_MENU(self, 1001, self.evt_google_earth_stream_delay)
        wx.EVT_MENU(self, 1002, self.evt_google_earth_stream_delay)
        wx.EVT_MENU(self, 1003, self.evt_google_earth_stream_delay)
        wx.EVT_MENU(self, 1004, self.evt_google_earth_stream_delay)
        wx.EVT_MENU(self, 1005, self.evt_google_earth_stream_delay)
        wx.EVT_MENU(self, 1006, self.evt_google_earth_stream_delay)
        # decal quality
        wx.EVT_MENU(self, 290, self.evt_decal_quality)
        wx.EVT_MENU(self, 291, self.evt_decal_quality)
        wx.EVT_MENU(self, 292, self.evt_decal_quality)
        wx.EVT_MENU(self, 293, self.evt_decal_quality)
        # chunk size
        wx.EVT_MENU(self, 285, self.evt_decal_maxsize)
        wx.EVT_MENU(self, 286, self.evt_decal_maxsize)
        wx.EVT_MENU(self, 287, self.evt_decal_maxsize)
        wx.EVT_MENU(self, 288, self.evt_decal_maxsize)
        # tile limit
        wx.EVT_MENU(self, 295, self.evt_tile_limit)
        wx.EVT_MENU(self, 296, self.evt_tile_limit)
        wx.EVT_MENU(self, 297, self.evt_tile_limit)
        wx.EVT_MENU(self, 298, self.evt_tile_limit)
        wx.EVT_MENU(self, 299, self.evt_tile_limit)
        # others
        wx.EVT_MENU(self, 206, self.evt_improvement_program)
        wx.EVT_MENU(self, 207, self.evt_grab_confirmation)
        wx.EVT_MENU(self, 2201, self.evt_show_splash)
        wx.EVT_MENU(self, 208, self.evt_disable_all_ge_layers)
        wx.EVT_MENU(self, 209, self.evt_disable_all_ge_places)
        wx.EVT_MENU(self, 210, self.evt_reset_grab_markers)
        wx.EVT_MENU(self, 217, self.evt_previous_clear)
        wx.EVT_MENU(self, 214, self.evt_create_ge_polygons)
        wx.EVT_MENU(self, 2202, self.evt_create_4_corner_center)
        wx.EVT_MENU(self, 219, self.evt_create_center)
        wx.EVT_MENU(self, 215, self.evt_tidy_stray_markers)
        wx.EVT_MENU(self, 211, self.evt_anti_alias)
        wx.EVT_MENU(self, 218, self.evt_chunk_overlap)
        

        # Settings meny events
        wx.EVT_MENU(self, 254, self.evt_show_working_path)
        wx.EVT_MENU(self, 250, self.evt_settings_railworks_path)
        wx.EVT_MENU(self, 251, self.evt_settings_developer_folder)
        wx.EVT_MENU(self, 252, self.evt_settings_product_folder)
        wx.EVT_MENU(self, 253, self.evt_settings_rwacetool_location)

        # Debugging menu events
        wx.EVT_MENU(self, 260, self.evt_debug)
        wx.EVT_MENU(self, 261, self.evt_debug_panel_clear)
        wx.EVT_MENU(self, 262, self.evt_debug_log_clear)

        # Help menu events
        wx.EVT_MENU(self, 300, self.evt_about)
        wx.EVT_MENU(self, 310, self.evt_update)
        wx.EVT_MENU(self, 311, self.evt_update_control)
        wx.EVT_MENU(self, 312, self.evt_update_control)
        wx.EVT_MENU(self, 313, self.evt_update_control)
        wx.EVT_MENU(self, 314, self.evt_update_control)
        wx.EVT_MENU(self, 302, self.evt_donate)
        wx.EVT_MENU(self, 303, self.evt_donate)
        wx.EVT_MENU(self, 304, self.evt_enter_license)
        wx.EVT_MENU(self, 305, self.evt_online_support)
        wx.EVT_MENU(self, 306, self.evt_pdf_manual)
        



        # main panel gubbins
        self.main_panel = wx.Panel(self, -1, style=wx.NO_BORDER|wx.TAB_TRAVERSAL|wx.RESIZE_BORDER)

        # Title
        if self.licensed:
            title = wx.StaticText(self.main_panel, -1, "RWDecal " + self.lang["licensed_to"] + " " + self.license_details["USERNAME"], style=wx.ALIGN_CENTRE)
        else:
            title = wx.StaticText(self.main_panel, -1, "RWDecal", style=wx.ALIGN_CENTRE)
        ziFont = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        title.SetFont(ziFont)
        
        # Specify decal name
        decal_name_label = wx.StaticText(self.main_panel, -1, self.lang["decal_name"], size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)
        
        self.decal_name_text  = wx.TextCtrl(self.main_panel, -1, self.form_settings["DECAL_NAME"], size=(self.fW*0.8 - hspace - 1, -1))
        self.decal_name_text.SetInsertionPoint(0)
        self.Bind(wx.EVT_TEXT, self.evt_validate_form,self.decal_name_text)
        self.decal_name_text.SetToolTip(wx.ToolTip(self.lang["tooltip_decalname"]))

        decal_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        decal_info.Bind(wx.EVT_BUTTON, lambda evt, temp="decal_info": self.evt_info_button(evt, temp))

        decal_name_sizer = wx.FlexGridSizer(cols=3, hgap=hspace, vgap=hspace)
        decal_name_sizer.AddMany([decal_name_label, self.decal_name_text,decal_info])

        # Previous Runs
        previous_runs_label = wx.StaticText(self.main_panel, -1, self.lang["previous_runs"], size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)
        self.get_previous_runs() # generates combo box

        previous_runs_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        previous_runs_info.Bind(wx.EVT_BUTTON, lambda evt, temp="previous_runs_info": self.evt_info_button(evt, temp))

        self.previous_runs_sizer = wx.FlexGridSizer(cols=4, hgap=hspace, vgap=hspace)
        self.previous_runs_sizer.AddMany([previous_runs_label, self.previous_runs_combo, self.previous_delete_button, previous_runs_info])

        # Load Marker Pairs
        marker_pairs_label = wx.StaticText(self.main_panel, -1, self.lang["marker_pairs"], size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)
        self.get_marker_pairs() # generates combo box

        marker_pairs_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        marker_pairs_info.Bind(wx.EVT_BUTTON, lambda evt, temp="marker_pairs_info": self.evt_info_button(evt, temp))

        self.marker_pairs_sizer = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=hspace)
        self.marker_pairs_sizer.AddMany([marker_pairs_label, self.marker_pairs_combo, self.marker_pair_delete, self.bulk_create, marker_pairs_info])

        # Lat/Lon direct entry section
        heading_LL = wx.StaticText(self.main_panel, -1, self.lang["lower_left"],size=(self.fW*0.3 - hspace, -1))
        heading_UR = wx.StaticText(self.main_panel, -1, self.lang["upper_right"],size=(self.fW*0.3 - hspace, -1))
        heading_dimensions = wx.StaticText(self.main_panel, -1, self.lang["decal_details"],size=(self.fW*0.2 - hspace, -1))
        
        lat_label = wx.StaticText(self.main_panel, -1, self.lang["latitude"],size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)
        lon_label = wx.StaticText(self.main_panel, -1, self.lang["longitude"],size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)

        self.latLL_text = wx.TextCtrl(self.main_panel, -1, self.form_settings["LL_LAT"], size=(self.fW*0.3 - hspace, -1))
        self.latLL_text.SetInsertionPoint(0)
        self.Bind(wx.EVT_TEXT, self.evt_validate_form, self.latLL_text)
        self.latLL_text.SetToolTip(wx.ToolTip(self.lang["tooltip_lllat"]))

        lat_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        lat_info.Bind(wx.EVT_BUTTON, lambda evt, temp="lat_info": self.evt_info_button(evt, temp))

        self.lonLL_text  = wx.TextCtrl(self.main_panel, -1, self.form_settings["LL_LON"], size=(self.fW*0.3 - hspace, -1))
        self.lonLL_text.SetInsertionPoint(0)
        self.Bind(wx.EVT_TEXT, self.evt_validate_form, self.lonLL_text)
        self.lonLL_text.SetToolTip(wx.ToolTip(self.lang["tooltip_lllon"]))

        lon_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        lon_info.Bind(wx.EVT_BUTTON, lambda evt, temp="lon_info": self.evt_info_button(evt, temp))

        self.latUR_text  = wx.TextCtrl(self.main_panel, -1, self.form_settings["UR_LAT"], size=(self.fW*0.3 - hspace, -1))
        self.latUR_text.SetInsertionPoint(0)
        self.Bind(wx.EVT_TEXT, self.evt_validate_form, self.latUR_text)
        self.latUR_text.SetToolTip(wx.ToolTip(self.lang["tooltip_urlat"]))

        self.lonUR_text  = wx.TextCtrl(self.main_panel, -1, self.form_settings["UR_LON"], size=(self.fW*0.3 - hspace, -1))
        self.lonUR_text.SetInsertionPoint(0)
        self.Bind(wx.EVT_TEXT, self.evt_validate_form, self.lonUR_text)
        self.lonUR_text.SetToolTip(wx.ToolTip(self.lang["tooltip_urlon"]))

        # configure main window status (must be before validate of form is done
        main_window_status_title = wx.StaticText(self.main_panel, -1, self.lang["status"], size=(self.fW + 25,-1))
        ziFont = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, True)
        main_window_status_title.SetFont(ziFont)

        self.main_window_status = wx.StaticText(self.main_panel, -1, self.lang["status_ready"],size=(self.fW + 25,-1),pos=(hspace,-1))
        self.main_window_status.Wrap(self.fW + 25 - hspace * 2)

        # work out area dimensions
        self.capture_area_dimensions = (0,0)
        if self.evt_validate_form(False,False,True):
            # vincenty
            self.capture_area_dimensions = (round(self.vinc_dist(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["LL_LAT"]),  float(self.form_settings["UR_LON"])),3),
                                            round(self.vinc_dist(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["UR_LAT"]),  float(self.form_settings["LL_LON"])),3))
            # haversine
            #self.capture_area_dimensions = (self.calc_seperation_in_meters(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["LL_LAT"]),  float(self.form_settings["UR_LON"])),
            #                                self.calc_seperation_in_meters(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["UR_LAT"]),  float(self.form_settings["LL_LON"])))
            
        if self.capture_area_dimensions[0] > 1000:
            self.width_text = wx.StaticText(self.main_panel, -1, str(round(self.capture_area_dimensions[0] / 1000.0,2)) + "k" + self.lang["meters_wide"],size=(self.fW*0.2 - hspace, -1))
        else:
            self.width_text = wx.StaticText(self.main_panel, -1, str(round(self.capture_area_dimensions[0],2)) + self.lang["meters_wide"],size=(self.fW*0.2 - hspace, -1))
        if self.capture_area_dimensions[1] > 1000:
            self.height_text = wx.StaticText(self.main_panel, -1, str(round(self.capture_area_dimensions[1] / 1000.0,2)) + "k" + self.lang["meters_high"],size=(self.fW*0.2 - hspace, -1))
        else:
            self.height_text = wx.StaticText(self.main_panel, -1, str(round(self.capture_area_dimensions[1],2)) + self.lang["meters_high"],size=(self.fW*0.2 - hspace, -1))

        self.num_tiles = wx.StaticText(self.main_panel, -1, "",size=(self.fW*0.2 - hspace, -1))

        grab_label = wx.StaticText(self.main_panel, -1, self.lang["coordinates"],size=(self.fW*0.2 - hspace, -1),style=wx.ALIGN_RIGHT)

        self.grab_ll = wx.Button(self.main_panel, -1, self.lang["grab_ll"],size=(self.fW*0.2 - hspace, -1))
        self.grab_ll.Bind(wx.EVT_BUTTON, lambda evt, temp="ll": self.evt_grab_start(evt, temp))
        self.grab_ll.SetToolTip(wx.ToolTip(self.lang["tooltip_startgrabll"]))

        self.grab_current = wx.Button(self.main_panel, -1, self.lang["grab_current"],size=(self.fW*0.2 - hspace / 2, -1))
        self.grab_current.Bind(wx.EVT_BUTTON, lambda evt, temp="current": self.evt_grab_start(evt, temp))
        self.grab_current.SetToolTip(wx.ToolTip(self.lang["tooltip_startgrabcurrent"]))
        
        self.grab_ur = wx.Button(self.main_panel, -1, self.lang["grab_ur"],size=(self.fW*0.2 - hspace, -1))
        self.grab_ur.Bind(wx.EVT_BUTTON, lambda evt, temp="ur": self.evt_grab_start(evt, temp))
        self.grab_ur.SetToolTip(wx.ToolTip(self.lang["tooltip_startgrabur"]))

        grab_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        grab_info.Bind(wx.EVT_BUTTON, lambda evt, temp="grab_info": self.evt_info_button(evt, temp))

        grab_sizer = wx.FlexGridSizer(cols=6, hgap=hspace, vgap=hspace)
        grab_sizer.AddMany([grab_label, self.grab_ll, self.grab_current, self.grab_ur, self.num_tiles, grab_info])
        
        coord_sizer = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=hspace)
        coord_sizer.AddMany([ (0, 0),      heading_LL,      heading_UR, heading_dimensions, (0, 0),
                            lat_label,   self.latLL_text, self.latUR_text, self.height_text, lat_info,
                            lon_label,   self.lonLL_text, self.lonUR_text, self.width_text, lon_info])
        #grab_sizer = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=hspace)
        #first_cell = self.fW*0.2 - hspace
        #grab_sizer.AddMany([(int(self.fW*0.2 - hspace),0), self.grab_ll, self.grab_ur, self.num_tiles, grab_info])


        # Altitude selection
        i = 25
        self.altitude_options = self.altitude_option_generate()


        self.altitude_choice = wx.Choice(self.main_panel, -1, choices=self.altitude_options, size=(self.fW*0.3 - hspace, -1))
        self.altitude_choice.SetSelection(int(self.form_settings["ALTITUDE"]))
        self.altitude_choice.Bind(wx.EVT_CHOICE, lambda evt: self.evt_validate_form(evt, False,False,True))
        #self.altitude_choice.Bind(wx.EVT_CHOICE, self.evt_validate_form, self.altitude_choice)
        self.altitude_choice.SetToolTip(wx.ToolTip(self.lang["tooltip_altitude"]))

        altitude_choice_label  = wx.StaticText(self.main_panel, -1, self.lang["altitude"],size=(self.fW*0.2 - hspace, -1), style=wx.ALIGN_RIGHT)

        altitude_limits = wx.StaticText(self.main_panel, -1, self.lang["altitude_limits"], size=(self.fW*0.5 - hspace,-1))

        altitude_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        altitude_info.Bind(wx.EVT_BUTTON, lambda evt, temp="altitude_info": self.evt_info_button(evt, temp))
        
        altitude_sizer = wx.FlexGridSizer(cols=4, hgap=hspace, vgap=hspace)
        altitude_sizer.AddMany([altitude_choice_label, self.altitude_choice, altitude_limits,altitude_info])


        # Chunk selection
        self.chunk_choice_options = [self.lang["chunks_only"], self.lang["full_only"], self.lang["fullchunks_only"]]
        self.chunk_choice = wx.Choice(self.main_panel, -1, choices=self.chunk_choice_options,size=(self.fW*0.3 - hspace, -1))
        self.chunk_choice.SetSelection(int(self.form_settings["CHUNK_CHOICE"]))
        self.chunk_choice.Bind(wx.EVT_CHOICE, self.evt_validate_form, self.chunk_choice)
        self.chunk_choice.SetToolTip(wx.ToolTip(self.lang["tooltip_chunkchoice"]))

        chunk_choice_label  = wx.StaticText(self.main_panel, -1, self.lang["decal_method"],size=(self.fW*0.2 - hspace, -1), style=wx.ALIGN_RIGHT)

        chunk_choice_desc = wx.StaticText(self.main_panel, -1, self.lang["chunk_desc"], size=(self.fW*0.5 - hspace,-1))
        chunk_choice_desc.Wrap(self.fW*0.5 - hspace)
        
        chunk_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        chunk_info.Bind(wx.EVT_BUTTON, lambda evt, temp="chunk_info": self.evt_info_button(evt, temp))
         
        chunk_sizer = wx.FlexGridSizer(cols=4,  hgap=hspace, vgap=hspace)
        chunk_sizer.AddMany([chunk_choice_label, self.chunk_choice, chunk_choice_desc, chunk_info])



        # Camera Speed
        self.camera_speed_choice_options = [self.lang["camera_slow"], self.lang["camera_medium"], self.lang["camera_fast"], self.lang["camera_veryfast"], self.lang["camera_instant"]]
        self.camera_speed_choice = wx.Choice(self.main_panel, -1, choices=self.camera_speed_choice_options,size=(self.fW*0.3 - hspace, -1))
        self.camera_speed_choice.SetSelection(int(self.form_settings["CAMERA_SPEED"]))
        self.camera_speed_choice.Bind(wx.EVT_CHOICE, self.evt_validate_form, self.camera_speed_choice)
        self.camera_speed_choice.SetToolTip(wx.ToolTip(self.lang["tooltip_cameraspeed"]))

        camera_speed_choice_label  = wx.StaticText(self.main_panel, -1, self.lang["camera"],size=(self.fW*0.2 - hspace, -1), style=wx.ALIGN_RIGHT)

        camera_speed_desc = wx.StaticText(self.main_panel, -1, self.lang["camera_desc"], size=(self.fW*0.5 - hspace,-1))
        camera_speed_desc.Wrap(self.fW*0.5 - hspace)
        
        camera_speed_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        camera_speed_info.Bind(wx.EVT_BUTTON, lambda evt, temp="camera_speed_info": self.evt_info_button(evt, temp))

        camera_speed_sizer = wx.FlexGridSizer(cols=4,  hgap=hspace, vgap=hspace)
        camera_speed_sizer.AddMany([camera_speed_choice_label, self.camera_speed_choice, camera_speed_desc, camera_speed_info])
        


        # Options
        # extras title
        options_label  = wx.StaticText(self.main_panel, -1, self.lang["options"])
        ziFont = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, True)
        options_label.SetFont(ziFont)

        
        # due north fix
        self.due_north_fix = wx.CheckBox(self.main_panel, -1, self.lang["due_north_fix"], wx.DefaultPosition,size=(self.fW*0.235 - hspace,-1))
        self.due_north_fix.SetValue(eval(self.form_settings["DUE_NORTH_FIX"]))
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.due_north_fix)
        self.due_north_fix.SetToolTip(wx.ToolTip(self.lang["tooltip_duenorthfix"]))

        self.due_north_fix_help = wx.Button(self.main_panel, -1, self.lang["due_north_fix_help_label"],size=(self.fW*0.265 - hspace - 4,-1))
        self.due_north_fix_help.Bind(wx.EVT_BUTTON, lambda evt, temp="due_north_fix_help": self.evt_info_button(evt, temp))
        self.due_north_fix_help.SetToolTip(wx.ToolTip(self.lang["tooltip_duenorthfixhelp"]))

        due_north_fix_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        due_north_fix_info.Bind(wx.EVT_BUTTON, lambda evt, temp="due_north_fix_info": self.evt_info_button(evt, temp))

        self.due_north_fix_degrees = wx.TextCtrl(self.main_panel, -1, self.form_settings["DUE_NORTH_FIX_DEGREES"], size=(self.fW*0.2 - hspace,-1))
        self.due_north_fix_degrees.Enable(False)
        self.due_north_fix_degrees.SetToolTip(wx.ToolTip(self.lang["tooltip_duenorthfixdegrees"]))

        due_north_fix_degrees_label = wx.StaticText(self.main_panel, -1, self.lang["degrees_rotation"], size=(self.fW*0.3 - hspace + 1,-1))

        self.due_north_fix_auto = wx.CheckBox(self.main_panel, -1, self.lang["due_north_auto"],size=(self.fW*0.5 - hspace,-1))
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.due_north_fix_auto)
        self.due_north_fix_auto.SetValue(eval(self.form_settings["AUTO_ROTATE"]))
        self.due_north_fix_auto.SetToolTip(wx.ToolTip(self.lang["tooltip_duenorthfixauto"]))

        self.due_north_fix_chunk_auto = wx.CheckBox(self.main_panel, -1, self.lang["due_north_chunk_auto"],size=(self.fW*0.5 - hspace,-1))
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.due_north_fix_chunk_auto)
        self.due_north_fix_chunk_auto.SetValue(eval(self.form_settings["AUTO_ROTATE_CHUNK_LOCK"]))
        self.due_north_fix_chunk_auto.SetToolTip(wx.ToolTip(self.lang["tooltip_duenorthfixchunkauto"]))

        #self.due_north_fix_USA = wx.Button(self.main_panel, -1, "USA",size=(self.fW*0.25 - hspace,-1))
        #self.due_north_fix_USA.Bind(wx.EVT_BUTTON, lambda evt, temp="USA": self.evt_estimate_rotate(evt, temp))
        #self.due_north_fix_USA.Enable(False)

        #if eval(self.form_settings["DUE_NORTH_FIX"]) == True: # if enabled then enable box to input degree value
        #    self.due_north_fix_degrees.Enable(True)
        #    self.due_north_fix_auto.Enable(True)
        #if eval(self.form_settings["AUTO_ROTATE"]):
        #    self.due_north_fix_chunk_auto.Enable(True)

        
        due_north_degrees_sizer1 = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=hspace)
        due_north_degrees_sizer1.AddMany([self.due_north_fix, self.due_north_fix_help, self.due_north_fix_degrees, due_north_fix_degrees_label, due_north_fix_info])
        due_north_degrees_sizer2 = wx.FlexGridSizer(cols=2, hgap=hspace, vgap=hspace)
        due_north_degrees_sizer2.AddMany([(int(self.fW*0.5 - hspace * 2),0),self.due_north_fix_auto,
                                          (int(self.fW*0.5 - hspace * 2),0),self.due_north_fix_chunk_auto])            

        # Marker Creation
        self.create_markers = wx.CheckBox(self.main_panel, -1, "",wx.DefaultPosition,size=(12  ,-1))
        self.create_markers.SetValue(eval(self.form_settings["CREATE_MARKERS"]))                                   
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.create_markers)
        self.create_markers.SetToolTip(wx.ToolTip(self.lang["tooltip_createmarkers"]))
        create_markers_label = wx.StaticText(self.main_panel, -1, self.lang["markers_desc"],size=(self.fW * 0.52 - hspace - 12 - hspace, -1))
        create_markers_label.Wrap(self.fW * 0.52 - hspace - 12)
        
        create_markers_choice_full_label = wx.StaticText(self.main_panel, -1, self.lang["markers_full"], size=(self.fW*0.28 - hspace,-1), style=wx.ALIGN_RIGHT)
        self.create_markers_choice_full_options = [self.lang["marker_options_none"],
                                                   self.lang["marker_options_corners"],
                                                   self.lang["marker_options_centre"],
                                                   self.lang["marker_options_both"]]
        self.create_markers_choice_full = wx.Choice(self.main_panel, -1, choices=self.create_markers_choice_full_options,size=(self.fW*0.2 - hspace - 4, -1))
        self.create_markers_choice_full.SetSelection(int(self.form_settings["CREATE_MARKERS_CHOICE_FULL"]))
        self.create_markers_choice_full.Bind(wx.EVT_CHOICE, self.evt_validate_form, self.create_markers_choice_full)
        self.create_markers_choice_full.SetToolTip(wx.ToolTip(self.lang["tooltip_createmarkersfull"]))

        create_markers_choice_chunks_label = wx.StaticText(self.main_panel, -1, self.lang["marker_chunk"], size=(self.fW*0.28 - hspace,-1), style=wx.ALIGN_RIGHT)
        self.create_markers_choice_chunks_options = [self.lang["marker_options_none"],
                                                     self.lang["marker_options_corners"],
                                                     self.lang["marker_options_centre"],
                                                     self.lang["marker_options_both"]]
        self.create_markers_choice_chunks = wx.Choice(self.main_panel, -1, choices=self.create_markers_choice_chunks_options,size=(self.fW*0.2 - hspace - 4, -1))
        self.create_markers_choice_chunks.SetSelection(int(self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]))
        self.create_markers_choice_chunks.Bind(wx.EVT_CHOICE, self.evt_validate_form, self.create_markers_choice_chunks)
        self.create_markers_choice_chunks.SetToolTip(wx.ToolTip(self.lang["tooltip_createmarkerschunks"]))

        #if eval(self.form_settings["CREATE_MARKERS"]) != True:
        #    self.create_markers_choice_full.Enable(False)
        #    self.create_markers_choice_chunks.Enable(False)

        create_markers_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        create_markers_info.Bind(wx.EVT_BUTTON, lambda evt, temp="create_markers_info": self.evt_info_button(evt, temp))

        create_markers_sizer = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=hspace)
        create_markers_sizer.AddMany([self.create_markers, create_markers_label, create_markers_choice_full_label, self.create_markers_choice_full, create_markers_info,
                                      (0,0), (0,0), create_markers_choice_chunks_label, self.create_markers_choice_chunks, (0,0)])


        # Export to RailWorks
        self.railworks_export = wx.CheckBox(self.main_panel, -1, self.lang["automatic_export"], wx.DefaultPosition,size=(self.fW - hspace - 5,-1))
        self.railworks_export.SetValue(eval(self.form_settings["RAILWORKS_EXPORT"]))
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.railworks_export)
        self.railworks_export.SetToolTip(wx.ToolTip(self.lang["tooltip_export"]))

        railworks_export_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        railworks_export_info.Bind(wx.EVT_BUTTON, lambda evt, temp="railworks_export_info": self.evt_info_button(evt, temp))

        railworks_export_sizer = wx.FlexGridSizer(cols=2, hgap=hspace, vgap=hspace)
        railworks_export_sizer.AddMany([self.railworks_export,railworks_export_info])

        # Delete blueprints after export
        self.delete_blueprints = wx.CheckBox(self.main_panel, -1, self.lang["delete_blueprints"], wx.DefaultPosition,size=(self.fW - hspace - 5,-1))
        self.delete_blueprints.SetValue(eval(self.form_settings["DELETE_BLUEPRINTS"]))       
        if eval(self.form_settings["RAILWORKS_EXPORT"]) != True:
            self.delete_blueprints.Enable(False)
        self.Bind(wx.EVT_CHECKBOX, self.evt_validate_form, self.delete_blueprints)
        self.delete_blueprints.SetToolTip(wx.ToolTip(self.lang["tooltip_deletesource"]))

        delete_blueprints_info = GenBitmapTextButton(self.main_panel, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)

        delete_blueprints_info.Bind(wx.EVT_BUTTON, lambda evt, temp="delete_blueprints_info": self.evt_info_button(evt, temp))

        delete_blueprints_sizer = wx.FlexGridSizer(cols=2, hgap=hspace, vgap=hspace)
        delete_blueprints_sizer.AddMany([self.delete_blueprints,delete_blueprints_info])
            
        
        options_sizer = wx.FlexGridSizer(cols=2, hgap=hspace, vgap=hspace)
        options_sizer.AddMany([(0, 0), options_label,
                             (0,0), due_north_degrees_sizer1,
                             (0,0), due_north_degrees_sizer2,
                             (0,0),(0,0),
                             (0, 0), create_markers_sizer,
                             (0, 0), railworks_export_sizer,
                             (0, 0), delete_blueprints_sizer])


        self.run_button = wx.Button(self.main_panel, -1, self.lang["run_button"], size=(self.fW * 0.33,-1))
        self.Bind(wx.EVT_BUTTON, self.evt_run_button, self.run_button)
        self.run_button.SetToolTip(wx.ToolTip(self.lang["tooltip_run"]))
        
        self.blueprint_editor_button = wx.Button(self.main_panel, -1, self.lang["blueprinteditor_button"], size=(self.fW * 0.33,-1))
        self.Bind(wx.EVT_BUTTON, self.evt_blueprint_editor_run, self.blueprint_editor_button)
        self.blueprint_editor_button.SetToolTip(wx.ToolTip(self.lang["tooltip_blueprinteditor"]))

        self.main_cancel_button = wx.Button(self.main_panel, -1, self.lang["cancel_button"], size=(self.fW * 0.33,-1))
        self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, self.main_cancel_button)
        self.main_cancel_button.Enable(False)
        self.main_cancel_button.SetToolTip(wx.ToolTip(self.lang["tooltip_maincancel"]))

        buttons_sizer = wx.FlexGridSizer(cols=5, hgap=hspace, vgap=2*hspace)
        buttons_sizer.AddMany([(0, 0), self.run_button, self.main_cancel_button, self.blueprint_editor_button, (0, 0)])
        
        buttons_status_sizer = wx.FlexGridSizer(cols=3, hgap=hspace, vgap=hspace)
        buttons_status_sizer.AddMany([(0, 0), buttons_sizer, (0, 0),
                             (0, 0), main_window_status_title, (0, 0),
                             (0, 0), self.main_window_status, (0, 0)])
      

        # Ui layout box
        border = wx.BoxSizer(wx.VERTICAL)
        border.Add(title, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(decal_name_sizer, 0, wx.GROW)
        border.AddSpacer(4)
        border.Add(self.previous_runs_sizer, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(self.marker_pairs_sizer, 0, wx.GROW)
        border.AddSpacer(4)
        border.Add(coord_sizer, 0, wx.GROW)
        border.AddSpacer(3)
        border.Add(grab_sizer, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(altitude_sizer, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(chunk_sizer, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(camera_speed_sizer, 0, wx.GROW)
        border.Add(options_sizer, 0, wx.GROW)
        border.AddSpacer(5)
        border.Add(buttons_status_sizer, 0, wx.GROW)
       
        self.main_panel.SetSizer(border)
        self.SetAutoLayout(True)
    

        # debug panel gubbins
        self.debug_panel = wx.lib.scrolledpanel.ScrolledPanel(parent=self, id=-1,style=wx.TAB_TRAVERSAL)
        self.debug_panel.Show(False)
        #self.debug_panel.SetupScrolling()

        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL)
        self.debug_text_area = wx.StaticText(self.debug_panel, -1, "")
        self.debug_text_area.SetFont(font)

        self.debug_line_number = 0

        self.log_output("Started RWDecal Version:  " + VERSION)

        self.sizer=wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.debug_text_area, -1, wx.EXPAND|wx.ALL, 5)

        self.debug_panel.SetSizer(self.sizer)

        hbox = wx.BoxSizer(wx.HORIZONTAL)
        hbox.Add(self.main_panel, 1, wx.EXPAND | wx.ALL, 1)
        hbox.Add(self.debug_panel, 1, wx.EXPAND | wx.ALL, 1)

        self.SetSizer(hbox)

        if eval(self.config["DEBUG"]) == True:
            window_pos = self.GetRect()
            self.debug_panel.Show(True)
            self.SetSize((wX * 2, wY))
            self.SetPosition((window_pos[0] - wX / 2, window_pos[1]))
        else:
            self.debug_panel.Show(False)

        # application is in center of screen
        self.Centre()

        self.get_calibration() # get GE Calibration data

        self.evt_validate_form("")
        
        # update estimate of tiles text
        try:
            ge_calibration_data = self.ge_calibration[self.altitude_options[self.form_settings["ALTITUDE"]]].split(",")
            num_tiles_x = math.ceil(self.capture_area_dimensions[0] / float(ge_calibration_data[0]))
            num_tiles_y = math.ceil(self.capture_area_dimensions[1] / float(ge_calibration_data[1]))
            num_decals_x = math.ceil(self.capture_area_dimensions[0] / float(self.config["MAX_DECAL_SIZE"]))
            num_decals_y  = math.ceil(self.capture_area_dimensions[1] / float(self.config["MAX_DECAL_SIZE"]))
            self.num_tiles.SetLabel(str(int(num_tiles_x * num_tiles_y)) + " " + self.lang["tile"] + "\n" + \
                                str(int(num_decals_x * num_decals_y)) + " " + self.lang["chunk"])
            
            
        except:
            pass

        self.evt_update("",True)

        order = (self.decal_name_text,
                 self.previous_runs_combo, self.previous_delete_button,
                 self.marker_pairs_combo, self.marker_pair_delete, self.bulk_create,
                 self.latLL_text, self.lonLL_text, self.latUR_text,self.lonUR_text,
                 self.grab_ll, self.grab_current, self.grab_ur,
                 self.altitude_choice,
                 self.chunk_choice,
                 self.camera_speed_choice,
                 self.due_north_fix,
                 self.due_north_fix_degrees, self.due_north_fix_auto, self.due_north_fix_chunk_auto,
                 self.create_markers, self.create_markers_choice_full, self.create_markers_choice_chunks,
                 self.railworks_export,
                 self.delete_blueprints,
                 self.run_button, self.main_cancel_button, self.blueprint_editor_button)
        for i in xrange(len(order) - 1):
            order[i+1].MoveAfterInTabOrder(order[i])

        
    def evt_run_button(self,event, do_bulk = False): # start thread for decal processing
        if do_bulk or self.evt_validate_form(event,True) != False:
            if eval(self.config["DEBUG"]) == True:
                for key,value in self.config.items():
                    if key == "LICENSE_KEY":
                        value = "XXXXXXXXXXXX"
                    self.log_output("Configuration " + str(key) + ": " + str(value))
                for key,value in self.form_settings.items():
                    try:
                        self.log_output("Form Setting " +  str(key) + ": " + str(value))
                    except:
                        pass
            if do_bulk and eval(self.config["OVERWRITE_WARNING"]):
                result = self.error_handler(self.lang["message_dobulknooverwritecheck"],
                                            self.lang["message_dobulknooverwritecheck_title"],
                                            wx.YES_NO)
                if result != wx.ID_YES:
                    self.log_output("Bulk decal creation aborted")
                    return False
            elif eval(self.config["OVERWRITE_WARNING"]) and self.check_file_overwrite() == False: # overwite check
                return

            self.lock_form("lock")

            self.cancel_clicked = False
            self.calibrate = False
        
            self.rw_status_window = wx.Frame(self, -1, self.lang["status_window_title"], (0,0),(self.screen_width,50),style=wx.FRAME_NO_TASKBAR)
            self.rw_status_window.Show(True)

            self.cancel_button = wx.Button(self.rw_status_window, -1, self.lang["cancel_button"], pos=(10,10))
            self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, self.cancel_button)

            self.status = wx.StaticText(self.rw_status_window, -1, self.lang["log_geinitialise"],pos=(100,12),style=wx.ALIGN_RIGHT|wx.EXPAND)
            font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
            self.status.SetFont(font)

            self.matrix_info = wx.StaticText(self.rw_status_window, -1, "",pos=(self.screen_width - 270,5),style=wx.ALIGN_RIGHT|wx.EXPAND)
            font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
            self.matrix_info.SetFont(font)
            
            make_decal(self,do_bulk, VERSION).start()

    def make_archive(self, backup_items, zip_name, gauge = False, title = False):
        # open the zip file for writing, and write stuff to it
        archive_path = self.config["INSTALL_PATH"] + "\\backups\\" + zip_name + ".zip"
        self.check_path_exists(archive_path)
        archive = zipfile.ZipFile(archive_path, "w", allowZip64=True)
        for item, base in backup_items.iteritems():
            if self.cancel_clicked:
                self.cancel_clicked = False
                archive.close()
                return False
            if gauge != False:
                gauge.SetValue(gauge.GetValue() + 1)
            if title != False:
                title.SetLabel(self.lang["clean_up_archive_status"].replace("~~file~~",os.path.basename(base)).replace("~~num~~",str(gauge.GetValue())).replace("~~num_of~~",str(len(backup_items))))
            archive.write(item, base, zipfile.ZIP_DEFLATED)

        archive.close()
        return True


    def spider_folder(self, folders, items = False, files_only = False):
        if items == False:
            items = {}
        for folder, base in folders.iteritems():
            for name in glob.glob(folder + "\\*"):
                if os.path.isfile(name): # if is file then archive it
                    items[name] = base + "\\" + os.path.basename(name)
                else:
                    if files_only == False:
                        items[name] = base + "\\" + os.path.basename(name)
                    items = self.spider_folder({name:base + "\\" + os.path.basename(name)}, items, files_only)
        return items

    def evt_validate_backup_options(self,event):
        if self.backup_route_check.GetValue() == False:
            self.backup_assets_check.SetValue(False)
            self.backup_source_check.SetValue(False)
            self.backup_assets_check.Enable(False)
            self.backup_source_check.Enable(False)
        else:
            self.backup_assets_check.Enable(True)
            self.backup_source_check.Enable(True)
            
        
    def evt_take_backup(self,event):
        confirm = wx.Dialog(self, title=self.lang["backup_window_title"], size=(700,220), style=wx.CAPTION|wx.RESIZE_BORDER)

        logo = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo = wx.StaticBitmap(confirm, -1, logo, (10 + logo.GetWidth(), 5))

        title = wx.StaticText(confirm, -1, self.lang["backup_window_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        title.SetFont(font)

        description = wx.StaticText(confirm, -1, self.lang["backup_window_desc"], size=(480,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(480)

        # choices
        route_choices = self.get_routes_list()
        route_choices.insert(0,  self.lang["routestart_chooseroute"])
        #route_check = wx.CheckBox(confirm, -1, self.lang["clean_up_decals_route_check"], wx.DefaultPosition)
        route_choices_combo = wx.ComboBox(confirm, -1, choices=route_choices, style=wx.CB_READONLY)
        route_choices_combo.SetToolTip(wx.ToolTip(self.lang["backup_chooseroute_tooltip"]))
        route_choices_combo.SetSelection(0)
        
        backup_route_check = wx.CheckBox(confirm, -1, self.lang["backup_route_check"], wx.DefaultPosition)
        backup_assets_check = wx.CheckBox(confirm, -1, self.lang["backup_assets_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]), wx.DefaultPosition)
        backup_source_check = wx.CheckBox(confirm, -1, self.lang["backup_source_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]), wx.DefaultPosition)
        choices_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        choices_sizer.Add(route_choices_combo, -1, wx.EXPAND)
        choices_sizer.Add(backup_route_check, -1, wx.EXPAND)
        choices_sizer.Add(backup_assets_check, -1, wx.EXPAND)
        choices_sizer.Add(backup_source_check, -1, wx.EXPAND)

        buttons = confirm.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo, -1, wx.ALL, 0)

        content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        content.Add(title, -1, wx.ALIGN_CENTER)
        content.Add(description, -1)
        content.Add(choices_sizer, -1, wx.ALIGN_CENTER)
        content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, content])
        
        confirm.SetSizer(confirm_sizer)

        result = confirm.ShowModal()
        confirm.Destroy()

        if result == wx.ID_OK:
            # make sure a route was selected
            if route_choices_combo.GetCurrentSelection() == 0: # ignore first item
                self.error_handler(self.lang["clean_up_decals_no_route"], self.lang["clean_up_decals_no_route_title"])
                return False

            else:
                self.route_folder = self.route_details[route_choices_combo.GetLabel()][2]
                self.route_name = route_choices_combo.GetLabel()

            route_path = self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + self.route_folder  + "\\"
            assets_path = self.config["RAILWORKS_PATH"] + "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"
            source_path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"

            backup_folders = {}
            if backup_route_check.GetValue() == True:
                backup_folders[route_path] = "\\Content\\Routes\\" + self.route_folder
            if backup_assets_check.GetValue() == True:
                backup_folders[assets_path] = "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"]
            if  backup_source_check.GetValue() == True:
                backup_folders[source_path] = "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"]

        
            if len(backup_folders) != 0:
                self.cancel_clicked = False
                self.main_panel.Show(False)

                self.gauge_panel = wx.Panel(self, -1, size=(wX,wY),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
                guage_cancel_button = wx.Button(self.gauge_panel, -1, self.lang["cancel_button"], size=(self.fW * 0.33,-1),pos=((wX/2) - ((self.fW * 0.33) / 2),270))
                self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, guage_cancel_button)
                guage_cancel_button.SetToolTip(wx.ToolTip(self.lang["tooltip_maincancel"]))
                self.gauge = wx.Gauge(self.gauge_panel, -1, 1, pos=(2,300), size=((wX - 10),25))
                self.title = wx.StaticText(self.gauge_panel, -1, "\n",size=(wX,-1),pos=(-1,340), style=wx.ALIGN_CENTER|wx.EXPAND|wx.ST_NO_AUTORESIZE)
                self.gauge_panel.Show(True)

                self.lock_form("lock")
                clean_up(self,wX,wY,backup_folders).start()

    def evt_clean_up_decals(self,event):
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        confirm = wx.Dialog(self, title=self.lang["clean_up_decals_window_title"], size=(800,427), style=wx.CAPTION|wx.RESIZE_BORDER)

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(confirm, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(confirm, -1, logo2, (10 + logo2.GetWidth(), 5))


        title = wx.StaticText(confirm, -1, self.lang["clean_up_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        title.SetFont(font)
        
        description = wx.StaticText(confirm, -1, self.lang["clean_up_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        warning = wx.StaticText(confirm, -1, self.lang["clean_up_decals_warning"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        warning.SetFont(font)
        warning.Wrap(580)

        # choices
        route_choices = self.get_routes_list()
        route_choices.insert(0,  self.lang["routestart_chooseroute"])
        route_choices_combo = wx.ComboBox(confirm, -1, choices=route_choices, style=wx.CB_READONLY)
        route_choices_combo.SetToolTip(wx.ToolTip(self.lang["cleanup_chooseroute_tooltip"]))
        route_choices_combo.SetSelection(0)
        
        # backup control
        backup_title = wx.StaticText(confirm, -1, self.lang["clean_up_backup_title"], size=(580,-1))
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        backup_title.SetFont(font)
        self.backup_route_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        self.backup_route_check.SetValue(True)
        self.backup_route_check.Bind(wx.EVT_CHECKBOX, self.evt_validate_backup_options)
        backup_route_check_text = wx.StaticText(confirm, -1, self.lang["clean_up_decals_backup_route_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]), size=(580,-1))
        backup_route_check_text.Wrap(580)
        backup_route_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        backup_route_sizer.Add(self.backup_route_check, -1, wx.EXPAND)
        backup_route_sizer.Add(backup_route_check_text, -1, wx.EXPAND)
        
        self.backup_assets_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        backup_assets_check_text = wx.StaticText(confirm, -1, self.lang["backup_assets_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]), size=(580,-1))
        backup_assets_check_text.Wrap(580)
        backup_assets_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        backup_assets_sizer.Add(self.backup_assets_check, -1, wx.EXPAND|wx.LEFT, 20)
        backup_assets_sizer.Add(backup_assets_check_text, -1, wx.EXPAND)
        
        self.backup_source_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        backup_source_check_text = wx.StaticText(confirm, -1, self.lang["backup_source_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]), size=(580,-1))
        backup_source_check_text.Wrap(580)
        backup_source_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        backup_source_sizer.Add(self.backup_source_check, -1, wx.EXPAND|wx.LEFT, 20)
        backup_source_sizer.Add(backup_source_check_text, -1, wx.EXPAND)


        # control delete of decals
        delete_title = wx.StaticText(confirm, -1, self.lang["clean_up_delete_title"], size=(580,-1))
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        delete_title.SetFont(font)
        self.decal_asset_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        decal_asset_check_text = wx.StaticText(confirm, -1, self.lang["clean_up_decals_assets_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]).replace("~~decals_path~~",self.config["RW_DECALS_PATH"]), size=(580,-1))
        decal_asset_check_text.Wrap(580)
        decal_asset_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        decal_asset_sizer.Add(self.decal_asset_check, -1, wx.EXPAND)
        decal_asset_sizer.Add(decal_asset_check_text, -1, wx.EXPAND)
        
        self.decal_source_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        decal_source_check_text = wx.StaticText(confirm, -1, self.lang["clean_up_decals_source_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]).replace("~~decals_path~~",self.config["RW_DECALS_PATH"]), size=(580,-1))
        decal_source_check_text.Wrap(580)
        decal_source_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        decal_source_sizer.Add(self.decal_source_check, -1, wx.EXPAND)
        decal_source_sizer.Add(decal_source_check_text, -1, wx.EXPAND)
        
        # control delete of markers
        self.marker_asset_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        marker_asset_check_text = wx.StaticText(confirm, -1, self.lang["clean_up_marker_assets_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]).replace("~~markers_path~~",self.config["RW_MARKERS_PATH"]), size=(580,-1))
        marker_asset_check_text.Wrap(580)
        marker_asset_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        marker_asset_sizer.Add(self.marker_asset_check, -1, wx.EXPAND)
        marker_asset_sizer.Add(marker_asset_check_text, -1, wx.EXPAND)
        
        self.marker_source_check = wx.CheckBox(confirm, -1, "", wx.DefaultPosition)
        marker_source_check_text = wx.StaticText(confirm, -1, self.lang["clean_up_marker_source_check"].replace("~~developer~~",self.config["DEVELOPER"]).replace("~~product~~",self.config["PRODUCT"]).replace("~~markers_path~~",self.config["RW_MARKERS_PATH"]), size=(580,-1))
        marker_source_check_text.Wrap(580)
        marker_source_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        marker_source_sizer.Add(self.marker_source_check, -1, wx.EXPAND)
        marker_source_sizer.Add(marker_source_check_text, -1, wx.EXPAND)

        
        # lay it all out
        choices_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        choices_sizer.Add(backup_title, -1, wx.EXPAND)
        choices_sizer.Add(backup_route_sizer, -1, wx.EXPAND)
        choices_sizer.Add(backup_assets_sizer, -1, wx.EXPAND)
        choices_sizer.Add(backup_source_sizer, -1, wx.EXPAND)
        choices_sizer.Add(delete_title, -1, wx.EXPAND)
        choices_sizer.Add(decal_asset_sizer, -1, wx.EXPAND)
        choices_sizer.Add(decal_source_sizer, -1, wx.EXPAND)
        choices_sizer.Add(marker_asset_sizer, -1, wx.EXPAND)
        choices_sizer.Add(marker_source_sizer, -1, wx.EXPAND)


        buttons = confirm.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 5)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)

        content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        content.Add(title, -1, wx.ALIGN_CENTER)
        content.Add(description, -1)
        content.Add(warning, -1, wx.ALIGN_CENTER)
        content.Add(route_choices_combo, -1, wx.ALIGN_CENTER)
        content.Add(choices_sizer, -1, wx.ALIGN_CENTER)
        content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, content])
        
        confirm.SetSizer(confirm_sizer)

        result = confirm.ShowModal()
        confirm.Destroy()

        if result == wx.ID_OK:
            self.cancel_clicked = False
            # make sure a route was selected
            if route_choices_combo.GetCurrentSelection() == 0: # ignore first item
                self.error_handler(self.lang["clean_up_decals_no_route"], self.lang["clean_up_decals_no_route_title"])
                return False

            else:
                self.route_folder = self.route_details[route_choices_combo.GetLabel()][2]
                self.route_name = route_choices_combo.GetLabel()

            self.route_path = self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + self.route_folder  + "\\"
            self.assets_path = self.config["RAILWORKS_PATH"] + "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"
            self.source_path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"

            self.main_panel.Hide()

            self.gauge_panel = wx.Panel(self, -1, size=(wX,wY),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
            self.gauge = wx.Gauge(self.gauge_panel, -1, 1, pos=(2,300), size=((wX - 10),25))
            guage_cancel_button = wx.Button(self.gauge_panel, -1, self.lang["cancel_button"], size=(self.fW * 0.33,-1),pos=((wX/2) - ((self.fW * 0.33) / 2),270))
            self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, guage_cancel_button)
            guage_cancel_button.SetToolTip(wx.ToolTip(self.lang["tooltip_maincancel"]))
            self.title = wx.StaticText(self.gauge_panel, -1, "\n",size=(wX,-1),pos=(-1,340), style=wx.ALIGN_CENTER|wx.EXPAND|wx.ST_NO_AUTORESIZE)
            self.gauge_panel.Show(True)

            self.lock_form("lock")
            clean_up(self,wX,wY).start()

    def evt_load_marker_pairs(self,event, marker_key = False): # load a previous decal settings
        if marker_key == False:
            marker_key = self.marker_pairs_combo.GetValue()
        if marker_key in self.marker_pairs:
            coords = self.marker_pairs[marker_key]
            self.decal_name_text.SetValue(marker_key) # decal name
            self.latLL_text.SetValue(str(coords["LL"][0])) # LL Lat
            self.lonLL_text.SetValue(str(coords["LL"][1])) # LL Lon
            self.latUR_text.SetValue(str(coords["UR"][0])) # UR Lat
            self.lonUR_text.SetValue(str(coords["UR"][1])) # UR Lon
            
            save_pairs = False
            if "ALTITUDE" in coords: # have stored altitude as part of marker pair so use it
                self.altitude_choice.SetSelection(int(coords["ALTITUDE"])) # Altitude
            elif marker_key in self.previous_runs: # no stored altitude so try to see if we have a previous run as use that altitude
                self.marker_pairs[marker_key]["ALTITUDE"] = self.previous_runs[marker_key]["ALTITUDE"]
                self.altitude_choice.SetSelection(int(self.previous_runs[marker_key]["ALTITUDE"])) # Altitude
                save_pairs = True
            else:
                self.marker_pairs[marker_key]["ALTITUDE"] = self.altitude_choice.GetSelection()
                save_pairs = True

            if save_pairs == True: # fixed missing altitude so save marker pairs
                # save data as pickled object
                data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
                pickle.dump(self.marker_pairs, data_file)
                data_file.close()
                

            self.evt_validate_form("") # validate form in case of errors
            self.log_output("Loaded " + marker_key + " marker coordinates")

    def evt_marker_pair_delete(self,event): # delete a marker pair
        if self.marker_pairs_combo.GetValue() in self.marker_pairs:
            self.log_output(self.marker_pairs_combo.GetValue() + " marker pair deleted");
            del self.marker_pairs[self.marker_pairs_combo.GetValue()]
            data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
            pickle.dump(self.marker_pairs, data_file)
            data_file.close()
            self.get_marker_pairs(True)
            

    def evt_bulk_create(self,event): # validate pairs before bulk create
        # store original form settings
        previous_decal_name_text = re.sub("[ ]+"," ",self.decal_name_text.GetValue().strip()) # decal name
        previous_latLL_text = self.latLL_text.GetValue() # LL Lat
        previous_lonLL_text = self.lonLL_text.GetValue() # LL Lon
        previous_latUR_text = self.latUR_text.GetValue() # UR Lat
        previous_lonUR_text = self.lonUR_text.GetValue() # UR Lon
        previous_altitude_choice = self.altitude_choice.GetSelection() # Altitude

        self.bulk_create_decals = list()

        # get all markers with pairs        
        for key in sorted(self.marker_pairs.iterkeys(),key=lambda x: x.lower()):
            if "LL" in self.marker_pairs[key] and "UR" in self.marker_pairs[key]: # we have two key
                # now need to check if they are valid
                # load them into form then validate form
                self.marker_pairs_combo.SetStringSelection(key)# set the combo box to the marker
                self.evt_load_marker_pairs("",key) # load marker pairs
                if self.evt_validate_form("") == False:
                    reason = self.main_window_status.GetLabel()
                    self.error_handler(self.lang["message_bulkdecalinvalid"].replace("~~name~~",key).replace("~~reason~~",reason),
                                       self.lang["message_bulkdecalinvalid_title"])
                else:
                    self.bulk_create_decals.append(key)


        if len(self.bulk_create_decals) > 0:
            # must allow 5 px for v scroll and 80 pixels for buttons and 20 pixels for wrap
            bulk_select = wx.Dialog(self, title=self.lang["bulkselect_window_title"],size=(600,-1), style=wx.CAPTION|wx.RESIZE_BORDER)
            buttons = bulk_select.CreateButtonSizer(wx.OK|wx.CANCEL)
            
            bulk_select_panel = wx.lib.scrolledpanel.ScrolledPanel(bulk_select, -1, size=(590,200))
            bulk_select_panel.SetupScrolling(scroll_x=False, scroll_y=True)

            # create a list of all the checkboxes
            check_boxes = list()
            check_boxes_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
            for item in self.bulk_create_decals:
                check_boxes.append(wx.CheckBox(bulk_select_panel, -1, item, wx.DefaultPosition))

            #title = wx.StaticText(about, -1, self.lang["about_title"].replace("~~name~~"," " + VERSION))
            #font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
            #title.SetFont(font)

            description = wx.StaticText(bulk_select, -1, self.lang["bulkselect_desc"])
            font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
            description.SetFont(font)
            description.Wrap(590)

            # check control
            check_all = GenBitmapTextButton(bulk_select, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\check_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
            uncheck_all = GenBitmapTextButton(bulk_select, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\uncheck_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
            invert = GenBitmapTextButton(bulk_select, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\invert.gif"),size=(16,16),style=wx.ALIGN_CENTER)
            new_only = wx.Button(bulk_select, -1, self.lang["bulkselect_new"])
            # tooltips for check buttons
            check_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_checkall_tooltip"]))
            uncheck_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_uncheckall_tooltip"]))
            invert.SetToolTip(wx.ToolTip(self.lang["bulkselect_invert_tooltip"]))
            new_only.SetToolTip(wx.ToolTip(self.lang["bulkselect_new_tooltip"]))
            # check button actions
            check_all.Bind(wx.EVT_BUTTON, lambda evt, action="check", boxes=check_boxes: self.evt_bulk_check_handler(evt, action, boxes), check_all)
            uncheck_all.Bind(wx.EVT_BUTTON, lambda evt, action="uncheck", boxes=check_boxes: self.evt_bulk_check_handler(evt, action, boxes), uncheck_all)
            invert.Bind(wx.EVT_BUTTON, lambda evt, action="invert", boxes=check_boxes: self.evt_bulk_check_handler(evt, action, boxes), invert)
            new_only.Bind(wx.EVT_BUTTON, lambda evt, action="new", boxes=check_boxes: self.evt_bulk_check_handler(evt, action, boxes), new_only)
            #layout check buttons
            check_control = wx.FlexGridSizer(cols=4, hgap=4, vgap=2*4)
            check_control.Add(check_all, -1, wx.LEFT|wx.RIGHT, 10)
            check_control.Add(uncheck_all, -1, wx.LEFT|wx.RIGHT, 10)
            check_control.Add(invert, -1, wx.LEFT|wx.RIGHT, 10)
            check_control.Add(new_only, -1, wx.LEFT|wx.RIGHT, 10)

            for item in check_boxes:
                item.SetValue(True)
                check_boxes_sizer.Add(item, -1, wx.EXPAND)

            check_boxes_sizer.AddGrowableCol(0);
            check_boxes_sizer.AddGrowableCol(1);
            check_boxes_sizer.AddGrowableCol(2);

            bulk_select_panel.SetSizer(check_boxes_sizer)
            
            scrolling_content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)

            content = wx.FlexGridSizer(cols=1, hgap=4, vgap=4)
            content.Add(description, -1, wx.EXPAND|wx.ALL, 5)
            content.Add(check_control, -1, wx.ALIGN_CENTER)
            content.Add(bulk_select_panel, -1, wx.EXPAND|wx.ALL, 5)
            content.Add(buttons, -1, wx.ALIGN_CENTER|wx.ALL, 5)
            bulk_select.SetSizer(content)
            bulk_select.Fit()

            result = bulk_select.ShowModal()
            bulk_select.Destroy

            if result == wx.ID_OK:
                self.bulk_create_decals = list()
                for item in check_boxes:
                    if item.GetValue() == True:
                        self.bulk_create_decals.append(item.GetLabel())

                if len(self.bulk_create_decals) > 0:
                    result = self.error_handler(self.lang["message_bulkcreate"].replace("~~number~~",str(len(self.bulk_create_decals))),
                                                self.lang["message_bulkcreate_title"],
                                                wx.YES_NO,
                                                wx.ICON_EXCLAMATION)
                    if result == wx.ID_YES:
                        self.evt_run_button("",True) # start off decal creation but with bulk mode
        else:
            self.error_handler(self.lang["message_nobulkdecals"],
                               self.lang["message_nobulkdecals_title"])

        # restore original form settings
        self.decal_name_text.SetValue(previous_decal_name_text) # decal name
        self.latLL_text.SetValue(previous_latLL_text) # LL Lat
        self.lonLL_text.SetValue(previous_lonLL_text) # LL Lon
        self.latUR_text.SetValue(previous_latUR_text) # UR Lat
        self.lonUR_text.SetValue(previous_lonUR_text) # UR Lon
        self.altitude_choice.SetSelection(previous_altitude_choice) # Altitude
        self.marker_pairs_combo.SetSelection(0)

    def evt_bulk_check_handler(self,event,action, check_boxes):
        if action == "check":
            for item in check_boxes:
                if item.IsEnabled():
                    item.SetValue(True)
        elif action == "uncheck":
            for item in check_boxes:
                if item.IsEnabled():
                    item.SetValue(False)
        elif action == "invert":
            for item in check_boxes:
                if item.GetValue() == False:
                    if item.IsEnabled():
                        item.SetValue(True)
                else:
                    if item.IsEnabled():
                        item.SetValue(False)
        elif action == "new":
            # loop through each item and see if any files will be overwritten
            for item in check_boxes:
                self.evt_load_marker_pairs("", item.GetLabel()) # load up form settings
                #print self.form_settings["DECAL_NAME"]
                if self.check_file_overwrite(True):
                    if item.IsEnabled():
                        item.SetValue(True)
                else:
                    if item.IsEnabled():
                        item.SetValue(False)
        return

    def evt_load_previous_run(self,event): # load a previous decal settings
        if self.previous_runs_combo.GetValue() in self.previous_runs:
            if "DECAL_NAME" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.decal_name_text.SetValue(self.previous_runs[self.previous_runs_combo.GetValue()]["DECAL_NAME"]) # decal name
            if "LL_LAT" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.latLL_text.SetValue(self.previous_runs[self.previous_runs_combo.GetValue()]["LL_LAT"]) # LL Lat
            if "LL_LON" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.lonLL_text.SetValue(self.previous_runs[self.previous_runs_combo.GetValue()]["LL_LON"]) # LL Lon
            if "UR_LAT" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.latUR_text.SetValue(self.previous_runs[self.previous_runs_combo.GetValue()]["UR_LAT"]) # UR Lat
            if "UR_LON" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.lonUR_text.SetValue(self.previous_runs[self.previous_runs_combo.GetValue()]["UR_LON"]) # UR Lon
            if "ALTITUDE" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.altitude_choice.SetSelection(int(self.previous_runs[self.previous_runs_combo.GetValue()]["ALTITUDE"])) # Altitude
            if "CHUNK_CHOICE" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.chunk_choice.SetSelection(int(self.previous_runs[self.previous_runs_combo.GetValue()]["CHUNK_CHOICE"])) # Chunk
            if "CAMERA_SPEED" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.camera_speed_choice.SetSelection(int(self.previous_runs[self.previous_runs_combo.GetValue()]["CAMERA_SPEED"])) # Camera Speed
            if "DUE_NORTH_FIX" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.due_north_fix.SetValue(eval(self.previous_runs[self.previous_runs_combo.GetValue()]["DUE_NORTH_FIX"])) # Due North Fix
            if "DUE_NORTH_FIX_DEGREES" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.due_north_fix_degrees.SetValue(str(self.previous_runs[self.previous_runs_combo.GetValue()]["DUE_NORTH_FIX_DEGREES"])) # Degrees for Due North
            if "CREATE_MARKERS" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.create_markers.SetValue(eval(self.previous_runs[self.previous_runs_combo.GetValue()]["CREATE_MARKERS"])) # create markers
            if "CREATE_MARKERS_CHOICE_FULL" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.create_markers_choice_full.SetSelection(int(self.previous_runs[self.previous_runs_combo.GetValue()]["CREATE_MARKERS_CHOICE_FULL"])) # create markers choice full
            if "CREATE_MARKERS_CHOICE_CHUNKS" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.create_markers_choice_chunks.SetSelection(int(self.previous_runs[self.previous_runs_combo.GetValue()]["CREATE_MARKERS_CHOICE_CHUNKS"])) # create markers choice chunks
            if "RAILWORKS_EXPORT" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.railworks_export.SetValue(eval(self.previous_runs[self.previous_runs_combo.GetValue()]["RAILWORKS_EXPORT"])) # export
            if "DELETE_BLUEPRINTS" in self.previous_runs[self.previous_runs_combo.GetValue()]:
                self.delete_blueprints.SetValue(eval(self.previous_runs[self.previous_runs_combo.GetValue()]["DELETE_BLUEPRINTS"])) # delete blueprints
            
            self.evt_validate_form("") # validate form in case of errors

            self.log_output("Loaded " + self.previous_runs_combo.GetValue() + " previous run")
           
            
    def evt_previous_clear(self,event):
        result = self.error_handler(self.lang["message_clearprevious"],
                                    self.lang["message_clearprevious_title"],wx.YES_NO)
        if result == wx.ID_YES:
            self.log_output("Previous Run information cleared")
            if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat") == True:
                os.remove(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat")
            self.get_previous_runs(True)

    def evt_previous_delete_button(self,event): # delete a previous run
        if self.previous_runs_combo.GetValue() in self.previous_runs:
            self.log_output(self.previous_runs_combo.GetValue() + " previous run deleted");
            del self.previous_runs[self.previous_runs_combo.GetValue()]
            data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat", "w")
            pickle.dump(self.previous_runs, data_file)
            data_file.close()
            self.get_previous_runs(True)

    def evt_blueprint_editor_run(self, event):
        try:
            be_window = win32gui.FindWindow("A8A9467F-75E0-4427-8694-ED8596A4BB54","BlueprintEditor")
            win32gui.ShowWindow(be_window, win32con.SW_MAXIMIZE)
        except:
            self.check_path_exists(self.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log")

            if os.path.exists(self.config["RAILWORKS_PATH"] + "\BlueprintEditor.exe"):
                subprocess.Popen(self.config["RAILWORKS_PATH"] + "\BlueprintEditor.exe",cwd=self.config["RAILWORKS_PATH"] + "\\")

            #subprocess.call([self.config["RAILWORKS_PATH"] + "\BlueprintEditor.exe"],
            #                 stdout=open(self.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
            #                 startupinfo=self.startupinfo, cmd=self.config["RAILWORKS_PATH"] + "\"")
            #subprocess.call([self.config["INSTALL_PATH"] + "\\blueprint_editor.bat",
            #                 self.config["RAILWORKS_PATH"] + "\" "],
            #                 stdout=open(self.config["INSTALL_PATH"] + "\\temp\\nul_ouput.log","w"),
            #                 startupinfo=self.startupinfo)

    def evt_grab_start(self, event, name):
        self.lock_form("lock")

        # set to false all variables that the grab class/thread checks for
        self.cancel_clicked = False
        self.grab_now = False
        self.grab_name = ""
        self.start_corner = name
        self.grab_move = False
        self.set_placemark = False
        self.go_placemark = False
        self.set_box = False

        # grab latitude or set to defaults if not contain any numbers
        if name == "ll":
            self.grab_latitude = self.form_settings["LL_LAT"]
            if re.match(".*[0-9].*",self.grab_latitude) == None:
                self.grab_latitude = "53.792419"
            self.grab_longitude = self.form_settings["LL_LON"]
            if re.match(".*[0-9].*",self.grab_longitude) == None:
                self.grab_longitude = "-1.555222"
        elif name== "ur":
            self.grab_latitude = self.form_settings["UR_LAT"]
            if re.match(".*[0-9].*",self.grab_latitude) == None:
                self.grab_latitude = "53.792419"
            self.grab_longitude = self.form_settings["UR_LON"]
            if re.match(".*[0-9].*",self.grab_longitude) == None:
                self.grab_longitude = "-1.555222"
        elif len(name) == 2:
            self.grab_latitude = name[0]
            self.grab_longitude = name[1]
        else:
            self.grab_latitude = ""
            self.grab_longitude = ""

        self.screen_width = GetSystemMetrics(0)
        self.screen_height = GetSystemMetrics(1)

        self.rw_status_window = wx.Frame(self, -1, self.lang["status_window_title"],(0,0),(self.screen_width,100),style=wx.FRAME_NO_TASKBAR)
        self.rw_status_window.Show(True)

        self.cancel_button = wx.Button(self.rw_status_window, -1, self.lang["finished_button"], pos=(3,3), size=(150,20))
        self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, self.cancel_button)
        self.cancel_button.SetToolTip(wx.ToolTip(self.lang["tooltip_finishbutton"]))

        self.marker_options = wx.StaticText(self.rw_status_window, -1, self.lang["grab_markeroptions"], pos=(5,27), size=(150,20),style=wx.ALIGN_CENTER)
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
        self.marker_options.SetFont(font)

        self.grab_decal_name = wx.TextCtrl(self.rw_status_window, -1, self.form_settings["DECAL_NAME"], pos=(3,51), size=(150,20))
        self.Bind(wx.EVT_TEXT, self.evt_grab_decal_name,self.grab_decal_name)
        self.grab_decal_name.SetToolTip(wx.ToolTip(self.lang["tooltip_grabdecalname"]))

        # Altitude selection
        i = 25
        self.grab_altitude_options = self.altitude_option_generate()

        self.grab_altitude_choice = wx.Choice(self.rw_status_window, -1, choices=self.grab_altitude_options, size=(150, 20), pos=(3,74))
        self.grab_altitude_choice.SetSelection(int(self.form_settings["ALTITUDE"]))
        self.grab_altitude_choice.Bind(wx.EVT_CHOICE, self.evt_grab_altitude, self.grab_altitude_choice)
        self.grab_altitude_choice.SetToolTip(wx.ToolTip(self.lang["tooltip_altitude"]))

        self.set_LL_placemark = wx.Button(self.rw_status_window, -1, self.lang["set_ll_placemark"], pos=(157,3),size=(150,20))
        self.set_LL_placemark.Bind(wx.EVT_BUTTON, lambda evt, temp="LL": self.evt_set_placemark(evt, temp))
        self.set_LL_placemark.SetToolTip(wx.ToolTip(self.lang["tooltip_setllplacemark"]))
        self.set_LL_placemark.Enable(False)

        self.go_LL_placemark = wx.Button(self.rw_status_window, -1, self.lang["go_ll_placemark"], pos=(157,27),size=(150,20))
        self.go_LL_placemark.Bind(wx.EVT_BUTTON, lambda evt, temp="LL": self.evt_go_placemark(evt, temp))
        self.go_LL_placemark.SetToolTip(wx.ToolTip(self.lang["tooltip_gotollplacemark"]))
        self.go_LL_placemark.Enable(False)

        self.grab_LL = wx.Button(self.rw_status_window, -1, self.lang["grab_ll_placemark"], pos=(157,51),size=(150,20))
        self.grab_LL.Bind(wx.EVT_BUTTON, lambda evt, temp="LL", move=True: self.evt_do_grab(evt, temp, move))
        self.grab_LL.SetToolTip(wx.ToolTip(self.lang["tooltip_grabll"]))
        self.grab_LL.Enable(False)
        
        self.grab_current_LL = wx.Button(self.rw_status_window, -1, self.lang["grab_ll_current"], pos=(157,74),size=(150,20))
        self.grab_current_LL.Bind(wx.EVT_BUTTON, lambda evt, temp="LL", move=False: self.evt_do_grab(evt, temp, move))
        self.grab_current_LL.SetToolTip(wx.ToolTip(self.lang["tooltip_grabcurrentll"]))
        self.grab_current_LL.Enable(False)

        self.set_UR_placemark = wx.Button(self.rw_status_window, -1, self.lang["set_ur_placemark"], pos=(311,3),size=(150,20))
        self.set_UR_placemark.Bind(wx.EVT_BUTTON, lambda evt, temp="UR": self.evt_set_placemark(evt, temp))
        self.set_UR_placemark.SetToolTip(wx.ToolTip(self.lang["tooltip_seturplacemark"]))
        self.set_UR_placemark.Enable(False)

        self.go_UR_placemark = wx.Button(self.rw_status_window, -1, self.lang["go_ur_placemark"], pos=(311,27),size=(150,20))
        self.go_UR_placemark.Bind(wx.EVT_BUTTON, lambda evt, temp="UR": self.evt_go_placemark(evt, temp))
        self.go_UR_placemark.SetToolTip(wx.ToolTip(self.lang["tooltip_gotourplacemark"]))
        self.go_UR_placemark.Enable(False)

        self.grab_UR = wx.Button(self.rw_status_window, -1, self.lang["grab_ur_placemark"], pos=(311,51),size=(150,20))
        self.grab_UR.Bind(wx.EVT_BUTTON, lambda evt, temp="UR", move=True: self.evt_do_grab(evt, temp, move))
        self.grab_UR.SetToolTip(wx.ToolTip(self.lang["tooltip_grabur"]))
        self.grab_UR.Enable(False)

        self.grab_current_UR = wx.Button(self.rw_status_window, -1, self.lang["grab_ur_current"], pos=(311,74),size=(150,20))
        self.grab_current_UR.Bind(wx.EVT_BUTTON, lambda evt, temp="UR", move=False: self.evt_do_grab(evt, temp, move))
        self.grab_current_UR.SetToolTip(wx.ToolTip(self.lang["tooltip_grabcurrentur"]))
        self.grab_current_UR.Enable(False)

        self.box_title = wx.StaticText(self.rw_status_window, -1, self.lang["box_title"], pos=(465,3), size=(104,20),style=wx.ALIGN_CENTER)
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
        self.box_title.SetFont(font)
 
        self.box_UR = GenBitmapTextButton(self.rw_status_window, -1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\arrow_dl.png"), pos=(465,27), size=(20,20))
        self.box_UR.Bind(wx.EVT_BUTTON, lambda evt, temp="UR", move=False: self.evt_set_box(evt, temp))
        self.box_UR.SetToolTip(wx.ToolTip(self.lang["tooltip_boxur"]))
        self.box_UR.Enable(False)

        self.box_UL = GenBitmapTextButton(self.rw_status_window, -1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\arrow_dr.png"), pos=(491,27), size=(20,20))
        self.box_UL.Bind(wx.EVT_BUTTON, lambda evt, temp="UL", move=False: self.evt_set_box(evt, temp))
        self.box_UL.SetToolTip(wx.ToolTip(self.lang["tooltip_boxul"]))
        self.box_UL.Enable(False)

        self.box_LL = GenBitmapTextButton(self.rw_status_window, -1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\arrow_ur.png"), pos=(517,27), size=(20,20))
        self.box_LL.Bind(wx.EVT_BUTTON, lambda evt, temp="LL", move=False: self.evt_set_box(evt, temp))
        self.box_LL.SetToolTip(wx.ToolTip(self.lang["tooltip_boxll"]))
        self.box_LL.Enable(False)

        self.box_LR = GenBitmapTextButton(self.rw_status_window, -1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\arrow_ul.png"), pos=(543,27), size=(20,20))
        self.box_LR.Bind(wx.EVT_BUTTON, lambda evt, temp="LR", move=False: self.evt_set_box(evt, temp))
        self.box_LR.SetToolTip(wx.ToolTip(self.lang["tooltip_boxlr"]))
        self.box_LR.Enable(False)

        self.box_MID = GenBitmapTextButton(self.rw_status_window, -1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\arrow_mid.png"), pos=(569,27), size=(20,20))
        self.box_MID.Bind(wx.EVT_BUTTON, lambda evt, temp="MID", move=False: self.evt_set_box(evt, temp))
        self.box_MID.SetToolTip(wx.ToolTip(self.lang["tooltip_boxmid"]))
        self.box_MID.Enable(False)

        self.box_size = wx.StaticText(self.rw_status_window, -1, self.lang["box_size"], pos=(465,54), size=(130,20),style=wx.ALIGN_CENTER)
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
        self.box_size.SetFont(font)

        # box selection
        i = 100
        self.box_options = self.box_option_generate()

        self.box_choice = wx.Choice(self.rw_status_window, -1, choices=self.box_options, size=(130, 20), pos=(465,74))
        self.box_choice.SetSelection(int(self.config["BOX_SIZE"]))
        self.box_choice.Bind(wx.EVT_CHOICE, self.evt_grab_box, self.box_choice)
        self.box_choice.SetToolTip(wx.ToolTip(self.lang["tooltip_box"]))

        self.status = wx.StaticText(self.rw_status_window, -1, self.lang["log_geinitialise"], pos=(595,3), size=(self.screen_width-595,100),style=wx.ALIGN_LEFT|wx.EXPAND)
        font = wx.Font(16, wx.NORMAL, wx.NORMAL, wx.BOLD)
        self.status.SetFont(font)
        self.status.Wrap(self.screen_width-595)
        
        grab_location(self).start()
        return

    def evt_do_grab(self,event, name, move): # actually grabs cordinates from GEz
        if move == False:
            self.log_output("Grab Current to " + name + " clicked")
        else:
            self.log_output("Grab " + name + " Placemark clicked")

        # get existing markers (if there are any)
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") != True:
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            
            ge_placemarks = {}
            return
        else:
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat","r")
            #Parse data string.
            try:
                ge_placemarks = pickle.load(f)
            except:
                ge_placemarks = {}


        if move == False: # not moving camera so just grab now
            pass
        elif self.form_settings["DECAL_NAME"] not in ge_placemarks: # make sure we have a placemark
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            return
        elif name not in ge_placemarks[self.form_settings["DECAL_NAME"]]: # make sure we have a placemark
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            return
        else: # have placemark so set move camera params
            self.go_href = self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml#" + self.form_settings["DECAL_NAME"] + " " + self.lang[name.lower()]
            self.go_href = self.go_href.replace("\\","/")
            self.grab_LL.Enable(False)
            self.grab_UR.Enable(False)
            self.grab_current_LL.Enable(False)
            self.grab_current_UR.Enable(False)
            self.set_LL_placemark.Enable(False)
            self.set_UR_placemark.Enable(False)
            self.go_LL_placemark.Enable(False)
            self.go_UR_placemark.Enable(False)

        self.grab_name = name
        self.grab_now = True
        self.grab_move = move
        
        return

    def evt_grab_decal_name(self,event):
        self.form_settings["DECAL_NAME"] = re.sub("[ ]+"," ",self.grab_decal_name.GetValue().strip())
        self.decal_name_text.SetValue(self.form_settings["DECAL_NAME"])

    def evt_grab_box(self,event):
        self.config["BOX_SIZE"] = self.box_choice.GetSelection()
        self.save_config()
    
    def evt_grab_altitude(self,event):
        self.altitude_choice.SetSelection(self.grab_altitude_choice.GetSelection()) # Altitude
        self.form_settings["ALTITUDE"] = self.altitude_choice.GetSelection()

        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "r")
            #Parse data string.
            try:
                ge_placemarks = pickle.load(f)
            except:
                ge_placemarks = {}
        else:
            self.parent.log_output("ge_placemarks.dat file missing")
            ge_placemarks = {}
            
        # attempt to update ge_placemarks.dat
        if self.form_settings["DECAL_NAME"] in ge_placemarks:
            if "ALTITUDE" in ge_placemarks[self.form_settings["DECAL_NAME"]]:
                ge_placemarks[self.form_settings["DECAL_NAME"]]["ALTITUDE"] = self.grab_altitude_choice.GetSelection()

                # save data as pickled object
                data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
                pickle.dump(ge_placemarks, data_file)
                data_file.close()


    def validate_decal_name(self,decal_name):
        if re.match("^[\w\s\(\)\[\]\{\}#]+$",decal_name) == None: # make sure valid string
            message = self.lang["message_baddecalname"]
            title = self.lang["message_baddecalname_title"]

            self.error_handler(message, title)
            return False
        return True

    def evt_set_placemark(self,event,name):
        if self.validate_decal_name(self.form_settings["DECAL_NAME"]):
            self.log_output("Set " + name + " Placemark clicked")
            self.set_placemark = True
            self.marker_name = name
        return

    def evt_set_box(self,event,name):
        if self.validate_decal_name(self.form_settings["DECAL_NAME"]):
            self.log_output("Set " + name + " Box clicked")
            self.set_box = True
            self.box_name = name
        return

    def evt_go_placemark(self,event,name):
        self.log_output("Goto " + name + " Placemark clicked")
        # get existing markers (if there are any)
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") != True:
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            
            ge_placemarks = {}
            return
        else:
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat","r")
            #Parse data string.
            try:
                ge_placemarks = pickle.load(f)
            except:
                ge_placemarks = {}

        if self.form_settings["DECAL_NAME"] not in ge_placemarks:
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            return
        elif name not in ge_placemarks[self.form_settings["DECAL_NAME"]]:
            self.error_handler(self.lang["message_notsetplacemarks"].replace("~~name~~",name) ,
                               self.lang["message_notsetplacemarks_title"])
            return
        else:
            self.go_href = self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml#" + self.form_settings["DECAL_NAME"] + " " + self.lang[name.lower()]
            self.go_href = self.go_href.replace("\\","/")
            self.go_placemark = True
        return

    def evt_cancel_button(self,event): # creates a text file that the processing thread looks for.
        self.log_output("Cancel acknowledged. Waiting for current task to finish .  .  .",
                        self.lang["log_cancelclicked"])
        self.cancel_clicked = True
        try:
            self.cancel_button.Enable(False)
            self.main_cancel_button.Enable(False)
        except:
            pass
    
    def evt_quit(self, event): # what is done when program exits
        if self.run_button.IsEnabled() == False:
            result = self.error_handler(self.lang["message_forcedquit"],
                                   self.lang["message_forcedquit_title"],wx.YES_NO)
            if result != wx.ID_YES:
                return False
           
        self.evt_validate_form("no_event",False)
        if self.config["SAVE_FORM"]:
            self.save_form()
            
        self.Destroy()

    def evt_opensource(self,event):
        try:
            os.system("explorer.exe \"" + self.config["RAILWORKS_PATH"] + "\\Source")
        except:
            pass

    def evt_openassets(self,event):
        try:
            os.system("explorer.exe \"" + self.config["RAILWORKS_PATH"] + "\\Assets")
        except:
            pass

    def evt_openbackups(self,event):
        try:
            os.system("explorer.exe \"" + self.config["INSTALL_PATH"] + "\\Backups")
        except:
            pass
        
    def evt_calibrate(self,event):
        self.lock_form("lock")

        self.cancel_clicked = False
        self.calibrate = True

        self.screen_width = GetSystemMetrics(0)
        self.screen_height = GetSystemMetrics(1)

        self.rw_status_window = wx.Frame(self, -1, self.lang["status_window_title"],(0,0),(self.screen_width,50),style=wx.FRAME_NO_TASKBAR)
        self.rw_status_window.Show(True)

        self.cancel_button = wx.Button(self.rw_status_window, -1, "Cancel", pos=(10,10))
        self.Bind(wx.EVT_BUTTON, self.evt_cancel_button, self.cancel_button)

        self.status = wx.StaticText(self.rw_status_window, -1, self.lang["log_geinitialise"],pos=(100,12),style=wx.ALIGN_RIGHT|wx.EXPAND)
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD)
        self.status.SetFont(font)

        self.ge_calibration = {} # reset calibration data
        make_decal(self,False, VERSION).start()

    def evt_info_button(self,event,name): # info handler
        if name == "decal_info":
            message = self.lang["decal_info"]
            title = self.lang["decal_info_title"]
        elif name == "previous_runs_info":
            message = self.lang["previous_runs_info"]
            title = self.lang["previous_runs_info_title"]
        elif name == "marker_pairs_info":
            message = self.lang["marker_pairs_info"]
            title = self.lang["marker_pairs_info_title"]
        elif name == "lat_info":
            message = self.lang["lat_info"]
            title = self.lang["lat_info_title"]
        elif name == "lon_info":
            message = self.lang["lon_info"]
            title = self.lang["lon_info_title"]
        elif name == "grab_info":
            message = self.lang["grab_info"]
            title = self.lang["grab_info_title"]
        elif name == "altitude_info":
            message = self.lang["altitude_info"]
            title = self.lang["altitude_info_title"]
        elif name == "chunk_info":
            message = self.lang["chunk_info"]
            title = self.lang["chunk_info_title"]
        elif name == "camera_speed_info":
            message = self.lang["camera_speed_info"]
            title = self.lang["camera_speed_info_title"]
        elif name == "due_north_fix_help":
            message = self.lang["due_north_fix_help"]
            title = self.lang["due_north_fix_help_title"]
        elif name == "due_north_fix_info":
            message = self.lang["due_north_fix_info"]
            title = self.lang["due_north_fix_info_title"]
        elif name == "create_markers_info":
            message = self.lang["create_markers_info"]
            title = self.lang["create_markers_info_title"]
        elif name == "railworks_export_info":
            message = self.lang["railworks_export_info"]
            title = self.lang["railworks_export_info_title"]
        elif name == "delete_blueprints_info":
            message = self.lang["delete_blueprints_info"]
            title = self.lang["delete_blueprints_info_title"]
        else:
            message = self.lang[name]
            title = ""
        md = wx.MessageDialog(None, message, title, wx.OK | wx.ICON_INFORMATION)
        result = md.ShowModal()

    def evt_debug_panel_clear(self,event): # clear the debug panel
        self.debug_text_area.SetLabel("")
        #self.debug_panel.SetupScrolling()
        self.debug_line_number = 0
        self.log_output("Cleared debug panel")

    def evt_debug_log_clear(self,event): # clear the log file
        log_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\debug.log", encoding="UTF-8", mode="w")
        log_file.close()
        self.log_output("Cleared debug.log file")

    def evt_save_form(self, event): # save form option changed
        self.config["SAVE_FORM"] = str(event.Checked())
        self.log_output("Save Form on Exit option set to " + str(event.Checked()))
        self.save_config()

    def get_routes_list(self): # get a list of routes
        xml_langs = {}
        # comment out lang
        xml_langs["EN_GB"] = "English"
        xml_langs["FR"] = "French"
        xml_langs["IT"] = "Italian"
        xml_langs["DE"] = "German"
        xml_langs["ES"] = "Spanish"
        xml_langs["NL"] = "Dutch"
        xml_langs["PT"] = "Portuguese"
        xml_langs["DA"] = "Danish"
        xml_langs["SW"] = "Swedish"
        xml_langs["CRO"] = "Croatian"
        
        
        
        # work out route map info from xml route files
        self.route_details = {}
        route_choices = list()

        if os.path.exists(self.config["RAILWORKS_PATH"] + "\\Content\\Routes.xml"): # Rail Simulator
            try:
                route_xml = minidom.parse(self.config["RAILWORKS_PATH"] + "\\Content\\Routes.xml")
                routes = route_xml.getElementsByTagName("DisplayName") # get all the routes as a node list
                for i in range(routes.length): # loop through the routes
                    route_name = ""
                    try: # try to get name based on the RWDecal selected language
                        route_name = routes[i].getElementsByTagName(xml_langs[self.config["LANGUAGE"]])[0].firstChild.data
                    except: # get all names in all languages and accept first one we find
                        try:
                            display_names = route_xml.getElementsByTagName("Localisation-cUserLocalisedString")[i]
                            for o in range(display_names.childNodes.length): # loop through the routes
                                if display_names.childNodes[o].nodeType == 1:
                                    try: # try to get a route name
                                        route_name = display_names.childNodes[o].firstChild.data
                                        if re.match("^[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{12}$",route_name) == None: # make sure is not the character string
                                            break
                                    except:
                                        pass
                        except:
                            pass
                    if len(route_name) == 0: # make sure we have a route name
                        continue
                    # get lat and lon values
                    try: # make sure we have lat and lon
                        route_lat = route_xml.getElementsByTagName("Lat")[i].firstChild.data
                        route_lon = route_xml.getElementsByTagName("Long")[i].firstChild.data
                        route_folder = route_xml.getElementsByTagName("DevString")[i].firstChild.data
                    except: # skip if we fail
                        continue
                    self.route_details[route_name] = (route_lat, route_lon, route_folder)
                    route_choices.append(route_name)
                
                routes = route_xml.getElementsByTagName("DisplayName")
            except:
                pass
            
        route_dirs = os.listdir(self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\")

        # loop through route dir's loading RouteProperties.xml and grabbing needed info
        for route_dir in route_dirs:
            if os.path.exists(self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_dir + "\\RouteProperties.xml"):
                route_name = ""
                route_xml = minidom.parse(self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_dir + "\\RouteProperties.xml")
                try: # try to get name based on the RWDecal selected language
                    route_name = route_xml.getElementsByTagName(xml_langs[self.config["LANGUAGE"]])[0].firstChild.data
                except:
                    display_names = route_xml.getElementsByTagName("Localisation-cUserLocalisedString")[0]
                    for o in range(display_names.childNodes.length): # loop through the routes
                        if display_names.childNodes[o].nodeType == 1:
                            try: # try to get a route name
                                route_name = display_names.childNodes[o].firstChild.data
                                if re.match("^[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{12}$",route_name) == None: # make sure is not the character string
                                    break
                            except:
                                pass
                if len(route_name) == 0: # make sure we have a route name
                    continue

                # get lat and lon values
               
                try: # make sure we have lat and lon
                    route_lat = route_xml.getElementsByTagName("Lat")[0].firstChild.data
                    route_lon = route_xml.getElementsByTagName("Long")[0].firstChild.data
                    route_folder = route_xml.getElementsByTagName("DevString")[0].firstChild.data
                except: # skip if we fail
                    continue
                self.route_details[route_name] = (route_lat, route_lon, route_folder)
                route_choices.append(route_name)

        route_choices.sort()

        return route_choices

    def evt_route_start(self,event,lat = "", lon = ""): # specify start of route
        #print route_xml.toxml()
        route = ""
        if lat == "" and lon == "" and "LATITUDE" in self.route_start and "LONGITUDE" in self.route_start:
            try:
                route = self.route_start["ROUTE"]
            except:
                pass
            lat = self.route_start["LATITUDE"]
            lon = self.route_start["LONGITUDE"]

        if len(route) == 0:
            lat = ""
            lon = ""
            route = ""
            
        routestart = wx.Dialog(self, title=self.lang["routestart_window_title"], size=(780,220), style=wx.CAPTION|wx.RESIZE_BORDER)

        logo = wx.Image(self.config["INSTALL_PATH"] + "\\images\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo = wx.StaticBitmap(routestart, -1, logo, (10 + logo.GetWidth(), 5), (logo.GetWidth(), logo.GetHeight()))

        title = wx.StaticText(routestart, -1, self.lang["routestart_title"], style=wx.ALIGN_CENTER)
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        title.SetFont(font)
        title.Wrap(575)

        description = wx.StaticText(routestart, -1, self.lang["routestart_desc"])
        description.Wrap(575)

        route_choices = self.get_routes_list()

        route_choices.insert(0,  self.lang["routestart_chooseroute"])

        self.route_choices_combo = wx.ComboBox(routestart, -1, choices=route_choices, style=wx.CB_READONLY)
        self.route_choices_combo.Bind(wx.EVT_COMBOBOX, self.evt_load_route_latlon, self.route_choices_combo)
        self.route_choices_combo.SetToolTip(wx.ToolTip(self.lang["routestart_chooseroute_tooltip"]))
        if len(route) == 0:
            self.route_choices_combo.SetSelection(0)
        else:
            self.route_choices_combo.SetStringSelection(route)
            

        lat_label = wx.StaticText(routestart, -1, self.lang["routestart_latitude"],size=(self.fW*0.4 - 4, -1),style=wx.ALIGN_RIGHT)
        lon_label = wx.StaticText(routestart, -1, self.lang["routestart_longitude"],size=(self.fW*0.4 - 4, -1),style=wx.ALIGN_RIGHT)

        self.route_lat_text = wx.TextCtrl(routestart, -1, str(lat), size=(self.fW*0.3 - 4, -1))
        self.route_lat_text.Enable(False)
        self.route_lat_text.SetToolTip(wx.ToolTip(self.lang["tooltip_routestartlat"]))

        self.route_lon_text  = wx.TextCtrl(routestart, -1, str(lon), size=(self.fW*0.3 - 4, -1))
        self.route_lon_text.Enable(False)
        self.route_lon_text.SetToolTip(wx.ToolTip(self.lang["tooltip_routestartlon"]))
        
        coords = wx.FlexGridSizer(cols=2, hgap=4, vgap=4)
        coords.Add(lat_label, -1, wx.ALIGN_RIGHT)
        coords.Add(self.route_lat_text, -1)
        coords.Add(lon_label, -1, wx.ALIGN_RIGHT)
        coords.Add(self.route_lon_text, -1)
        
        buttons = routestart.CreateButtonSizer(wx.OK|wx.CANCEL)

        content = wx.FlexGridSizer(cols=1, hgap=4, vgap=4)
        content.Add(title, -1, wx.ALIGN_CENTER)
        content.Add(description, -1)
        content.Add(self.route_choices_combo, -1, wx.ALIGN_CENTER)
        content.Add(coords, -1, wx.ALIGN_CENTER)
        content.Add(buttons, -1, wx.ALIGN_CENTER)

        routestart_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=4)
        routestart_sizer.AddMany([logo, content])
        
        routestart.SetSizer(routestart_sizer)

        result = routestart.ShowModal()
        routestart.Destroy

        if result == wx.ID_OK:
            lat = re.sub('[^0-9\.-]','',self.route_lat_text.GetValue())
            if re.match("^[-+]?[0-9]*\.?[0-9]+$",lat) == None or float(lat) < -80 or float(lat) > 84: # make sure valid string
                self.error_handler(self.lang["message_badlatroutestart"],
                                   self.lang["message_badlatroutestart_title"])
                self.evt_route_start("",self.route_lat_text.GetValue(),self.route_lon_text.GetValue())
                return
            
            lon = re.sub('[^0-9\.-]','',self.route_lon_text.GetValue())
            if re.match("^[-+]?[0-9]*\.?[0-9]+$",lon) == None or float(lon) < -180 or float(lon) > 180: # make sure valid string
                self.error_handler(self.lang["message_badlonroutestart"],
                                   self.lang["message_badlonroutestart_title"])
                self.evt_route_start("",self.route_lat_text.GetValue(),self.route_lon_text.GetValue())
                return False
            if len(self.route_choices_combo.GetLabel()) == 0:
                self.error_handler(self.lang["message_badrouteroutestart"],
                                   self.lang["message_message_badrouteroutestart_title"])
                self.evt_route_start("",self.route_lat_text.GetValue(),self.route_lon_text.GetValue())
                return False

            # got this far so set values
            self.route_start["ROUTE"] = self.route_choices_combo.GetLabel()
            self.route_start["LATITUDE"] = str(round(float(lat),6))
            self.route_start["LONGITUDE"] = str(round(float(lon),6))

            # save as pickle
            data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\route_start.dat", "w")
            pickle.dump(self.route_start, data_file)
            data_file.close()

            # revalidate form to make rotation get applied
            self.evt_validate_form("")

    def evt_load_route_latlon(self,event):
        if self.route_choices_combo.GetCurrentSelection() == 0: # ignore first item
            self.route_lat_text.SetValue("")
            self.route_lon_text.SetValue("")
            return
        self.route_lat_text.SetValue(self.route_details[self.route_choices_combo.GetLabel()][0])
        self.route_lon_text.SetValue(self.route_details[self.route_choices_combo.GetLabel()][1])
        
            

    def evt_delete_temp_files(self, event): # delete temp files option changed
        self.config["DELETE_TEMP_FILES"] = str(event.Checked())
        self.log_output("Delete temporary files option set to " + str(event.Checked()))
        self.save_config()

    def evt_overwrite_warning(self,event): # overwrite warning option changed
        self.config["OVERWRITE_WARNING"] = str(event.Checked())
        self.log_output("Overwrite Warning option set to " + str(event.Checked()))
        self.save_config()

    def evt_grab_confirmation(self,event): # Grab confirmation option changed
        self.config["GRAB_WARNINGS"] = str(event.Checked())
        self.log_output("Show Grab Confirmation set to " + str(event.Checked()))
        self.save_config()

    def evt_show_splash(self,event): # Grab confirmation option changed
        self.config["SHOW_SPLASH"] = str(event.Checked())
        self.log_output("Show Splash set to " + str(event.Checked()))
        self.save_config()

    def evt_create_center(self,event): # Grab corner centre marker option changed
        self.config["CENTER_MARKERS"] = str(event.Checked())
        self.log_output("Create Google Earth Centre Markers set to " + str(event.Checked()))
        self.save_config()

    def evt_create_4_corner_center(self,event): # Grab 4 corner marker option changed
        self.config["CENTER_4CORNERMARKERS"] = str(event.Checked())
        self.log_output("Create All Four Google Earth Corner Markers set to " + str(event.Checked()))
        self.save_config()

    def evt_change_language(self,event): # Language changed

        ### comment out language
        for key in self.language_options:
            if self.language_options[key][0] == event.GetId():
                self.config["LANGUAGE"] = self.language_options[key][3]
                break
                
##        if event.GetId() == 221:
##            self.config["LANGUAGE"] = "DE"
##        elif event.GetId() == 222:
##            self.config["LANGUAGE"] = "EN_GB"
##        elif event.GetId() == 223:
##            self.config["LANGUAGE"] = "ES"
##        elif event.GetId() == 224:
##            self.config["LANGUAGE"] = "FR"
##       
##        #elif event.GetId() == 225:
##        #    self.config["LANGUAGE"] = "PT"
##        elif event.GetId() == 226:
##            self.config["LANGUAGE"] = "NL"
##        elif event.GetId() == 227:
##            self.config["LANGUAGE"] = "IT"
##        elif event.GetId() == 228:
##            self.config["LANGUAGE"] = "SW"
##        elif event.GetId() == 229:
##            self.config["LANGUAGE"] = "DA"
        
        self.log_output("Language set to " + self.config["LANGUAGE"])
        self.save_config()
        self.error_handler(self.lang["message_changelang"],
                           self.lang["message_changelang_title"],
                           wx.OK,
                           wx.ICON_EXCLAMATION)
        self.evt_quit("")

    def evt_select_language(self,event): # Language changed
        if self.language_combo.GetValue():
            self.config["LANGUAGE"] = self.language_options_code[self.language_combo.GetValue()]
##        if self.language_combo.GetValue() == "English British":
##            self.config["LANGUAGE"] = "EN_GB"
##        elif self.language_combo.GetValue() == "Deutsch":
##            self.config["LANGUAGE"] = "DE"
##        elif self.language_combo.GetValue() == unicode("Espa�ol",):
##            self.config["LANGUAGE"] = "ES"
##        elif self.language_combo.GetValue() == unicode("Fran�ais","cp1252"):
##            self.config["LANGUAGE"] = "FR"
##        # comment out lang
##        #elif self.language_combo.GetValue() == unicode("Portugu�s","cp1252"):
##        #    self.config["LANGUAGE"] = "PT"
##        elif self.language_combo.GetValue() == unicode("Nederlands","cp1252"):
##            self.config["LANGUAGE"] = "NL"
##        elif self.language_combo.GetValue() == unicode("Italiano","cp1252"):
##            self.config["LANGUAGE"] = "IT"
##        elif self.language_combo.GetValue() == unicode("Svenska","cp1252"):
##            self.config["LANGUAGE"] = "SW"
##        elif self.language_combo.GetValue() == unicode("Dansk","cp1252"):
##            self.config["LANGUAGE"] = "DA"
        
            self.log_output("Language set to " + self.config["LANGUAGE"])

    def evt_reduced_capture(self,event): # Capture Area changed

        if event.GetId() == 270:
            self.config["REDUCED_CAPTURE"] = "0.5"
        elif event.GetId() == 271:
            self.config["REDUCED_CAPTURE"] = "0.55"
        elif event.GetId() == 272:
            self.config["REDUCED_CAPTURE"] = "0.6"
        elif event.GetId() == 273:
            self.config["REDUCED_CAPTURE"] = "0.65"
        elif event.GetId() == 274:
            self.config["REDUCED_CAPTURE"] = "0.7"
        elif event.GetId() == 275:
            self.config["REDUCED_CAPTURE"] = "0.75"
        elif event.GetId() == 276:
            self.config["REDUCED_CAPTURE"] = "0.8"
        elif event.GetId() == 277:
            self.config["REDUCED_CAPTURE"] = "0.85"
        elif event.GetId() == 278:
            self.config["REDUCED_CAPTURE"] = "0.9"
        elif event.GetId() == 279:
            self.config["REDUCED_CAPTURE"] = "0.95"
        elif event.GetId() == 280:
            self.config["REDUCED_CAPTURE"] = "1.0"
        self.log_output("Reduced Capture area set to " + self.config["REDUCED_CAPTURE"])
        self.save_config()
        self.error_handler(self.lang["message_changecapturearea"],
                           self.lang["message_changecapturearea_title"])
        self.evt_calibrate(False) # requires re-calibration

    def evt_google_earth_stream_delay(self, event):
        if event.GetId() == 1001:
            self.config["GE_STREAM_DELAY"] = "0"
        elif event.GetId() == 1002:
            self.config["GE_STREAM_DELAY"] = "0.1"
        elif event.GetId() == 1003:
            self.config["GE_STREAM_DELAY"] = "0.25"
        elif event.GetId() == 1004:
            self.config["GE_STREAM_DELAY"] = "0.5"
        elif event.GetId() == 1005:
            self.config["GE_STREAM_DELAY"] = "0.75"
        elif event.GetId() == 1006:
            self.config["GE_STREAM_DELAY"] = "1"
        
        self.log_output("Google Earth Stream Render Delay option set to " + self.config["GE_STREAM_DELAY"])
        self.save_config()

    def evt_decal_quality(self,event): # manage decal quality
        if event.GetId() == 290:
            self.config["DECAL_QUALITY"] = "512"
        elif event.GetId() == 291:
            self.config["DECAL_QUALITY"] = "1024"
        elif event.GetId() == 292:
            self.config["DECAL_QUALITY"] = "2048"
        elif event.GetId() == 293:
            self.config["DECAL_QUALITY"] = "4096"
        self.save_config()

    def evt_decal_maxsize(self,event): # Manage decal chunk size
        if event.GetId() > 286:
            self.error_handler(self.lang["message_maxdecalsize"],
                              self.lang["message_maxdecalsize_title"])
        if event.GetId() == 285:
            self.config["MAX_DECAL_SIZE"] = "300"
        elif event.GetId() == 286:
            self.config["MAX_DECAL_SIZE"] = "400"
        elif event.GetId() == 287:
            self.config["MAX_DECAL_SIZE"] = "500"
        elif event.GetId() == 288:
            self.config["MAX_DECAL_SIZE"] = "600"
        self.save_config()
        self.evt_validate_form("")

    def evt_tile_limit(self,event): # manage tile limit
        if event.GetId() == 295:
            self.config["TILE_LIMIT"] = "150"
        elif event.GetId() == 296:
            self.config["TILE_LIMIT"] = "250"
        elif event.GetId() == 297:
            self.config["TILE_LIMIT"] = "500"
        elif event.GetId() == 298:
            self.config["TILE_LIMIT"] = "750"
        elif event.GetId() == 299:
            self.config["TILE_LIMIT"] = "-1"
        if self.config["TILE_LIMIT"] != "150":
            self.error_handler(self.lang["message_tilelimit"],
                               self.lang["message_tilelimit_title"])
        else:
            self.log_output("Tile Limit option set to " + self.config["TILE_LIMIT"])
        self.save_config()

    def evt_disable_all_ge_layers(self,event): # Disable all GE layers before capture
        self.config["DISABLE_ALL_GE_LAYERS"] = str(event.Checked())
        self.log_output("Disable all Google Earth Layers option set to " + str(event.Checked()))
        self.save_config()
        
    def evt_disable_all_ge_places(self,event): # Disable all GE places before capture
        self.config["DISABLE_ALL_GE_PLACES"] = str(event.Checked())
        self.log_output("Disable all Google Earth Places option set to " + str(event.Checked()))
        self.save_config()

    def evt_reset_grab_markers(self,event): # Remove all RWDecal created markers from GE
        result = self.error_handler(self.lang["message_resetgrabmarkers"],
                                    self.lang["message_resetgrabmarkers_title"],wx.YES_NO)
        if result == wx.ID_YES:
            if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
                os.remove(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat")
            if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml") == True:
                os.remove(self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.kml")
            os.system("copy .\\templates\GoogleEarth\placemark_blank.kml .\\settings\\ge_placemarks.kml > NUL")
            self.get_marker_pairs(True)
            self.get_auto_grab_delete_options()

    def evt_reset_grab_markers_auto(self,event, marker_set): # Remove all RWDecal auto created markers from GE
        result = self.error_handler(self.lang["message_resetgrabmarkers_auto"].replace("~name~",marker_set),
                                    self.lang["message_resetgrabmarkers_auto_title"],wx.YES_NO)
        if result == wx.ID_YES:
            if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
                f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "r")
                ge_placemarks = pickle.load(f)

            else:
                ge_placemarks = {}

            for key in ge_placemarks.keys():
                if "AUTO" in ge_placemarks[key] and ge_placemarks[key]["AUTO"] and "AUTO_SET_NAME" in ge_placemarks[key] and ge_placemarks[key]["AUTO_SET_NAME"] == marker_set:
                    del ge_placemarks[key]

            data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
            pickle.dump(ge_placemarks, data_file)
            data_file.close()

            os.system("copy .\\templates\GoogleEarth\placemark_blank.kml .\\settings\\ge_placemarks.kml > NUL")
            self.get_marker_pairs(True)
            self.get_auto_grab_delete_options()
            

    def evt_create_ge_polygons(self, event):
        self.config["CREATE_GE_POLYGONS"] = str(event.Checked())
        self.log_output("Create Polygons when Grabbing Markers set to " + str(event.Checked()))
        self.save_config()

    def evt_tidy_stray_markers(self,event):
        for key in sorted(self.marker_pairs.iterkeys(),key=lambda x: x.lower()):
            if "LL" not in self.marker_pairs[key] or "UR" not in self.marker_pairs[key]: # we have one key
                del self.marker_pairs[key]
                # save data as pickled object
        data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
        pickle.dump(self.marker_pairs, data_file)
        data_file.close()
        self.get_marker_pairs(True)
        self.log_output("Single Google Earth placemarks have been tidied");

    def evt_anti_alias(self,event): # aplies antialiasing to decal rotation
        self.config["ANTIALIAS_DECALS"] = str(event.Checked())
        self.log_output("Antialiased Decals set to " + str(event.Checked()))
        self.save_config()

    def evt_chunk_overlap(self,event): # Applies a 2% overlap to decal chunks
        self.config["CHUNK_OVERLAP"] = str(event.Checked())
        self.log_output("2% Chunk Overlap set to set to " + str(event.Checked()))
        self.save_config()

    def evt_due_north_auto(self, coords): # whether or not to estimate the due north fix rotation whenever the form changes
        if "LATITUDE" not in self.route_start or "LONGITUDE" not in self.route_start:
            result = self.error_handler(self.lang["message_missingroutecoords"],
                               self.lang["message_missingroutecoords_title"],
                               wx.YES_NO)
            if result == wx.ID_YES:
                self.evt_route_start("")
            self.form_settings["AUTO_ROTATE"] = "False"
            self.due_north_fix_auto.SetValue(False)
            return 0
        rotation = round(calc_rotation(coords[0],coords[1],coords[2],self.route_start["LATITUDE"], self.route_start["LONGITUDE"]),6)
        return rotation


    def evt_improvement_program(self,event):# improvement program option changed
        self.config["IMPROVEMENT_PROGRAM"] = str(event.Checked())
        self.log_output("Take Part in RWDecal Improvement Program option set to " + str(event.Checked()))
        self.save_config()
        if event.Checked():
            self.error_handler(self.lang["message_improvementthanks"],
                               self.lang["message_improvementthanks_title"])

    def evt_debug(self,event): # debug option changed
        window_pos = self.GetRect()
        if event.Checked():
            self.debug_panel.Show(True)
            self.SetSize((wX * 2, wY))
            self.SetPosition((window_pos[0] - wX / 2, window_pos[1]))
            self.debug_text_area.Show(True)
        else:
            self.debug_panel.Show(False)
            self.SetSize((wX, wY))
            self.SetPosition((window_pos[0] + wX / 2, window_pos[1]))
            self.debug_text_area.SetLabel("")
            self.debug_line_number = 0
        self.config["DEBUG"] = str(event.Checked())
        self.log_output("Debug option set to " + str(event.Checked()))
        if event.Checked():
            self.error_handler(self.lang["message_debugslow"],
                               self.lang["message_debugslow_title"])
        self.save_config()

    def evt_show_working_path(self,event): # shows the current working path
        self.error_handler(self.lang["message_workingpath"].replace("~~path~~",self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"),
                           self.lang["message_workingpath_title"])

    def evt_settings_railworks_path(self,event): # specify railworks path
        self.choose_railworks_path(True)
        self.choose_developer_folder()
        self.choose_product_folder()
        self.save_config()
        self.validate_config(True)

    def evt_settings_developer_folder(self,event): # specify developer folder
        self.choose_developer_folder(True)
        self.choose_product_folder()
        self.save_config()
        self.validate_config(True)

    def evt_settings_product_folder(self,event): # specify product folder
        self.choose_product_folder(True)
        self.save_config()
        self.validate_config(True)

    def evt_settings_rwacetool_location(self,event): # specify RWACeTool Location
        result = self.choose_rw_ace(True)
        if result != False:
            self.save_config()

    def evt_about(self,event):
        about = wx.Dialog(self, title=self.lang["about_window_title"], size=(600,220),style=wx.RESIZE_BORDER)

        logo = wx.Image(self.config["INSTALL_PATH"] + "\\images\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo = wx.StaticBitmap(about, -1, logo, (10 + logo.GetWidth(), 5), (logo.GetWidth(), logo.GetHeight()))


        title = wx.StaticText(about, -1, self.lang["about_title"].replace("~~name~~"," " + VERSION))
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        title.SetFont(font)
        description = wx.StaticText(about, -1, self.lang["about_desc"], size=(400,-1), style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        description.SetFont(font)

        if self.licensed:
            licensed_to = self.lang["about_licensed"].replace("~~name~~",self.license_details["USERNAME"])
            link = wx.Button(about, -1, "www.rwdecal.co.uk/support")
            link.Bind(wx.EVT_BUTTON, lambda evt, temp="rwdecal_support": self.evt_visit_link(evt, temp))
            
        else:
            licensed_to = self.lang["about_unlicensed"]
            link = wx.Button(about, -1, "www.rwdecal.co.uk")
            link.Bind(wx.EVT_BUTTON, lambda evt, temp="rwdecal": self.evt_visit_link(evt, temp))
        details = wx.StaticText(about, -1,  self.lang["about_details"].replace("~~name~~",VERSION) + " " + licensed_to)
        details.Wrap(400)

        buttons =  about.CreateButtonSizer(wx.OK)

        content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        content.Add(title, -1, wx.ALIGN_CENTER)
        content.Add(description, -1, wx.ALIGN_CENTER)
        content.Add(details, -1)
        content.Add(link, -1, wx.ALIGN_CENTER)
        content.Add(buttons, -1, wx.ALIGN_CENTER)

        about_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        about_sizer.AddMany([logo, content])
        
        about.SetSizer(about_sizer)

        about.ShowModal()
        about.Destroy
        

    def evt_visit_link(self,event,link): # info handler
        if link == "rwdecal_support":
            webbrowser.open("http://www.rwdecal.co.uk/support",2,1)
        elif link == "rwdecal":
            webbrowser.open("http://www.rwdecal.co.uk",2,1)

    def evt_donate(self,event):
        self.error_handler(self.lang["message_donate"],
                           self.lang["message_donate_title"])
        webbrowser.open("http://www.rwdecal.co.uk/donate",2,1)

    def evt_online_support(self,event):
        webbrowser.open("http://www.rwdecal.co.uk/support",2,1)

    def evt_update(self,event,at_start = False):
        if at_start and (int(self.config["UPDATE_CHECK_FREQUENCY"]) == -1 or float(self.config["LAST_UPDATE_CHECK"]) > time.time() - float(self.config["UPDATE_CHECK_FREQUENCY"])):
            return

        try: # try to connect to web and check updates
            url = 'http://www.rwdecal.co.uk/latest_version.txt?random=' + str(random.randrange(0,10000000))
            req = urllib2.Request(url)
            response = urllib2.urlopen(req, timeout=2)
            outcome = response.read()
            outcome = self.parse_config(outcome)
        except:
            self.error_handler(self.lang["message_failedupdatecheck"],
                               self.lang["message_failedupdatecheck_title"])
            pass
            
        else:
            if int(outcome["major_version"]) > MAJOR_VERSION or (int(outcome["major_version"]) == MAJOR_VERSION and int(outcome["minor_version"]) > MINOR_VERSION) or (int(outcome["major_version"]) == MAJOR_VERSION and int(outcome["minor_version"]) == MINOR_VERSION and int(outcome["build"]) > BUILD):
                result = self.error_handler(self.lang["message_updateavailable"].replace("~~version~~",VERSION).replace("~~major_version~~",outcome["major_version"]).replace("~~minor_version~~",outcome["minor_version"]).replace("~~build~~",outcome["build"]).replace("~~release~~",outcome["release"]).replace("~~update_url~~",outcome["update_url"]),
                                   self.lang["message_updateavailable_title"], wx.YES_NO)
                if result == wx.ID_YES:
                    webbrowser.open(outcome["update_url"],2,1)
                    return
                
                
            elif at_start == False:
                self.error_handler(self.lang["message_uptodate"].replace("~~version~~",VERSION).replace("~~major_version~~",outcome["major_version"]).replace("~~minor_version~~",outcome["minor_version"]).replace("~~build~~",outcome["build"]).replace("~~release~~",outcome["release"]),
                                   self.lang["message_uptodate_title"])

        if at_start:
            self.config["LAST_UPDATE_CHECK"] = str(time.time())
            self.save_config()
        return

    def evt_update_control(self,event):
        if event.GetId() ==311:
            self.config["UPDATE_CHECK_FREQUENCY"] = "-1"
        elif event.GetId() == 312:
            self.config["UPDATE_CHECK_FREQUENCY"] = "0"
        elif event.GetId() == 313:
            self.config["UPDATE_CHECK_FREQUENCY"] = "86400"
        elif event.GetId() == 314:
            self.config["UPDATE_CHECK_FREQUENCY"] = "604800"

        self.log_output("heck for update frequency changed to " + self.config["UPDATE_CHECK_FREQUENCY"])
        self.save_config()

    def evt_enter_license(self,event): # enter license option clicked
        self.enter_license()
        if self.licensed:
            self.help.Remove(303)
            self.help.Remove(304)

    def evt_pdf_manual(self,event): # Load PDF Manual from HD
        self.load_pdf_manual()

    def evt_validate_form(self,event,show_errors = False, coords_only = False, alt_clicked = False): # validate the form (on form change and on run)
        try:
            block = self.run_button.IsEnabled()
        except:
            block = True
            
        if block == True:
            self.main_window_status.SetLabel(self.lang["status_ready"])

        #remove degree signs from lat / lon as this makes pasting from google earth easier
        self.form_settings["LL_LAT"] = re.sub('[^0-9\.-]','',self.latLL_text.GetValue())
        if re.match("^[-+]?[0-9]*\.?[0-9]+$",self.form_settings["LL_LAT"]) == None or float(self.form_settings["LL_LAT"]) < -90 or float(self.form_settings["LL_LAT"]) > 90: # make sure valid string
            message = self.lang["message_badlatll"]
            title = self.lang["message_badlatll_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if show_errors:
            self.latLL_text.SetValue(self.form_settings["LL_LAT"])
        self.form_settings["UR_LAT"] = re.sub('[^0-9\.-]','',self.latUR_text.GetValue())
        if re.match("^[-+]?[0-9]*\.?[0-9]+$",self.form_settings["UR_LAT"]) == None or float(self.form_settings["UR_LAT"]) < -90 or float(self.form_settings["LL_LAT"]) > 90: # make sure valid string
            message = self.lang["message_badlatur"]
            title = self.lang["message_badlatur_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if show_errors:
            self.latUR_text.SetValue(self.form_settings["UR_LAT"])
        self.form_settings["LL_LON"] = re.sub('[^0-9\.-]','',self.lonLL_text.GetValue())
        if re.match("^[-+]?[0-9]*\.?[0-9]+$",self.form_settings["LL_LON"]) == None or float(self.form_settings["LL_LON"]) < -180 or float(self.form_settings["LL_LAT"]) > 180: # make sure valid string
            message = self.lang["message_badlonll"]
            title = self.lang["message_badlonll_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if show_errors:
            self.lonLL_text.SetValue(self.form_settings["LL_LON"])
        self.form_settings["UR_LON"] = re.sub('[^0-9\.-]','',self.lonUR_text.GetValue())
        if re.match("^[-+]?[0-9]*\.?[0-9]+$",self.form_settings["UR_LON"]) == None or float(self.form_settings["UR_LON"]) < -180 or float(self.form_settings["LL_LAT"]) > 180: # make sure valid string
            message = self.lang["message_badlonur"]
            title = self.lang["message_badlonur_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if show_errors:
            self.lonUR_text.SetValue(self.form_settings["UR_LON"])
            
        if float(self.form_settings["UR_LAT"]) <= float(self.form_settings["LL_LAT"]):
            message = self.lang["message_badlat"]
            title = self.lang["message_badlat_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if float(self.form_settings["UR_LON"]) <= float(self.form_settings["LL_LON"]):
            message = self.lang["mesasge_badlon"]
            title = self.lang["mesasge_badlon_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False
        if coords_only:
            return True
        

        if coords_only == False: # needed here to allow processing of checkbox enabling etc correctly
            self.form_settings["DUE_NORTH_FIX"] = str(self.due_north_fix.IsChecked())
            self.form_settings["AUTO_ROTATE"] = str(self.due_north_fix_auto.IsChecked())
            if self.due_north_fix_auto.IsChecked() and self.main_cancel_button.IsEnabled() == False: # do not check anything if:
                self.Unbind(wx.EVT_TEXT, self.due_north_fix_degrees)
                try:
                    coords = (float(self.form_settings["LL_LAT"]) + ((float(self.form_settings["UR_LAT"]) - float(self.form_settings["LL_LAT"])) / 2.0),
                              float(self.form_settings["LL_LON"]) + ((float(self.form_settings["UR_LON"]) - float(self.form_settings["LL_LON"])) / 2.0),
                              float(self.form_settings["UR_LAT"]))
                    self.due_north_fix_degrees.SetLabel(str(self.evt_due_north_auto(coords)))
                except:
                    pass
            elif self.main_cancel_button.IsEnabled() == False:
                if eval(self.form_settings["DUE_NORTH_FIX"]):
                    self.due_north_fix_degrees.Enable(True)
                self.due_north_fix_auto.Enable(True)
                
            self.form_settings["AUTO_ROTATE"] = str(self.due_north_fix_auto.IsChecked())
            self.form_settings["AUTO_ROTATE_CHUNK_LOCK"] = str(self.due_north_fix_chunk_auto.IsChecked())

            if eval(self.form_settings["DUE_NORTH_FIX"]) and self.main_cancel_button.IsEnabled() == False:
                self.due_north_fix_degrees.Enable(True)
                self.due_north_fix_auto.Enable(True)
                if eval(self.form_settings["AUTO_ROTATE"]) == False:
                    self.Bind(wx.EVT_TEXT, self.evt_validate_form, self.due_north_fix_degrees)
                    self.due_north_fix_degrees.Enable(True)
                    self.due_north_fix_chunk_auto.Enable(False)
                else:
                    self.due_north_fix_degrees.Enable(False)
                    self.due_north_fix_chunk_auto.Enable(True)
            elif self.main_cancel_button.IsEnabled() == False:
                self.due_north_fix_degrees.Enable(False)
                self.due_north_fix_auto.Enable(False)
                self.due_north_fix_chunk_auto.Enable(False)
                
            
                
            self.form_settings["DUE_NORTH_FIX_DEGREES"] = re.sub('[^0-9\.-]','',self.due_north_fix_degrees.GetValue())
            if eval(self.form_settings["DUE_NORTH_FIX"]) == True and (re.match("^[-+]?[0-9]*\.?[0-9]+$",self.form_settings["DUE_NORTH_FIX_DEGREES"]) == None or float(self.form_settings["DUE_NORTH_FIX_DEGREES"]) < -5 or float(self.form_settings["DUE_NORTH_FIX_DEGREES"]) > 5): # make sure valid string
                message = self.lang["message_badrotation"]
                title = self.lang["message_badrotation_title"]
                if show_errors:
                    self.error_handler(message, title)
                elif block == True:
                    self.main_window_status.SetLabel(title + ": " + message)
                    self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
                return False
                
            self.form_settings["CREATE_MARKERS"] = str(self.create_markers.IsChecked())
            if eval(self.form_settings["CREATE_MARKERS"]) and self.main_cancel_button.IsEnabled() == False:
                self.create_markers_choice_full.Enable(True)
                self.create_markers_choice_chunks.Enable(True)
            elif self.main_cancel_button.IsEnabled() == False:
                self.create_markers_choice_full.Enable(False)
                self.create_markers_choice_chunks.Enable(False)
            
            self.form_settings["DECAL_NAME"] = re.sub("[ ]+"," ",self.decal_name_text.GetValue().strip())
            if re.match("^[\w\s\[\]\(\)\{\}#]+$",self.form_settings["DECAL_NAME"]) == None: # make sure valid string
                message = self.lang["message_baddecalname"]
                title = self.lang["message_baddecalname_title"]
                if show_errors:
                    self.error_handler(message, title)
                elif block == True:
                    self.main_window_status.SetLabel(title + ": " + message)
                    self.main_window_status.Wrap(self.fW +15 - 4 * 2)
                return False

            if len(self.form_settings["DECAL_NAME"]) > 20:
                message = self.lang["message_toolongdecalname"]
                title = self.lang["message_toolongdecalname_title"]
                if show_errors:
                    self.error_handler(message, title)
                elif block == True:
                    self.main_window_status.SetLabel(title + ": " + message)
                    self.main_window_status.Wrap(self.fW +15 - 4 * 2)
                return False

            self.form_settings["RAILWORKS_EXPORT"] = str(self.railworks_export.IsChecked())
            if eval(self.form_settings["RAILWORKS_EXPORT"]) == False:
                self.delete_blueprints.Enable(False)
            elif self.main_cancel_button.IsEnabled() == False:
                self.delete_blueprints.Enable(True)
                self.form_settings["DELETE_BLUEPRINTS"] = str(self.delete_blueprints.IsChecked())
    
        # recalculate dimensions
        # vincenty
        self.capture_area_dimensions = (round(self.vinc_dist(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["LL_LAT"]),  float(self.form_settings["UR_LON"])),3),
                                            round(self.vinc_dist(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["UR_LAT"]),  float(self.form_settings["LL_LON"])),3))
        # haversine
        #self.capture_area_dimensions = (self.calc_seperation_in_meters(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["LL_LAT"]),  float(self.form_settings["UR_LON"])),
        #                                    self.calc_seperation_in_meters(float(self.form_settings["LL_LAT"]),  float(self.form_settings["LL_LON"]),  float(self.form_settings["UR_LAT"]),  float(self.form_settings["LL_LON"])))

        if self.capture_area_dimensions[0] > 1000:
            self.width_text.SetLabel(str(round(self.capture_area_dimensions[0]/1000.0,2)) +"k" + self.lang["meters_wide"])
        else:
            self.width_text.SetLabel(str(round(self.capture_area_dimensions[0],2)) + self.lang["meters_wide"])
        if self.capture_area_dimensions[1] > 1000:
            self.height_text.SetLabel(str(round(self.capture_area_dimensions[1]/1000.0,2)) + "k"  + self.lang["meters_high"])
        else:
            self.height_text.SetLabel(str(round(self.capture_area_dimensions[1],2)) + self.lang["meters_high"])

        self.form_settings["ALTITUDE"] = self.altitude_choice.GetSelection()
        try:
            if alt_clicked and self.form_settings["DECAL_NAME"] in self.marker_pairs and \
               "LL" in self.marker_pairs[self.form_settings["DECAL_NAME"]] and \
               "UR" in self.marker_pairs[self.form_settings["DECAL_NAME"]]:
                self.marker_pairs[self.form_settings["DECAL_NAME"]]["ALTITUDE"] = self.form_settings["ALTITUDE"]
                data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat", "w")
                pickle.dump(self.marker_pairs, data_file)
                data_file.close()
        except:
            pass

        # estimate tiles
        try:
            ge_calibration_data = self.ge_calibration[self.altitude_options[self.form_settings["ALTITUDE"]]].split(",")
            num_tiles_x = math.ceil(self.capture_area_dimensions[0] / float(ge_calibration_data[0]))
            num_tiles_y = math.ceil(self.capture_area_dimensions[1] / float(ge_calibration_data[1]))
            num_decals_x = math.ceil(self.capture_area_dimensions[0] / float(self.config["MAX_DECAL_SIZE"]))
            num_decals_y  = math.ceil(self.capture_area_dimensions[1] / float(self.config["MAX_DECAL_SIZE"]))
            self.num_tiles.SetLabel(str(int(num_tiles_x * num_tiles_y)) + " " + self.lang["tile"] + "\n" + \
                                    str(int(num_decals_x * num_decals_y)) + " " + self.lang["chunk"])
        except:
            return
        
        if block == False:
            return True

        self.form_settings["CHUNK_CHOICE"] = self.chunk_choice.GetSelection()

        self.form_settings["CAMERA_SPEED"] = self.camera_speed_choice.GetSelection()

        self.form_settings["CREATE_MARKERS_CHOICE_FULL"] = self.create_markers_choice_full.GetSelection()
        self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"] = self.create_markers_choice_chunks.GetSelection()
        if eval(self.form_settings["CREATE_MARKERS"]) and self.form_settings["CHUNK_CHOICE"] == 1 and self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"] != 0:
            message = self.lang["message_invalidmarkers"]
            title = self.lang["message_invalidmarkers_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False

        # warn of large decal and ask if need to cancel
        if int(num_tiles_x * num_tiles_y) > int(self.config["TILE_LIMIT"]) and int(self.config["TILE_LIMIT"]) > 0:
            message = self.lang["message_numtilesabort"].replace("~~name~~",self.config["TILE_LIMIT"])
            title = self.lang["message_numtilesabort_title"]
            if show_errors:
                self.error_handler(message, title)
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
            return False

        elif show_errors and int(num_tiles_x * num_tiles_y) > 100:
            result = self.error_handler(self.lang["message_numtileswarning"],
                          self.lang["message_numtileswarning_title"], wx.YES_NO)
            if result != wx.ID_YES:
                return False
            

        if show_errors and int(num_decals_x * num_decals_y) > 50 and self.form_settings["CHUNK_CHOICE"] != 1 :
            result = self.error_handler(self.lang["message_numdecalswarning"].replace("~~number~~",str(int(num_decals_x * num_decals_y))),
                          self.lang["message_numdecalswarning_title"], wx.YES_NO)
            if result != wx.ID_YES:
                return False

        if self.licensed == False and int(self.form_settings["ALTITUDE"]) < 19:
            message = self.lang["message_unlicensedalt"]
            title = self.lang["message_unlicensedalt_title"]
            if show_errors:
                result = self.error_handler(message, title, wx.OK|wx.CANCEL)
                if result != wx.ID_OK:
                    return False
            elif block == True:
                self.main_window_status.SetLabel(title + ": " + message)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)

        return True
     

    def save_form(self):
        last_settings = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\last_settings.dat", encoding="UTF-8", mode="w")
        for key in sorted(self.form_settings.iterkeys(),key=lambda x: x.lower()):
            last_settings.write(key + '=' + unicode(self.form_settings[key]) + "\r\n")
        last_settings.close()

    def load_marker_pairs(self):
        # no file so return false
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat") == True:
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat","r")
            #Parse data string.
            try:
                self.marker_pairs = pickle.load(f)
            except:
                self.marker_pairs = {}

        else:
            self.marker_pairs = {}

    def get_marker_pairs(self,update = False, no_enable = False):
        self.load_marker_pairs()
        
        marker_pairs_choice = list()

        for key in sorted(self.marker_pairs.iterkeys(),key=lambda x: x.lower()):
            if "LL" in self.marker_pairs[key] and "UR" in self.marker_pairs[key]:
                marker_pairs_choice.append(key)

        marker_pairs_choice.sort()


                                  
        if len(marker_pairs_choice) != 0:
            default_value = self.lang["marker_pairsselect"]
            marker_pairs_choice.insert(0,  default_value)
        else:
            default_value = self.lang["marker_pairsdesc"]
            marker_pairs_choice.append(default_value)

        if update == False:
            self.marker_pair_delete = wx.Button(self.main_panel, -1, self.lang["marker_pairsdelete"], size=(self.fW * 0.2 - 4,-1))
            self.Bind(wx.EVT_BUTTON, self.evt_marker_pair_delete, self.marker_pair_delete)
            self.marker_pair_delete.SetToolTip(wx.ToolTip(self.lang["tooltip_markerpairdelete"]))
            if not no_enable:
                self.marker_pair_delete.Enable(True)

            self.bulk_create = wx.Button(self.main_panel, -1, self.lang["marker_pairscreateall"], size=(self.fW * 0.2 - 4,-1))
            self.Bind(wx.EVT_BUTTON, self.evt_bulk_create, self.bulk_create)
            self.bulk_create.SetToolTip(wx.ToolTip(self.lang["tooltip_bulkcreate"]))
            if not no_enable:
                self.bulk_create.Enable(True)
        
            self.marker_pairs_combo = wx.ComboBox(self.main_panel, -1, choices=marker_pairs_choice, size=(self.fW*0.4 - 3, -1),style=wx.CB_READONLY)
            self.Bind(wx.EVT_COMBOBOX, self.evt_load_marker_pairs, self.marker_pairs_combo)
            self.marker_pairs_combo.SetToolTip(wx.ToolTip(self.lang["tooltip_markerpairs"]))
        else:
            if not no_enable:
                self.marker_pairs_combo.Enable(True)
                self.bulk_create.Enable(True)
                self.marker_pair_delete.Enable(True)
                self.prefs.Enable(210,True)
            self.marker_pairs_combo.Clear()
            for choice in marker_pairs_choice:
                self.marker_pairs_combo.Append(choice)
        if len(marker_pairs_choice) == 1:
            if not no_enable:
                self.marker_pairs_combo.Enable(False)
                self.marker_pair_delete.Enable(False)
                self.bulk_create.Enable(False)
                self.prefs.Enable(210,False)
                self.prefs.Enable(2203,False)


        self.marker_pairs_combo.SetSelection(0)
            

        return True

    def get_previous_runs(self, update = False, data = False, do_bulk = False):
        # get previous run
        self.previous_runs = {}

        
        
        # if file exists in route of settings then need to copy to developer folder
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\previous_runs.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\previous_runs.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\previous_runs.dat")
            
        # no file so return false
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat") == True:
            self.previous_runs
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat","r")
            #Parse data string.
            try:
                self.previous_runs = pickle.load(f)
            except:
                self.previous_runs = {}

        previous_runs_choice = list()
        if update != False and data != False: # add this form setting to array and to form items list
            self.previous_runs[data["DECAL_NAME"]] = data
            self.save_previous_run()
       
        if len(self.previous_runs) != 0:
            for key in self.previous_runs:
                previous_runs_choice.append(key)
            previous_runs_choice.sort()
            default_value = self.lang["previous_runs_select"]
            previous_runs_choice.insert(0,  default_value)
        else:
            default_value = self.lang["previous_runs_desc"]
            previous_runs_choice.append(default_value)

        if update == False: # not updating so must be first run
            self.previous_delete_button = wx.Button(self.main_panel, -1, self.lang["previous_runs_delete"], size=(self.fW * 0.2 - 4,-1))
            self.Bind(wx.EVT_BUTTON, self.evt_previous_delete_button, self.previous_delete_button)
            self.previous_delete_button.SetToolTip(wx.ToolTip(self.lang["tooltip_previousdelete"]))
            self.previous_runs_combo = wx.ComboBox(self.main_panel, -1, choices=previous_runs_choice, size=(self.fW*0.6 - 4, -1),style=wx.CB_READONLY)
            self.Bind(wx.EVT_COMBOBOX, self.evt_load_previous_run, self.previous_runs_combo)
            self.previous_runs_combo.SetToolTip(wx.ToolTip(self.lang["tooltip_previousruns"]))
        else:
            if do_bulk == False:
                self.previous_runs_combo.Enable(True)
                self.previous_delete_button.Enable(True)
                self.prefs.Enable(217,True)
            self.previous_runs_combo.Clear()
            for choice in previous_runs_choice:
                self.previous_runs_combo.Append(choice)
        if len(self.previous_runs) == 0:
            self.previous_runs_combo.Enable(False)
            self.previous_delete_button.Enable(False)
            self.prefs.Enable(217,False)

        self.previous_runs_combo.SetSelection(0)
            

        return True

    def save_previous_run(self):
        self.check_path_exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat")
        # save data as pickled object
        data_file = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\previous_runs.dat","w")
        pickle.dump(self.previous_runs, data_file)
        data_file.close()

        #self.previous_clear_button.Enable(True)


    def get_last_use_settings(self):
        # get last use settings
        # no config file so get defaults
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\last_settings.dat") != True:
            self.form_settings["DECAL_NAME"]="Leeds Station"
            self.form_settings["LL_LON"]="-1.555222"
            self.form_settings["LL_LAT"]="53.792419"
            self.form_settings["UR_LON"]="-1.542621"
            self.form_settings["UR_LAT"]="53.795136"
            self.form_settings["ALTITUDE"]="19"
            self.form_settings["CHUNK_CHOICE"]="0"
            self.form_settings["CAMERA_SPEED"]="3"
            self.form_settings["DUE_NORTH_FIX"]="False"
            self.form_settings["DUE_NORTH_FIX_DEGREES"]="0"                    
            self.form_settings["CREATE_MARKERS"]="True"
            self.form_settings["CREATE_MARKERS_CHOICE_FULL"]="1"
            self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]="1"
            self.form_settings["RAILWORKS_EXPORT"]="True"
            self.form_settings["DELETE_BLUEPRINTS"]="True"
            self.form_settings["AUTO_ROTATE"] = "False"
            self.form_settings["AUTO_ROTATE_CHUNK_LOCK"] = "False"
            self.form_settings["ALTITUDE_KML_PRIMARY"] = "7"
            self.form_settings["ALTITUDE_KML_SECONDARY"] = "10"
            self.form_settings["KML_AREA"] = "7"
            self.form_settings["KML_DISTANCE"] = "5"
            self.form_settings["KML_LAST_DIR"] = os.path.expanduser("~") + "\\Desktop"
        else:
            f = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\last_settings.dat", encoding='UTF-8', mode="r")
            data = f.read()
            f.close()
            self.form_settings = self.parse_config(data)

        # incorrect number of settings so return to defaults
        if len(self.form_settings) != 22:
            self.form_settings = {} # make sure start from blank
            self.form_settings["DECAL_NAME"]="Leeds Station"
            self.form_settings["LL_LON"]="-1.555222"
            self.form_settings["LL_LAT"]="53.792419"
            self.form_settings["UR_LON"]="-1.542621"
            self.form_settings["UR_LAT"]="53.795136"
            self.form_settings["ALTITUDE"]="19"
            self.form_settings["CHUNK_CHOICE"]="0"
            self.form_settings["CAMERA_SPEED"]="3"
            self.form_settings["DUE_NORTH_FIX"]="False"
            self.form_settings["DUE_NORTH_FIX_DEGREES"]="0"   
            self.form_settings["CREATE_MARKERS"]="True"
            self.form_settings["CREATE_MARKERS_CHOICE_FULL"]="1"
            self.form_settings["CREATE_MARKERS_CHOICE_CHUNKS"]="2"
            self.form_settings["RAILWORKS_EXPORT"]="True"
            self.form_settings["DELETE_BLUEPRINTS"]="True"
            self.form_settings["AUTO_ROTATE"] = "False"
            self.form_settings["AUTO_ROTATE_CHUNK_LOCK"] = "False"
            self.form_settings["ALTITUDE_KML_PRIMARY"] = "7"
            self.form_settings["ALTITUDE_KML_SECONDARY"] = "10"
            self.form_settings["KML_AREA"] = "7"
            self.form_settings["KML_DISTANCE"] = "7"
            self.form_settings["KML_LAST_DIR"] = os.path.expanduser("~") + "\\Desktop"
            

    def log_output(self, message, update_status = False, fatal = False):
        if not "DEBUG" in self.config or eval(self.config["DEBUG"]) == True or fatal == True:
            message = re.sub("\s+",' ',message)
            now = datetime.datetime.now()

            if os.path.exists(self.config["INSTALL_PATH"] + "\\debug.log") == True:
                os.remove(self.config["INSTALL_PATH"] + "\\debug.log");

            self.check_path_exists(self.config["INSTALL_PATH"] + "\\settings\\debug.log")
            log_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\debug.log", encoding="UTF-8", mode="a")
            log_file.write(u"[" + now.strftime("%d %b %Y - %H:%M:%S") + "] " + message + "\r\n")
            log_file.close()
            
            try:
                self.debug_line_number += 1
                existing = self.debug_text_area.GetLabel()
                existing = existing.split("\n");
                if len(existing) > 200:
                    existing = existing[:200]
                self.debug_text_area.SetLabel(str(self.debug_line_number).zfill(4) + ": " + message + " [" + now.strftime("%H:%M:%S") + "]\n" + "\n".join(existing))
                self.debug_text_area.Wrap(wX - 30)
                #self.debug_panel.SetupScrolling()
                
            except:
                pass
        if update_status != False:
            try:
                self.main_window_status.SetLabel(update_status)
                self.main_window_status.Wrap(self.fW + 25 - 4 * 2)
                self.status.SetLabel(update_status)
                self.status.Wrap(self.screen_width-595)
                
            except:
                pass
            
        
    def parse_config(self,s,slash_n_replace = False, slash_t_replace = False):
        """Parse a string into a dictionary."""
        #Fetch a *copy* of the default dictionary.
        ret = {}
        #Split lines.
        s = s.lstrip( unicode( codecs.BOM_UTF8, "utf8" ) )
        lines = s.split("\n")
        #Loop through lines.
        for line in lines:
            #try:
            #    print line
            #except:
            #    pass
            #Strip whitespace.
            line = line.strip()
            #Skip comment and blank lines.
            if line and line[0] != "#":
                #Split the line in the pair key, value
                breaker = line.find('=')
                # skip if line does not contain an equals sign
                if breaker <= 0:
                    break
                key = line[0:breaker].strip()
                value = line[breaker+1:len(line)].strip()
                if slash_n_replace == True:
                    value = value.replace("\\n","\n")
                if slash_t_replace == True:
                    value = value.replace("\\t","\t")
                    
                #Fill dictionary.
                ret[key] = value
        #Return dictionary.
        return ret
            
    def error_handler(self, message, title, buttons = wx.OK, icon = wx.ICON_EXCLAMATION, fatal = False):
        self.log_output(title + ":\t" + message,False,fatal)
        md = wx.MessageDialog(None,message,title,buttons | icon)
        result = md.ShowModal()
        if fatal == True:
            sys.exit()
        else:
            return result

    def check_flag(self):
        # create list of files we need to check
        flag_files = list()
        #flag_files.append("RWDecal_flag.bin")
        flag_files.append("RWDecal_flag.GeoPcDx")
        #flag_files.append("RWDecal_flag_editor.xml")
        flag_files.append("RWDecal_flag_editor.bin")
        flag_files.append("Textures\\RW_decal.TgPcDx")
        flag_files.append("Textures\\RW_decal_nm.TgPcDx")
        flag_files.append("Textures\\RW_decal_nmc.TgPcDx")

        # what is path to assets
        assets_path = self.config["RAILWORKS_PATH"] + "\\Assets\\Kuju\\RailSimulatorCore\\RouteMarkers\\"

        copied = False
        
        # loop through files and check they exist
        for flag_file in flag_files:
            # template file exists and assets file is the file missing or the modifed date not equal the template version
            if os.path.exists(self.config["INSTALL_PATH"] + "\\templates\\railworks\\RWDecal_flag\\" + flag_file) == True and (os.path.exists(assets_path + flag_file) != True or os.path.getmtime(assets_path + flag_file) != os.path.getmtime(self.config["INSTALL_PATH"] + "\\templates\\railworks\\RWDecal_flag\\" + flag_file)):
                if os.path.exists(assets_path + flag_file):
                    os.remove(assets_path + flag_file)

                self.check_path_exists(assets_path + flag_file)
                # copy file ignoring replace
                shutil.copy(self.config["INSTALL_PATH"] + "\\templates\\railworks\\RWDecal_flag\\" + flag_file,assets_path + flag_file)
                
                copied = True

        if copied:
            if os.path.exists(self.config["RAILWORKS_PATH"] + "\\Assets\\Kuju\\RailSimulatorCore\\Blueprints.pak") == True:
                os.remove(self.config["RAILWORKS_PATH"] + "\\Assets\\Kuju\\RailSimulatorCore\\Blueprints.pak")

    def get_config(self):           
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\config.dat") == True:
            f = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\config.dat", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()
            self.config = self.parse_config(data)

        self.config["INSTALL_PATH"] = INSTALL_PATH

        self.get_language_list()

        if "LANGUAGE" not in self.config or len(self.config["LANGUAGE"]) == 0: # no config so need to select a language
            choose_lang = wx.Dialog(self, title="Choose a Language", size=(550,220),style=wx.CAPTION|wx.RESIZE_BORDER)

            logo = wx.Image(self.config["INSTALL_PATH"] + "\\images\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
            logo = wx.StaticBitmap(choose_lang, -1, logo, (10 + logo.GetWidth(), 5), (logo.GetWidth(), logo.GetHeight()))


            label = wx.StaticText(choose_lang, -1, "Please select a language:\n"\
                                  "Selecteer een taal:\n"\
                                  "S'il vous pla�t choisir une langue:\n"\
                                  "V�lg et sprog:\n"\
                                  "Bitte w�hlen Sie eine Sprache:\n"\
                                  "Si prega di selezionare una lingua:\n"\
                                  "Por favor selecione um idioma:",
                                  # comment out lang
                                  #"Por favor, seleccione un idioma:\n"\
                                  #"Si prega di selezionare una lingua:",
                                  size=(350,-1),
                                  style=wx.ALIGN_CENTER)
            font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
            label.SetFont(font)

            choices = list()
            for lang_code in self.language_options:
                choices.append(self.language_options[lang_code][1])
            choices.sort()
            i = 0
            for choice in choices:
                if choice == "English British":
                    set_selection = i
                i = i + 1
        
            self.language_combo = wx.ComboBox(choose_lang, -1, choices=choices, size=(self.fW*0.4 - 3, -1),style=wx.CB_READONLY)
            self.language_combo.SetSelection(set_selection)

            buttons = choose_lang.CreateButtonSizer(wx.OK)

            content_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
            content_sizer.Add(label, -1, wx.ALIGN_CENTER)
            content_sizer.Add(self.language_combo, -1, wx.ALIGN_CENTER)
            content_sizer.Add(buttons, -1, wx.ALIGN_CENTER)
            
            choose_lang_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4,)
            choose_lang_sizer.AddMany([logo, content_sizer])
            
            choose_lang.SetSizer(choose_lang_sizer)

            choose_lang.ShowModal()
            self.evt_select_language(self)
            choose_lang.Destroy
            

        # make sure a lang is set
        if "LANGUAGE" not in self.config:
            self.config["LANGUAGE"] = "EN_GB"
            
        self.language_file() # Load language file
        self.validate_config() # validate config file

        if "USERNAME" in self.config and "LICENSE_KEY" in self.config: # transfer license details
            license_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="w")
            license_file.write("USERNAME=" + str(self.config["USERNAME"]) + "\n")
            license_file.write("LICENSE_KEY=" + str(self.config["LICENSE_KEY"]) + "\n")
            license_file.close()
            del self.config["USERNAME"]
            del self.config["LICENSE_KEY"]
            self.save_config()
        self.check_license() # check and set license status

        # move files to correct locations during upgrade from previous versions
        self.check_path_exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat")
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\ge_placemarks.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\ge_placemarks.dat")
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\assets_decals.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\assets_decals.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\assets_decals.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\assets_decals.dat")
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\assets_markers.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\assets_markers.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\assets_markers.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\assets_markers.dat")
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\source_decals.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\source_decals.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\source_decals.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\source_decals.dat")
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\source_markers.dat") == True:
            shutil.copy(self.config["INSTALL_PATH"] + "\\settings\\source_markers.dat",self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\source_markers.dat")
            os.remove(self.config["INSTALL_PATH"] + "\\settings\\source_markers.dat")

        if len(self.config) != 35: # not right number of config settings so reset
            config_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\config.dat", encoding="UTF-8", mode="w")
            license_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="w")
            if self.licensed: # attempt to bring any license details into reset config file
                license_file.write("USERNAME=" + str(self.license_details["USERNAME"]) + "\n")
                license_file.write("LICENSE_KEY=" + str(self.license_details["LICENSE_KEY"]) + "\n")
            config_file.close()
            license_file.close()
            self.error_handler(self.lang["message_invalidconfig"],
                               self.lang["message_invalidconfig_title"],wx.OK, wx.ICON_EXCLAMATION, True)

        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\hidden_config.dat"):
            f = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\hidden_config.dat", encoding="UTF-8", mode="r")
            data = f.read()
            f.close()
            self.hidden_config = self.parse_config(data)

        self.get_route_start()

    def get_route_start(self):
        self.check_path_exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\route_start.dat")
        
        # no file so return false
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\route_start.dat") == True:
            f = open(self.config["INSTALL_PATH"] + "\\settings\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\route_start.dat", "r")
            #Parse data string.
            try:
                self.route_start = pickle.load(f)
            except:
                self.route_start = {}

        else:
            self.route_start = {}

    def get_calibration(self):
        self.ge_calibration = {}
        if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\ge_calibration.dat") != True:
            #self.finished_calibrate = False
            self.log_output("ge_calibration.dat file missing")
            self.error_handler(self.lang["message_missinggecalib"],
                               self.lang["message_missinggecalib_title"],wx.OK)
            self.evt_calibrate(False) # run a calibration cycle
        else:
            f = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\ge_calibration.dat",encoding="UTF-8", mode="r")
            data = f.read()
            f.close()
            self.ge_calibration = self.parse_config(data)
            if len(self.ge_calibration) != self.num_calibrations: # not right number of calibration settings so reset
                os.remove(self.config["INSTALL_PATH"] + "\\settings\\ge_calibration.dat")
                self.error_handler(self.lang["message_invalidgecalib"],
                                   self.lang["message_invalidgecalib_title"],wx.OK, wx.ICON_EXCLAMATION)
                self.evt_calibrate(False) # run a calibration cycle
            

    def check_license(self,just_entered = False):
        # get license details
        if just_entered == False:
            if os.path.exists(self.config["INSTALL_PATH"] + "\\settings\\license.dat") == True:
                f = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="r")
                data = f.read()
                f.close()
                self.license_details = self.parse_config(data)

            elif self.enter_license(True) == False:
                self.licensed = True
                # change to false to re-enable license system
                return

        if "USERNAME" not in self.license_details or "LICENSE_KEY" not in self.license_details:
            self.licensed = True
            # change to false to re-enable license system
            return
        
        # Work out if have a valid license
        license_decode_string = "qwertyuiopQWERTYUIOPasdfghjklASDFGHJKLzxcvbnmZXCVBNM"

        mangled_username = ''
        for char in range(0, len(self.license_details["USERNAME"])):
            char_pos = license_decode_string.find(self.license_details["USERNAME"][char]) + 1 # find each character from the name in the LICENSE_DECODE string and return the position advanced by 10
            if char_pos == -1: # ignore if can't find character
                continue
            if char_pos >= len(license_decode_string): # if character position + 1 takes us past the end of the string then start again from the beginning
                char_pos -= len(license_decode_string)
            new_char = license_decode_string[char_pos] #
            mangled_username += new_char


        # create a MD5 hash of the new name
        license_code = hashlib.md5()
        license_code.update(mangled_username)

        if self.license_details["LICENSE_KEY"] == str(license_code.hexdigest()[0:12]): # we only use first 12 chracters of the MD5 so check if license code in config matches what we have generated
            self.log_output("RWDecal licensed to: " + str(self.license_details["USERNAME"]))
            self.licensed = True

        else:
            self.log_output("RWDecal is unrestricted and 100% free!")
            self.licensed = True
            # change to false to re-enable license system

    def enter_license(self,ask = False):
        if ask == True: # ask user if they want to enter license details
            result = self.error_handler(self.lang["message_enterlicensenow"], self.lang["message_enterlicensenow_title"],wx.YES_NO)
            if result != wx.ID_YES:
                self.license_details["USERNAME"] = "Unrestricted and 100% Free!"
                self.license_details["LICENSE_KEY"] = "Free"
                license_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="w")
                for key in sorted(self.license_details.iterkeys(),key=lambda x: x.lower()):
                    license_file.write(key + '=' + str(self.license_details[key]) + "\n")
                license_file.close()
                return False
            
        dlg = wx.TextEntryDialog(None, self.lang["message_enterlicensename"],self.lang["message_enterlicensename_title"])

        if dlg.ShowModal() == wx.ID_OK:
            self.license_details["USERNAME"] = dlg.GetValue()
        else:
            dlg.Destroy()
            self.license_details["USERNAME"] = "Unrestricted and 100% Free!"
            self.license_details["LICENSE_KEY"] = "Free"
            return False
        dlg.Destroy()

        dlg = wx.TextEntryDialog(None, self.lang["message_enterlicensekey"], self.lang["message_enterlicensekey_title"])

        if dlg.ShowModal() == wx.ID_OK:
            self.license_details["LICENSE_KEY"] = dlg.GetValue()
        else:
            self.license_details["USERNAME"] = "Unrestricted and 100% Free!"
            self.license_details["LICENSE_KEY"] = "Free"
            dlg.Destroy()
            return False
        dlg.Destroy()

        self.check_license(True)
        if self.licensed == True:
            self.error_handler(self.lang["message_licensesuccess"].replace("~~name~~",str(self.license_details["USERNAME"])),
                               self.lang["message_licensesuccess_title"],wx.OK)
            license_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="w")
            for key in sorted(self.license_details.iterkeys(),key=lambda x: x.lower()):
                license_file.write(key + '=' + str(self.license_details[key]) + "\n")
            license_file.close()
            if ask == False:
                self.evt_validate_form("")
            return True
        else:
            self.license_details["USERNAME"] = "Unrestricted and 100% Free!"
            self.license_details["LICENSE_KEY"] = "Free"
            self.error_handler(self.lang["message_licensefail"],
                               self.lang["message_licensefail_title"],wx.OK)
            license_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\license.dat", encoding="UTF-8", mode="w")
            for key in sorted(self.license_details.iterkeys(),key=lambda x: x.lower()):
                license_file.write(key + '=' + str(self.license_details[key]) + "\n")
            license_file.close()
            return False

    def choose_railworks_path(self, new = False):
        # first specify railworks location if current path is bad
        # check for likely folders
        if not "RAILWORKS_PATH" in self.config or os.path.exists(self.config["RAILWORKS_PATH"] + "\\serz.exe") != True or new == True:
            if "RAILWORKS_PATH" in self.config and os.path.exists(self.config["RAILWORKS_PATH"]) == True:
                path = self.config["RAILWORKS_PATH"]
            elif os.path.exists("C:\\Program Files\\Steam\\steamapps\\common\\railworks\\serz.exe") == True: # RailWorks x32
                path = "C:\\Program Files\\Steam\\steamapps\\common\\railworks\\"
            elif os.path.exists("C:\\Program Files (x86)\\Steam\\steamapps\\common\\railworks\\serz.exe") == True: # RailWorks x64
                path = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\railworks\\"
            elif os.path.exists("C:\\Program Files\\railsimulator\\serz.exe") == True: # RailSimulator x32
                path = "C:\\Program Files\\railsimulator\\"
            elif os.path.exists("C:\\Program Files (x86)\\railsimulator\\serz.exe") == True: # RailWorks x64
                path = "C:\\Program Files (x86)\\railsimulator\\"
            else:
                path = "C:\\Program Files"
            dialog = wx.FileDialog ( None, message = self.lang["railworks_message"],
                                     style = wx.FD_OPEN,
                                     defaultDir=path,
                                     defaultFile="serz.exe",
                                     wildcard="serz.exe") 
            found = False
            while found == False:           
                # Call the dialog as a model-dialog so we're required to choose Ok or Cancel   
                if dialog.ShowModal() == wx.ID_OK:   
                    # User has selected something, get the path, set the window's title to the path   
                    filename = dialog.GetPath()
                    if os.path.exists(filename) and re.match(".*(\\\|/)serz.exe$",filename,re.IGNORECASE):
                        found = True
                        self.config["RAILWORKS_PATH"] = dialog.GetDirectory()
                        self.log_output("Railworks/RailSimulator folder selected: \"" + str(self.config["RAILWORKS_PATH"]) + "\"")
                        dialog.Destroy()
                        self.save_config()
                        if new == True: # need to make sure change does not stuff up product folder selection
                            self.error_handler(self.lang["message_railworkspathchange"],
                                               self.lang["message_railworkspathchange_title"])
                            self.validate_config()
                    else:
                        self.error_handler(self.lang["message_invalidrailworks"], self.lang["message_invalidrailworks_title"])
                        return False
                    
                elif new == False:
                    found = False
                    dialog.Destroy()
                    return False

    def choose_rw_ace(self, new = False):
        # specify location of RWAce tool
        if not "RW_ACE_PATH" in self.config or os.path.exists(self.config["RW_ACE_PATH"]) != True or new == True:
            if os.path.exists(self.config["INSTALL_PATH"] + "\\RWAceTool"):
                path = self.config["INSTALL_PATH"] + "\\RWAceTool"
            else:
                path = self.config["INSTALL_PATH"] + "\\"
            dialog = wx.FileDialog ( None, message = self.lang["rwace_message"],
                                     style = wx.FD_OPEN,
                                     defaultDir=path,
                                     defaultFile="RWAceTool.exe",
                                     wildcard="RWAceTool.exe")

            found = False
            while found == False:           
                # Call the dialog as a model-dialog so we're required to choose Ok or Cancel   
                if dialog.ShowModal() == wx.ID_OK:   
                    # User has selected something, get the path, set the window's title to the path   
                    filename = dialog.GetPath()
                    if os.path.exists(filename) and re.match(".*(\\\|/)RWAceTool.exe$",filename,re.IGNORECASE):
                        found = True
                        self.config["RW_ACE_PATH"] = filename
                        self.log_output("RWAcetool located: \"" + str(self.config["RW_ACE_PATH"]) + "\"")
                        dialog.Destroy()
                        self.save_config()
                    else:
                        self.error_handler(self.lang["message_invalidrwacetool"], self.lang["message_invalidrwacetool_title"])
                    
                else:
                    found = False
                    dialog.Destroy()
                    return False
            

    def choose_developer_folder(self,new = False):
        # specify developer folder
        if not "DEVELOPER" in self.config or os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\") != True or new == True:
            if "DEVELOPER" in self.config and os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"]) == True:
                path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"]
            elif os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\") == True:
                path = self.config["RAILWORKS_PATH"] + "\\Source\\"
            else:
                path = self.config["RAILWORKS_PATH"] + "\\"
            dialog = wx.DirDialog ( None, message = self.lang["developer_message"],
                                    defaultPath=path) 
           
            # Call the dialog as a model-dialog so we're required to choose Ok or Cancel   
            if dialog.ShowModal() == wx.ID_OK:
                # User has selected something, get the path, set the window's title to the path  
                # make sure that the folder is within railworks source folder
                if re.match(re.escape(self.config["RAILWORKS_PATH"] + "\\Source\\"),dialog.GetPath(),re.IGNORECASE) == None: # make sure valid string
                    self.log_output("Invalid DEVELOPER folder selected: " + dialog.GetPath(),False,True)
                    dialog.Destroy()
                    return False
                self.config["DEVELOPER"] = re.sub("(?i)" + re.escape(self.config["RAILWORKS_PATH"] + "\\Source\\"),'',dialog.GetPath())
                self.log_output("Developer folder selected: \"" + str(self.config["DEVELOPER"]) + "\"")
                dialog.Destroy()
                self.save_config()
                if new == True: # need to make sure change does not stuff up product folder selection
                    self.error_handler(self.lang["message_developerpathchange"],
                                       self.lang["message_developerpathchange_title"])
                    self.validate_config()
                if new:
                    # reload markers and previous runs because product may have changed
                    self.get_previous_runs(True)
                    self.get_marker_pairs(True)
                    self.get_route_start()
                    self.evt_validate_form("")

            elif new == False:
                dialog.Destroy()
                return False


    def choose_product_folder(self,new = False):
        # specify product folder
        if not "PRODUCT" in self.config or os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\") != True or new == True:
            if "PRODUCT" in self.config and os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\") == True:
                path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"
            elif os.path.exists(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\") == True:
                path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\"
            else:
                path = self.config["RAILWORKS_PATH"] + "\\"
            dialog = wx.DirDialog ( None, message = self.lang["product_message"],
                                    defaultPath=path) 
           
            # Call the dialog as a model-dialog so we're required to choose Ok or Cancel   
            if dialog.ShowModal() == wx.ID_OK:
                # User has selected something, get the path, set the window's title to the path
                # make sure that the folder is within railworks source folder
                if re.match(re.escape(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\"),dialog.GetPath(),re.IGNORECASE) == None: # make sure valid string
                    self.log_output("Invalid PRODUCT folder selected: " + dialog.GetPath(),False,True)
                    dialog.Destroy()
                    return False
                self.config["PRODUCT"] = re.sub("(?i)" + re.escape(self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\"),'',dialog.GetPath())
                self.log_output("Product folder selected: \"" + str(self.config["PRODUCT"]) + "\"")
                dialog.Destroy()
                self.save_config()
                if new:
                    # reload markers and previous runs because product may have changed
                    self.get_previous_runs(True)
                    self.get_marker_pairs(True)
                    self.error_handler(self.lang["message_productsettings"],
                                       self.lang["message_productsettings_title"])
                    self.get_route_start()
                    self.evt_validate_form("")
            elif new == False:
                dialog.Destroy()
                return False

    def load_pdf_manual(self): # load PDF Manual
        if self.config["LANGUAGE"] == "IT":
            file_name = "RWDecal Documentazione IT.pdf"
        elif self.config["LANGUAGE"] == "DE":
            file_name = "RWDecal Documentation DE.pdf"
        else:
            file_name = "RWDecal Documentation EN_GB.pdf"
        try:
            os.startfile('"' + self.config["INSTALL_PATH"] + '\\Documentation\\' + file_name + '"')
        except:
            os.system("explorer.exe \"" + self.config["INSTALL_PATH"] + "\\Documentation\\" + file_name)
        self.log_output("RWDecal PDF Manual Loaded")

    def save_config(self,config = False, log = True):
        if config == False:
            config = self.config
        config_file = codecs.open(self.config["INSTALL_PATH"] + "\\settings\\config.dat", encoding="UTF-8", mode="w")
        for key in sorted(self.config.iterkeys(),key=lambda x: x.lower()):
            config_file.write(key + '=' + str(self.config[key]) + "\r\n")
        config_file.close()
        if log == True:
            self.log_output("Saved Configuration Settings")

    def validate_config(self, new = False):
        if self.choose_railworks_path() == False:
            message = self.lang["message_failedvalidationrailworks"]
            # reset all essential folders to prevent loop
            if "RAILWORKS_PATH" in self.config:
                del self.config["RAILWORKS_PATH"]
            if "DEVELOPER" in self.config:
                del self.config["DEVELOPER"]
            if "PRODUCT" in self.config:
                del self.config["PRODUCT"]
            # attempt to load route start settings
            self.save_config()
            self.error_handler(message, 
                               self.lang["message_failedvalidationrailworks_title"],wx.OK, wx.ICON_EXCLAMATION, True)
        # developer does not exist and failed to choose developer
        if self.choose_developer_folder() == False: # developer exists but is not in raiworks path and failed to specify folder correct
            message = self.lang["message_failedvalidationdeveloper"].replace("~~railworks~~",unicode.encode(unicode(self.config["RAILWORKS_PATH"]),"cp1252"))
            # reset all essential folders to prevent loop
            if "RAILWORKS_PATH" in self.config:
                del self.config["RAILWORKS_PATH"]
            if "DEVELOPER" in self.config:
                del self.config["DEVELOPER"]
            if "PRODUCT" in self.config:
                del self.config["PRODUCT"]
            self.save_config()
            self.error_handler(message,
                               self.lang["message_failedvalidationdeveloper_title"],wx.OK, wx.ICON_EXCLAMATION, True)
        if self.choose_product_folder() == False: # developer exists but is not in raiworks path and failed to specify folder correct:
            message = self.lang["message_failedvalidationproduct"].replace("~~railworks~~",unicode.encode(unicode(self.config["RAILWORKS_PATH"]),"cp1252")).replace("~~developer~~",unicode.encode(unicode(self.config["DEVELOPER"]),"cp1252"))
            # reset all essential folders to prevent loop
            if "RAILWORKS_PATH" in self.config:
                del self.config["RAILWORKS_PATH"]
            if "DEVELOPER" in self.config:
                del self.config["DEVELOPER"]
            if "PRODUCT" in self.config:
                del self.config["PRODUCT"]
            # attempt to load route start settings
            self.save_config()
            self.error_handler(message,
                               self.lang["message_failedvalidationproduct_title"],wx.OK, wx.ICON_EXCLAMATION, True)
        if "RW_ACE_PATH" not in self.config and self.choose_rw_ace() == False or \
           "RW_ACE_PATH" in self.config and self.choose_rw_ace() == False:
            self.error_handler(self.lang["message_failedvalidationrwacetool"],
                               self.lang["message_failedvalidationrwacetool_title"],wx.OK, wx.ICON_EXCLAMATION, True)
        if "DEBUG" not in self.config:
            self.config["DEBUG"] = "False"
        if "OVERWRITE_WARNING" not in self.config:
            self.config["OVERWRITE_WARNING"] = "True"
        if "SAVE_FORM" not in self.config:
            self.config["SAVE_FORM"] = "True"
        if "DELETE_TEMP_FILES" not in self.config:
            self.config["DELETE_TEMP_FILES"] = "True"
        if "REDUCED_CAPTURE" not in self.config:
            self.config["REDUCED_CAPTURE"] = "0.8"
        if "GE_STREAM_DELAY" not in self.config:
            self.config["GE_STREAM_DELAY"] = "0"
        if "DECAL_QUALITY" not in self.config:
            self.config["DECAL_QUALITY"] = "1024"
        if "GRAB_WARNINGS" not in self.config:
            self.config["GRAB_WARNINGS"] = "True"
        if "MAX_DECAL_SIZE" not in self.config:
            self.config["MAX_DECAL_SIZE"] = "400"
        if "RW_DECALS_PATH" not in self.config:
            self.config["RW_DECALS_PATH"] = "Environment\\Terrain\\Decals"
        if "RW_MARKERS_PATH" not in self.config:
            self.config["RW_MARKERS_PATH"] = "RouteMarkers\\Decals"
        if "FIRST_USE" not in self.config:
            self.config["FIRST_USE"] = "True"
        if "IMPROVEMENT_PROGRAM" not in self.config:
            result = self.error_handler(self.lang["message_improvementprogram"],
                                        self.lang["message_improvementprogram_title"],wx.YES_NO, wx.ICON_EXCLAMATION)
            if result == wx.ID_YES:
                self.config["IMPROVEMENT_PROGRAM"] = "True"
            else:
                self.config["IMPROVEMENT_PROGRAM"] = "False"
        if "GE_RENDER_DIMENSIONS" not in self.config:
            self.config["GE_RENDER_DIMENSIONS"] = ""
        if "DISABLE_ALL_GE_LAYERS" not in self.config:
            self.config["DISABLE_ALL_GE_LAYERS"] = "True"
        if "DISABLE_ALL_GE_PLACES" not in self.config:
            self.config["DISABLE_ALL_GE_PLACES"] = "True"
        if "ANTIALIAS_DECALS" not in self.config:
            self.config["ANTIALIAS_DECALS"] = "False"
        if "TILE_LIMIT" not in self.config:
            self.config["TILE_LIMIT"] = "150"
        if "LANGUAGE" not in self.config:
            self.config["LANGUAGE"] = "EN_GB"
        if "CREATE_GE_POLYGONS" not in self.config:
            self.config["CREATE_GE_POLYGONS"] = "True"
        if "LAST_UPDATE_CHECK" not in self.config:
            self.config["LAST_UPDATE_CHECK"] = time.time()
        if "UPDATE_CHECK_FREQUENCY" not in self.config:
            self.config["UPDATE_CHECK_FREQUENCY"] = 604800 # weekly
        if "CHUNK_OVERLAP" not in self.config:
            self.config["CHUNK_OVERLAP"] = "False"
        if "SHOW_SPLASH" not in self.config:
            self.config["SHOW_SPLASH"] = "True"
        if "CENTER_MARKERS" not in self.config:
            self.config["CENTER_MARKERS"] = "False"
        if "CENTER_4CORNERMARKERS" not in self.config:
            self.config["CENTER_4CORNERMARKERS"] = "True"
        if "MAX_ALTITUDE" not in self.config:
            self.config["MAX_ALTITUDE"] = "100000"
        if "MAX_BOX" not in self.config:
            self.config["MAX_BOX"] = "10000"
        if "BOX_SIZE" not in self.config:
            self.config["BOX_SIZE"] = "9"
        if "MAX_KML_DISTANCE" not in self.config:
            self.config["MAX_KML_DISTANCE"] = "5000"
            

        self.num_calibrations = len(self.altitude_option_generate())
            
        self.save_config(False,False)
        return True

    def check_path_exists(self, path):
        path = os.path.dirname(path)
        split_path = path.split("\\")
        path_check = ''
        for folder in split_path:
            path_check += folder + "\\"
            if folder != "." and os.path.exists(path_check) != True:
                try:
                    os.mkdir(path_check)
                except:
                    break
        # if path still does not exist exit
        if os.path.exists(path) != True:
            self.error_handler(self.lang["message_createfolderfail"].replace("~~path~~",path),
                               self.lang["message_createfolderfail_title"],wx.OK, wx.ICON_EXCLAMATION, True)
            sys.exit()
        return True

    def vinc_pt(self, phi1, lembda1, alpha12, s ):
        """

        Returns the lat and long of projected point and reverse azimuth
        given a reference point and a distance and azimuth to project.
        lats, longs and azimuths are passed in decimal degrees

        Returns ( phi2,  lambda2,  alpha21 ) as a tuple 

        """

        a = 6378137.0
        b = 6356752.3142
        f = (a-b)/a

        # convert lon lat to radians
        phi1 = math.radians(phi1)
        lembda1 = math.radians(lembda1)
        alpha12 = math.radians(alpha12)
        
        two_pi = 2.0*math.pi

        if ( alpha12 < 0.0 ) : 
                alpha12 = alpha12 + two_pi
        if ( alpha12 > two_pi ) : 
                alpha12 = alpha12 - two_pi

        
        b = a * (1.0 - f)

        TanU1 = (1-f) * math.tan(phi1)
        U1 = math.atan( TanU1 )
        sigma1 = math.atan2( TanU1, math.cos(alpha12) )
        Sinalpha = math.cos(U1) * math.sin(alpha12)
        cosalpha_sq = 1.0 - Sinalpha * Sinalpha
        
        u2 = cosalpha_sq * (a * a - b * b ) / (b * b)
        A = 1.0 + (u2 / 16384) * (4096 + u2 * (-768 + u2 * \
                (320 - 175 * u2) ) )
        B = (u2 / 1024) * (256 + u2 * (-128 + u2 * (74 - 47 * u2) ) )
        
        # Starting with the approximation
        sigma = (s / (b * A))

        last_sigma = 2.0 * sigma + 2.0  # something impossible
        
        # Iterate the following three equations 
        # until there is no significant change in sigma 

        # two_sigma_m , delta_sigma

        while ( abs( (last_sigma - sigma) / sigma) > 1.0e-9 ) :

           two_sigma_m = 2 * sigma1 + sigma
           
           delta_sigma = B * math.sin(sigma) * ( math.cos(two_sigma_m) \
                        + (B/4) * (math.cos(sigma) * \
                        (-1 + 2 * math.pow( math.cos(two_sigma_m), 2 ) -  \
                        (B/6) * math.cos(two_sigma_m) * \
                        (-3 + 4 * math.pow(math.sin(sigma), 2 )) *  \
                        (-3 + 4 * math.pow( math.cos (two_sigma_m), 2 ))))) \
           
           last_sigma = sigma
           sigma = (s / (b * A)) + delta_sigma
        
        
        phi2 = math.atan2 ( (math.sin(U1) * math.cos(sigma) + math.cos(U1) * math.sin(sigma) * math.cos(alpha12) ), \
                ((1-f) * math.sqrt( math.pow(Sinalpha, 2) +  \
                pow(math.sin(U1) * math.sin(sigma) - math.cos(U1) * math.cos(sigma) * math.cos(alpha12), 2))))
        

        lembda = math.atan2( (math.sin(sigma) * math.sin(alpha12 )), (math.cos(U1) * math.cos(sigma) -  \
                math.sin(U1) *  math.sin(sigma) * math.cos(alpha12)))
        
        C = (f/16) * cosalpha_sq * (4 + f * (4 - 3 * cosalpha_sq ))
        
        omega = lembda - (1-C) * f * Sinalpha *  \
                (sigma + C * math.sin(sigma) * (math.cos(two_sigma_m) + \
                C * math.cos(sigma) * (-1 + 2 * math.pow(math.cos(two_sigma_m),2) )))
        
        lembda2 = lembda1 + omega
        
        alpha21 = math.atan2 ( Sinalpha, (-math.sin(U1) * math.sin(sigma) +  \
                math.cos(U1) * math.cos(sigma) * math.cos(alpha12)))

        alpha21 = alpha21 + two_pi / 2.0
        if ( alpha21 < 0.0 ) :
                alpha21 = alpha21 + two_pi
        if ( alpha21 > two_pi ) :
                alpha21 = alpha21 - two_pi


        return math.degrees(phi2), math.degrees(lembda2), math.degrees(alpha21)


    def vinc_dist(self, phi1,  lembda1,  phi2,  lembda2 ) :
        """ 

        Returns the distance between two geographic points on the ellipsoid
        and the forward and reverse azimuths between these points.
        lats, longs and azimuths are in radians, distance in metres 

        Returns ( s, alpha12,  alpha21 ) as a tuple

        """
        # defaults for meters
        a = 6378137.0
        b = 6356752.3142
        f = (a-b)/a

        # convert lon lat to radians
        phi1 = math.radians(phi1)
        phi2 = math.radians(phi2)
        lembda1 = math.radians(lembda1)
        lembda2 = math.radians(lembda2)

        if (abs( phi2 - phi1 ) < 1e-8) and ( abs( lembda2 - lembda1) < 1e-8 ) :
          return 0.0
  
        two_pi = 2.0*math.pi

        b = a * (1.0 - f)

        TanU1 = (1-f) * math.tan( phi1 )
        TanU2 = (1-f) * math.tan( phi2 )
        
        U1 = math.atan(TanU1)
        U2 = math.atan(TanU2)

        lembda = lembda2 - lembda1
        last_lembda = -4000000.0                # an impossibe value
        omega = lembda

        # Iterate the following equations, 
        #  until there is no significant change in lembda 
        
        while ( last_lembda < -3000000.0 or lembda != 0 and abs( (last_lembda - lembda)/lembda) > 1.0e-9 ) :
        
          sqr_sin_sigma = pow( math.cos(U2) * math.sin(lembda), 2) + \
                pow( (math.cos(U1) * math.sin(U2) - \
                math.sin(U1) *  math.cos(U2) * math.cos(lembda) ), 2 )

          Sin_sigma = math.sqrt( sqr_sin_sigma )
          
          Cos_sigma = math.sin(U1) * math.sin(U2) + math.cos(U1) * math.cos(U2) * math.cos(lembda)
          
          sigma = math.atan2( Sin_sigma, Cos_sigma )

          Sin_alpha = math.cos(U1) * math.cos(U2) * math.sin(lembda) / math.sin(sigma)
          alpha = math.asin( Sin_alpha )
          
          Cos2sigma_m = math.cos(sigma) - (2 * math.sin(U1) * math.sin(U2) / pow(math.cos(alpha), 2) )
          
          C = (f/16) * pow(math.cos(alpha), 2) * (4 + f * (4 - 3 * pow(math.cos(alpha), 2)))
          
          last_lembda = lembda
          
          lembda = omega + (1-C) * f * math.sin(alpha) * (sigma + C * math.sin(sigma) * \
                (Cos2sigma_m + C * math.cos(sigma) * (-1 + 2 * pow(Cos2sigma_m, 2) )))
        

        u2 = pow(math.cos(alpha),2) * (a*a-b*b) / (b*b)
        
        A = 1 + (u2/16384) * (4096 + u2 * (-768 + u2 * (320 - 175 * u2)))
        
        B = (u2/1024) * (256 + u2 * (-128+ u2 * (74 - 47 * u2)))
        
        delta_sigma = B * Sin_sigma * (Cos2sigma_m + (B/4) * \
                (Cos_sigma * (-1 + 2 * pow(Cos2sigma_m, 2) ) - \
                (B/6) * Cos2sigma_m * (-3 + 4 * sqr_sin_sigma) * \
                (-3 + 4 * pow(Cos2sigma_m,2 ) )))
        
        s = b * A * (sigma - delta_sigma)
        
        alpha12 = math.atan2( (math.cos(U2) * math.sin(lembda)), \
                (math.cos(U1) * math.sin(U2) - math.sin(U1) * math.cos(U2) * math.cos(lembda)))
        
        alpha21 = math.atan2( (math.cos(U1) * math.sin(lembda)), \
                (-math.sin(U1) * math.cos(U2) + math.cos(U1) * math.sin(U2) * math.cos(lembda)))

        if ( alpha12 < 0.0 ) : 
                alpha12 =  alpha12 + two_pi
        if ( alpha12 > two_pi ) : 
                alpha12 = alpha12 - two_pi

        alpha21 = alpha21 + two_pi / 2.0
        if ( alpha21 < 0.0 ) : 
                alpha21 = alpha21 + two_pi
        if ( alpha21 > two_pi ) : 
                alpha21 = alpha21 - two_pi
        return float(s)


    def calc_seperation_in_meters(self, lat1, lon1, lat2, lon2):
        # Convert latitude and longitude to
        # spherical coordinates in radians.
        degrees_to_radians = math.pi/180.0

        # phi = 90 - latitude
        phi1 = (90.0 - lat1)*degrees_to_radians
        phi2 = (90.0 - lat2)*degrees_to_radians

        # theta = longitude
        theta1 = lon1*degrees_to_radians
        theta2 = lon2*degrees_to_radians

        # Compute spherical distance from spherical coordinates.
        
        # For two locations in spherical coordinates
        # (1, theta, phi) and (1, theta, phi)
        # cosine( arc length ) =
        #    sin phi sin phi' cos(theta-theta') + cos phi cos phi'
        # distance = rho * arc length

        cos = (math.sin(phi1)*math.sin(phi2)*math.cos(theta1 - theta2) +
               math.cos(phi1)*math.cos(phi2))
        try:
            arc = math.acos( cos ) * float(6378100) # radius of earth in meters
        except:
            return 0
            pass

        # Remember to multiply arc by the radius of the earth
        # in your favorite set of units to get length.

        return arc

    def check_file_overwrite(self,just_check = False):
        base_source_path = self.config["RAILWORKS_PATH"] + "\\Source\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"
        base_assets_path = self.config["RAILWORKS_PATH"] + "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\"
        # work out chunks if chunking
        files = list()
        if int(self.form_settings["CHUNK_CHOICE"]) != 1: # not full only so calc chunks
            x_chunks = int(math.ceil(self.capture_area_dimensions[0] / float(self.config["MAX_DECAL_SIZE"])))
            y_chunks = int(math.ceil(self.capture_area_dimensions[1] / float(self.config["MAX_DECAL_SIZE"])))
            for y_chunk in range(1, y_chunks + 1): # loop through number of y decals
                for x_chunk in range(1, x_chunks + 1): # loop through number of x decals
                    # temp chunk path
                    #if eval(self.config["DELETE_TEMP_FILES"]) != True:
                    #    temp_chunk_path = self.config["INSTALL_PATH"] + "\\temp\\chunks\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".png"
                    #    files.append(temp_chunk_path)

                    # ace files
                    ace_chunk_path = base_source_path + self.config["RW_DECALS_PATH"] + "\\aces\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".ace"
                    files.append(ace_chunk_path)

                    # decal blueprints
                    chunk_blueprint_path = base_source_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".xml"
                    files.append(chunk_blueprint_path)

                    if eval(self.form_settings["RAILWORKS_EXPORT"]) == True or just_check == True: # exporting so need to check assets
                        chunk_exported_ace = base_assets_path + self.config["RW_DECALS_PATH"] + "\\aces\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".TgPcDx"
                        files.append(chunk_exported_ace)

                        chunk_exported_bin = base_assets_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".bin"
                        files.append(chunk_exported_bin)

                        chunk_exported_xml = base_assets_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + " X" + str(x_chunk).zfill(len(str(x_chunks))) + ' Y' + str(y_chunk).zfill(len(str(y_chunks))) + ".xml"
                        files.append(chunk_exported_xml)
                        
        if int(self.form_settings["CHUNK_CHOICE"]) != 0: # involves full
            #if eval(self.config["DELETE_TEMP_FILES"]) != True:
            #    temp_chunk_path = self.config["INSTALL_PATH"] + "\\temp\\full\\" + str(self.form_settings["DECAL_NAME"]) + ".png"
            #    files.append(temp_chunk_path)

            # ace files
            ace_chunk_path = base_source_path + self.config["RW_DECALS_PATH"] + "\\aces\\" + str(self.form_settings["DECAL_NAME"])+ ".ace"
            files.append(ace_chunk_path)

            # decal blueprints
            chunk_blueprint_path = base_source_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".xml"
            files.append(chunk_blueprint_path)

            if eval(self.form_settings["RAILWORKS_EXPORT"]) == True or just_check == True: # exporting so need to check assets
                chunk_exported_ace = base_assets_path + self.config["RW_DECALS_PATH"] + "\\aces\\" + str(self.form_settings["DECAL_NAME"]) + ".TgPcDx"
                files.append(chunk_exported_ace)

                chunk_exported_bin = base_assets_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".bin"
                files.append(chunk_exported_bin)

                chunk_exported_xml = base_assets_path + self.config["RW_DECALS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".xml"
                files.append(chunk_exported_xml)


        if eval(self.form_settings["CREATE_MARKERS"]) == True: # create markers
            marker_blueprint_path = base_source_path + self.config["RW_MARKERS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".xml"
            files.append(marker_blueprint_path)

            marker_csv_path = base_source_path + self.config["RW_MARKERS_PATH"] + "\\csv\\" + str(self.form_settings["DECAL_NAME"]) + ".csv"
            files.append(marker_csv_path)

            if eval(self.form_settings["RAILWORKS_EXPORT"]) == True or just_check == True: # exporting so need to check assets
                marker_exported_bin = base_assets_path + self.config["RW_MARKERS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".bin"
                files.append(marker_exported_bin)

                marker_exported_xml = base_assets_path + self.config["RW_MARKERS_PATH"] + "\\" + str(self.form_settings["DECAL_NAME"]) + ".xml"
                files.append(marker_exported_xml)

                marker_exported_dcsv = base_assets_path + self.config["RW_MARKERS_PATH"] + "\\csv\\" + str(self.form_settings["DECAL_NAME"]) + ".dcsv"
                files.append(marker_exported_dcsv)

        # now check to see if any files exist
        message = ''
        i = 1
        for check in files:
            #print check
            if os.path.exists(check) == True:
                if i <= 30:
                    message += check.replace(self.config["RAILWORKS_PATH"],"") + "\n"
                i += 1

        if i > 30:
            message += self.lang["message_overwriteothers"].replace("~~number~~",str(i - 30));

        if len(message) != 0:
            if just_check:
                return False
            result = self.error_handler(self.lang["message_overwritewarning"].replace("~~number~~",str(i-1)).replace("~~file_list~~",message),
                                        self.lang["message_overwritewarning_title"],
                                        wx.YES_NO)
            if result != wx.ID_YES:
                return False
        return True

    def language_file(self):
        if os.path.exists(self.config["INSTALL_PATH"] + "\\lang\\" + self.config["LANGUAGE"] + ".lang") == True:
            f = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\" + self.config["LANGUAGE"] + ".lang", encoding="UTF-8", mode="r")
            first_line = f.readline().lstrip(unicode( codecs.BOM_UTF8, "utf8" ))
            f = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\" + self.config["LANGUAGE"] + ".lang", encoding="UTF-8", mode="r")
            try:
                #Read whole file as one string.
                data = f.read()
            finally:
                #Close file
                f.close()
            #Parse data string.
            self.lang = self.parse_config(data, True, True)

            # enable key file generation
            if LANG_KEYS == True:
                keys = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\lang_keys.txt",encoding="UTF-8", mode="w")
                for key in sorted(self.lang.iterkeys(),key=lambda x: x.lower()):
                    keys.write(key + "=\r\n")
                keys.close()

            # uncomment next 4 lines to enable ordered language file generation
            if LANG_ORDERED == True:
                self.check_path_exists(self.config["INSTALL_PATH"] + "\\lang\\ordered\\")
                ordered = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\ordered\\" + self.config["LANGUAGE"] + ".lang", encoding="UTF-8", mode="w")
                if first_line[0] == "#": # language code
                    ordered.write(first_line)
                for key in sorted(self.lang.iterkeys(),key=lambda x: x.lower()):
                    ordered.write(key + " = " + self.lang[key].replace("\t","\\t").replace("\n","\\n") + "\r\n")
                ordered.close()
            # load list of language keys
            f = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\lang_keys.txt", encoding="UTF-8", mode="r")
            try:
                #Read whole file as one string.
                data = f.read()
            finally:
                #Close file
                f.close()
            #Parse data string.
            lang_keys = self.parse_config(data, True, True)
            #print lang_keys


            # check that language file is valid
            invalid = False
            lang_log = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\lang_log.txt", encoding="UTF-8", mode="w")
            for key in sorted(self.lang.iterkeys(),key=lambda x: x.lower()):
                if key not in lang_keys:
                    lang_log.write("Extra: " + key + "\r\n")
                    invalid = True
            for key in sorted(lang_keys.iterkeys(),key=lambda x: x.lower()):
                if key not in self.lang:
                    lang_log.write("Missing: " + key + "\r\n")
                    invalid = True
            lang_log.close()
            if invalid:
                self.log_output("Loaded .\\lang\\" + self.config["LANGUAGE"] + ".lang file")
            else:
                return True
        

        # return error and exit if got this far
        if "message_badlangfile" in self.lang and "message_badlangfile_title" in self.lang:
            self.error_handler(self.lang["message_badlangfile"].replace("~~file~~",self.config["LANGUAGE"]).replace(".txt",".lang") ,
                               self.lang["message_badlangfile_title"],
                               wx.OK,
                               wx.ICON_EXCLAMATION)
            self.config["LANGUAGE"] = ""
            self.save_config()
            sys.exit()
            
        else:
            self.error_handler("The language file (.\\lang\\" + self.config["LANGUAGE"] + ".lang) appears to be corrupt or missing.\n\n"\
                               "Please reinstall RWDecal",
                               "Corrupt Language File",
                               wx.OK,
                               wx.ICON_EXCLAMATION)
            self.config["LANGUAGE"] = ""
            self.save_config()
            sys.exit()

    def lock_form(self,do):
        if do == "lock":
            # disable all menu items
            for item in self.file.GetMenuItems():
                item.Enable(False)
            for item in self.prefs.GetMenuItems():
                item.Enable(False)
            for item in self.help.GetMenuItems():
                item.Enable(False)
            

            self.decal_name_text.Enable(False) # Disable decal name

            self.previous_runs_combo.Enable(False) # Disable previous runs load
            self.previous_delete_button.Enable(False) # Disable previous runs clear

            self.marker_pair_delete.Enable(False) # Disable pair delete button
            self.bulk_create.Enable(False) # Disable bulk_create button
            self.marker_pairs_combo.Enable(False) # Disable pair combo

            self.latLL_text.Enable(False) # Disable lat LL
            self.latUR_text.Enable(False) # Disable lat UR
            self.lonLL_text.Enable(False) # Disable lon LL
            self.lonUR_text.Enable(False) # Disable lon UR
            self.grab_ll.Enable(False) # Disable grab ll button
            self.grab_current.Enable(False) # Disable grab current button
            self.grab_ur.Enable(False) # Disable grab ur button

            self.altitude_choice.Enable(False) # Disable altitude combo
            self.chunk_choice.Enable(False) # Disable decal method combo
            self.camera_speed_choice.Enable(False) # Disable camera combo
            
            self.due_north_fix.Enable(False) # Disable due north fix
            self.due_north_fix_degrees.Enable(False) # Disable due north fix degrees
            self.due_north_fix_help.Enable(False) # Disable due north fix degrees
            self.due_north_fix_auto.Enable(False) # Disable due north fix degrees
            self.due_north_fix_chunk_auto.Enable(False) # Disable chunk lock option

            self.create_markers.Enable(False) # Disable create markers
            self.create_markers_choice_full.Enable(False) # Disable markers full combo
            self.create_markers_choice_chunks.Enable(False) # Disable markers chunks combo

            self.railworks_export.Enable(False) # Enable export

            self.delete_blueprints.Enable(False) # Enable delete blurprints

            self.run_button.Enable(False) # Disable run button
            self.blueprint_editor_button.Enable(False) # Disable blueprint editor button
            
            self.main_cancel_button.Enable(True) # Enable cancel button MUST BE LAST ITEM
        elif do == "unlock":
            # disable all menu items
            for item in self.file.GetMenuItems():
                item.Enable(True)
            for item in self.prefs.GetMenuItems():
                item.Enable(True)
            for item in self.help.GetMenuItems():
                item.Enable(True)

            self.decal_name_text.Enable(True) # Enable decal name

            if len(self.previous_runs) > 0:
                self.previous_runs_combo.Enable(True) # Enable previous runs load
                self.previous_delete_button.Enable(True) # Enable previous runs clear
            else:
                self.prefs.Enable(217,False)

            if len(self.marker_pairs) > 0:
                self.marker_pair_delete.Enable(True) # Enable pair delete button
                self.bulk_create.Enable(True) # Enable bulk_create button
                self.marker_pairs_combo.Enable(True) # Enable pair combo
            else:
                self.prefs.Enable(210,False)

            self.latLL_text.Enable(True) # Enable lat LL
            self.latUR_text.Enable(True) # Enable lat UR
            self.lonLL_text.Enable(True) # Enable lon LL
            self.lonUR_text.Enable(True) # Enable lon UR
            self.grab_ll.Enable(True) # Enable grab ll button
            self.grab_current.Enable(True) # Disable grab current button
            self.grab_ur.Enable(True) # Enable grab ur button

            self.altitude_choice.Enable(True) # Enable altitude combo
            self.chunk_choice.Enable(True) # Enable decal method combo
            self.camera_speed_choice.Enable(True) # Enable camera combo
            
            self.due_north_fix.Enable(True) # Enable due north fix
            self.due_north_fix_help.Enable(True) # Enable due north fix degrees
            if eval(self.form_settings["DUE_NORTH_FIX"]):
                if eval(self.form_settings["AUTO_ROTATE"]) == False:
                    self.due_north_fix_degrees.Enable(True) # Enable due north fix degrees
                else:
                    self.due_north_fix_chunk_auto.Enable(True) # Enable chunk lock option
                self.due_north_fix_auto.Enable(True) # Enable due north fix degrees

            self.create_markers.Enable(True) # Enable create markers
            if eval(self.form_settings["CREATE_MARKERS"]):
                self.create_markers_choice_full.Enable(True) # Enable markers full combo
                self.create_markers_choice_chunks.Enable(True) # Enable markers chunks combo

            self.railworks_export.Enable(True) # Enable export

            if eval(self.form_settings["RAILWORKS_EXPORT"]):
                self.delete_blueprints.Enable(True) # Enable delete blurprints

            self.run_button.Enable(True) # Enable run button
            self.blueprint_editor_button.Enable(True) # enable blueprint editor button
            
            self.main_cancel_button.Enable(False) # Disable cancel button MUST BE LAST ITEM

    def fix_shortcut(self,shortcut,icon):
        if os.path.exists(shortcut) and os.path.exists(icon):
            shell = win32com.client.Dispatch("WScript.Shell") 
            shortcut_object = shell.CreateShortCut(shortcut)
            if shortcut_object.IconLocation != icon:
                shortcut_object.IconLocation = icon
                shortcut_object.save()
                self.log_output('Changed "' + shortcut + '" to use "' + icon + '" icon')


    def evt_hide_decals(self,event):
        self.task = "hide"
        self.hide_check_boxes = list()
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        self.hide_decals_gui = wx.Dialog(self, title=self.lang["hide_decals_window_title"], size=(800,625), style=wx.CAPTION|wx.RESIZE_BORDER)

        self.bulk_select_panel = wx.lib.scrolledpanel.ScrolledPanel(self.hide_decals_gui, -1, size=(590,225))
        self.bulk_select_panel.SetupScrolling(scroll_x=False, scroll_y=True)

        self.gauge_panel = wx.Panel(self.hide_decals_gui, -1, size=(800,625),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
        self.gauge = wx.Gauge(self.gauge_panel, -1, 1, pos=(202,300), size=((590),25))
        self.gauge_panel.Show(False)

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(self.hide_decals_gui, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(self.hide_decals_gui, -1, logo2, (10 + logo2.GetWidth(), 5))
        logo3 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo3 = wx.StaticBitmap(self.hide_decals_gui, -1, logo3, (10 + logo3.GetWidth(), 5))


        self.title = wx.StaticText(self.hide_decals_gui, -1, self.lang["hide_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)
        
        description = wx.StaticText(self.hide_decals_gui, -1, self.lang["hide_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        warning = wx.StaticText(self.hide_decals_gui, -1, self.lang["hide_decals_warning"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        warning.SetFont(font)
        warning.Wrap(580)

        # choices
        route_choices = self.get_routes_list()
        route_choices.insert(0,  self.lang["routestart_chooseroute"])
        self.route_choices_combo = wx.ComboBox(self.hide_decals_gui, -1, choices=route_choices, style=wx.CB_READONLY)
        self.route_choices_combo.Bind(wx.EVT_COMBOBOX, self.evt_get_used_decals, self.route_choices_combo)
        self.route_choices_combo.SetToolTip(wx.ToolTip(self.lang["hide_chooseroute_tooltip"]))
        self.route_choices_combo.SetSelection(0)

        # check boxes
        self.check_control = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer.AddGrowableCol(0)
        self.check_boxes_sizer.AddGrowableCol(1)
        self.check_boxes_sizer.AddGrowableCol(2)
        
        self.bulk_select_panel.SetSizer(self.check_boxes_sizer)

        # set it all out
        buttons = self.hide_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 5)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)
        logos.Add(logo3, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1)
        self.content.Add(warning, -1, wx.ALIGN_CENTER)
        self.content.Add(self.route_choices_combo, -1, wx.ALIGN_CENTER)
        self.content.Add(self.check_control, -1, wx.ALIGN_CENTER)
        self.content.Add(self.bulk_select_panel, -1, wx.ALIGN_CENTER)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, self.content])
        
        self.hide_decals_gui.SetSizer(confirm_sizer)
        self.hide_decals_gui.Fit()

        result = self.hide_decals_gui.ShowModal()
        self.hide_decals_gui.Destroy()

        if result == wx.ID_OK:
            decals_to_hide = {}
            for item in self.hide_check_boxes:
                if item.GetValue() == True:
                    decals_to_hide["GE: " + item.GetLabel()] = self.used_decals["GE: " + item.GetLabel()]

            if len(decals_to_hide) > 0:
                result = self.error_handler(self.lang["message_hide_decals"].replace("~~number~~",str(len(decals_to_hide))),
                                            self.lang["message_hide_decals_title"],
                                            wx.YES_NO,
                                            wx.ICON_EXCLAMATION)
                if result == wx.ID_YES:
                    hide_decals(self, wX, wY, decals_to_hide).start()

        return

    def evt_unhide_decals(self,event):
        self.task = "unhide"
        self.hide_check_boxes = list()
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        self.hide_decals_gui = wx.Dialog(self, title=self.lang["unhide_decals_window_title"], size=(800,625), style=wx.CAPTION|wx.RESIZE_BORDER)

        self.bulk_select_panel = wx.lib.scrolledpanel.ScrolledPanel(self.hide_decals_gui, -1, size=(590,225))
        self.bulk_select_panel.SetupScrolling(scroll_x=False, scroll_y=True)

        self.gauge_panel = wx.Panel(self.hide_decals_gui, -1, size=(800,625),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
        self.gauge = wx.Gauge(self.gauge_panel, -1, 1, pos=(202,300), size=((590),25))
        self.gauge_panel.Show(False)

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(self.hide_decals_gui, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(self.hide_decals_gui, -1, logo2, (10 + logo2.GetWidth(), 5))
        logo3 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo3 = wx.StaticBitmap(self.hide_decals_gui, -1, logo3, (10 + logo3.GetWidth(), 5))


        self.title = wx.StaticText(self.hide_decals_gui, -1, self.lang["unhide_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)
        
        description = wx.StaticText(self.hide_decals_gui, -1, self.lang["unhide_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        warning = wx.StaticText(self.hide_decals_gui, -1, self.lang["unhide_decals_warning"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        warning.SetFont(font)
        warning.Wrap(580)

        # choices
        route_choices = self.get_routes_list()
        route_choices.insert(0,  self.lang["routestart_chooseroute"])
        self.route_choices_combo = wx.ComboBox(self.hide_decals_gui, -1, choices=route_choices, style=wx.CB_READONLY)
        self.route_choices_combo.Bind(wx.EVT_COMBOBOX, self.evt_get_used_decals, self.route_choices_combo)
        self.route_choices_combo.SetToolTip(wx.ToolTip(self.lang["unhide_chooseroute_tooltip"]))
        self.route_choices_combo.SetSelection(0)

        # check boxes
        self.check_control = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer.AddGrowableCol(0)
        self.check_boxes_sizer.AddGrowableCol(1)
        self.check_boxes_sizer.AddGrowableCol(2)
        
        self.bulk_select_panel.SetSizer(self.check_boxes_sizer)

        # set it all out
        buttons = self.hide_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 5)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)
        logos.Add(logo3, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1)
        self.content.Add(warning, -1, wx.ALIGN_CENTER)
        self.content.Add(self.route_choices_combo, -1, wx.ALIGN_CENTER)
        self.content.Add(self.check_control, -1, wx.ALIGN_CENTER)
        self.content.Add(self.bulk_select_panel, -1, wx.ALIGN_CENTER)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, self.content])
        
        self.hide_decals_gui.SetSizer(confirm_sizer)
        self.hide_decals_gui.Fit()

        result = self.hide_decals_gui.ShowModal()
        self.hide_decals_gui.Destroy()

        if result == wx.ID_OK:
            decals_to_unhide = {}
            for item in self.hide_check_boxes:
                if item.GetValue() == True:
                    decals_to_unhide["GE: " + item.GetLabel()] = self.used_decals["GE: " + item.GetLabel()]

            if len(decals_to_unhide) > 0:
                result = self.error_handler(self.lang["message_unhide_decals"].replace("~~number~~",str(len(decals_to_unhide))),
                                            self.lang["message_unhide_decals_title"],
                                            wx.YES_NO,
                                            wx.ICON_EXCLAMATION)
                if result == wx.ID_YES:
                    unhide_decals(self, wX, wY, decals_to_unhide).start()

        return

    def evt_rename_decals(self,event):
        self.route_check_boxes = list()
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        self.rename_decals_gui = wx.Dialog(self, title=self.lang["rename_decals_window_title"], size=(800,625), style=wx.CAPTION|wx.RESIZE_BORDER)

        self.bulk_select_panel = wx.lib.scrolledpanel.ScrolledPanel(self.rename_decals_gui, -1, size=(590,100))
        self.bulk_select_panel.SetupScrolling(scroll_x=False, scroll_y=True)

        

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(self.rename_decals_gui, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(self.rename_decals_gui, -1, logo2, (10 + logo2.GetWidth(), 5))
        logo3 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo3 = wx.StaticBitmap(self.rename_decals_gui, -1, logo3, (10 + logo3.GetWidth(), 5))


        self.title = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)
        
        description = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        warning = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_warning"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        warning.SetFont(font)
        warning.Wrap(580)

        # choices
        stage_1 = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_stage_1"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_1.SetFont(font)

        #self.gauge_panel = wx.Panel(self.rename_decals_gui, -1, size=(800,625),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
        self.gauge = wx.Gauge(self.rename_decals_gui, -1, 1, size=(550,20))
        self.decal_list_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=4)
        self.decal_list_sizer.Add(self.gauge, -1, wx.EXPAND)
        #decal_choices = list_decals(self.config["RAILWORKS_PATH"] + "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\" + self.config["RW_DECALS_PATH"],True)
        #decal_choices.insert(0,  self.lang["rename_decals_choose_decal"])
        #self.decal_choices_combo = wx.ComboBox(self.rename_decals_gui, -1, choices=decal_choices, style=wx.CB_READONLY)
        #self.decal_choices_combo.SetToolTip(wx.ToolTip(self.lang["rename_decals_choose_decal_tooltip"]))
        #self.decal_choices_combo.SetSelection(0)

        # Specify new decal name
        stage_2 = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_stage_2"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_2.SetFont(font)
        new_decal_name_label = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_new_name"], style=wx.ALIGN_RIGHT)
        
        self.new_decal_name_text = wx.TextCtrl(self.rename_decals_gui, -1, "")
        self.Bind(wx.EVT_TEXT, self.evt_validate_form,self.new_decal_name_text)
        self.new_decal_name_text.SetToolTip(wx.ToolTip(self.lang["tooltip_decalname"]))

        new_decal_info = GenBitmapTextButton(self.rename_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        new_decal_info.Bind(wx.EVT_BUTTON, lambda evt, temp="decal_info": self.evt_info_button(evt, temp))

        decal_name_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=4)
        decal_name_sizer.AddMany([new_decal_name_label, self.new_decal_name_text, new_decal_info])

        stage_3 = wx.StaticText(self.rename_decals_gui, -1, self.lang["rename_decals_stage_3"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_3.SetFont(font)

        # check boxes     
        self.check_boxes_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer.AddGrowableCol(0)
        self.check_boxes_sizer.AddGrowableCol(1)
        self.check_boxes_sizer.AddGrowableCol(2)
        route_choices = self.get_routes_list()
        route_checkboxes = list()
        for route in route_choices:
            route_checkboxes.append(wx.CheckBox(self.bulk_select_panel, -1, route, wx.DefaultPosition))
                                    
        for item in route_checkboxes:
            self.check_boxes_sizer.Add(item, -1, wx.EXPAND)
        
        self.bulk_select_panel.SetSizer(self.check_boxes_sizer)

        # check control
        self.check_control = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        check_all = GenBitmapTextButton(self.rename_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\check_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        uncheck_all = GenBitmapTextButton(self.rename_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\uncheck_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        invert = GenBitmapTextButton(self.rename_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\invert.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        # tooltips for check buttons
        check_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_checkall_tooltip"]))
        uncheck_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_uncheckall_tooltip"]))
        invert.SetToolTip(wx.ToolTip(self.lang["bulkselect_invert_tooltip"]))
        # check button actions
        check_all.Bind(wx.EVT_BUTTON, lambda evt, action="check", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), check_all)
        uncheck_all.Bind(wx.EVT_BUTTON, lambda evt, action="uncheck", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), uncheck_all)
        invert.Bind(wx.EVT_BUTTON, lambda evt, action="invert", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), invert)
        #layout check buttons
        self.check_control.Add(check_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(uncheck_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(invert, -1, wx.LEFT|wx.RIGHT, 10)

        # set it all out
        buttons = self.rename_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 5)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)
        logos.Add(logo3, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1)
        self.content.Add(warning, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_1, -1, wx.ALIGN_CENTER)
        self.content.Add(self.decal_list_sizer, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_2, -1, wx.ALIGN_CENTER)
        self.content.Add(decal_name_sizer, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_3, -1, wx.ALIGN_CENTER)
        self.content.Add(self.check_control, -1, wx.ALIGN_CENTER)
        self.content.Add(self.bulk_select_panel, -1, wx.ALIGN_CENTER)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)

        self.confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        self.confirm_sizer.AddMany([logos, self.content])
        
        self.rename_decals_gui.SetSizer(self.confirm_sizer)
        self.rename_decals_gui.Fit()
        list_decals(self, "update_decal_list", self.config["RAILWORKS_PATH"] + "\\Assets\\" + self.config["DEVELOPER"] + "\\" + self.config["PRODUCT"] + "\\" + self.config["RW_DECALS_PATH"],True).start()

        result = self.rename_decals_gui.ShowModal()
        self.rename_decals_gui.Destroy()

        routes_to_search = {}
        if result == wx.ID_OK:
            if self.decal_choices_combo.GetCurrentSelection() == 0: # ignore first item
                self.error_handler(self.lang["rename_decals_decal_choice_error"], self.lang["rename_decals_decal_choice_error_title"])
            else:
                if self.evt_validate_decal_name(re.sub("[ ]+"," ",self.new_decal_name_text.GetValue().strip())):
                    new_decal_name = re.sub("[ ]+"," ",self.new_decal_name_text.GetValue().strip())
                    # make sure new decal name not already used
                    error = False
                    for decal in self.decal_list:
                        if decal.lower() == new_decal_name.lower():
                            self.error_handler(self.lang["rename_decals_new_exists_error"], self.lang["rename_decals_new_exists_error_title"])
                            error = True
                            break
                    if error == False:
                        decal_to_rename = self.decal_choices_combo.GetLabel()
                        for item in route_checkboxes:
                            if item.GetValue() == True:
                                routes_to_search[item.GetLabel()] = self.route_details[item.GetLabel()][2]

                        rename_decal(self, decal_to_rename, new_decal_name, routes_to_search).start()

        return
 
    def update_hide_checks(self,used_decals):
        self.used_decals = used_decals
        self.check_boxes_sizer.Clear(True)
        self.check_control.Clear(True)
        self.hide_check_boxes = list()
        for key in sorted(used_decals.iterkeys(),key=lambda x: x.lower()):
            self.hide_check_boxes.append(wx.CheckBox(self.bulk_select_panel, -1, re.sub("^GE: ","",key), wx.DefaultPosition))

        for item in self.hide_check_boxes:
            if self.task == "unhide":
                if used_decals["GE: " + item.GetLabel()][3] != False:
                    item.Enable(False)
                    item.SetLabel(item.GetLabel() + " (visible)")
            else:
                if used_decals["GE: " + item.GetLabel()][3] == False:
                    item.Enable(False)
                    item.SetLabel(item.GetLabel() + " (hidden)")
            self.check_boxes_sizer.Add(item, -1, wx.EXPAND)

        # check control
        check_all = GenBitmapTextButton(self.hide_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\check_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        uncheck_all = GenBitmapTextButton(self.hide_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\uncheck_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        invert = GenBitmapTextButton(self.hide_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\invert.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        # tooltips for check buttons
        check_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_checkall_tooltip"]))
        uncheck_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_uncheckall_tooltip"]))
        invert.SetToolTip(wx.ToolTip(self.lang["bulkselect_invert_tooltip"]))
        # check button actions
        check_all.Bind(wx.EVT_BUTTON, lambda evt, action="check", boxes=self.hide_check_boxes: self.evt_bulk_check_handler(evt, action, boxes), check_all)
        uncheck_all.Bind(wx.EVT_BUTTON, lambda evt, action="uncheck", boxes=self.hide_check_boxes: self.evt_bulk_check_handler(evt, action, boxes), uncheck_all)
        invert.Bind(wx.EVT_BUTTON, lambda evt, action="invert", boxes=self.hide_check_boxes: self.evt_bulk_check_handler(evt, action, boxes), invert)
        #layout check buttons
        self.check_control.Add(check_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(uncheck_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(invert, -1, wx.LEFT|wx.RIGHT, 10)

        self.hide_decals_gui.Layout()
        self.check_boxes_sizer.Layout()
        self.bulk_select_panel.SetupScrolling()
        return

    def update_decal_list(self,decal_list):
        self.decal_list = decal_list
        self.decal_list_sizer.Clear(True)
        decal_list.insert(0,  self.lang["rename_decals_choose_decal"])
        self.decal_choices_combo = wx.ComboBox(self.rename_decals_gui, -1, choices=decal_list, style=wx.CB_READONLY)
        self.decal_choices_combo.SetToolTip(wx.ToolTip(self.lang["rename_decals_choose_decal_tooltip"]))
        self.decal_choices_combo.SetSelection(0)

        self.decal_list_sizer.Add(self.decal_choices_combo, -1, wx.EXPAND)

        self.decal_list_sizer.Layout()
        self.rename_decals_gui.Layout()
        return

    def update_product_list(self,product_list):
        self.product_list = product_list
        product_list_a = list()
        product_list_b = list()
        self.product_choices_A_sizer.Clear(True)
        self.product_choices_B_sizer.Clear(True)

        # sort results
        for key in sorted(self.product_list.iterkeys(),key=lambda x: x.lower()):
            if product_list[key] > 0:
                product_list_a.append(key + " (" + str(product_list[key]) + " decals)")
            product_list_b.append(key)
        
        product_list_a.insert(0,  self.lang["transfer_decals_choose"])
        product_list_b.insert(0,  self.lang["transfer_decals_choose"])

        self.product_choices_A_combo = wx.ComboBox(self.transfer_decals_gui, -1, choices=product_list_a, style=wx.CB_READONLY)
        self.product_choices_A_combo.SetToolTip(wx.ToolTip(self.lang["transfer_decals_choose_tooltip_a"]))
        self.product_choices_A_combo.SetSelection(0)
        self.product_choices_A_sizer.Add(self.product_choices_A_combo, -1, wx.EXPAND)

        self.product_choices_B_combo = wx.ComboBox(self.transfer_decals_gui, -1, choices=product_list_b, style=wx.CB_READONLY)
        self.product_choices_B_combo.SetToolTip(wx.ToolTip(self.lang["transfer_decals_choose_tooltip_b"]))
        self.product_choices_B_combo.SetSelection(0)

        self.product_choices_B_sizer.Add(self.product_choices_B_combo, -1, wx.EXPAND)

        self.product_choices_A_sizer.Layout()
        self.product_choices_B_sizer.Layout()

        buttons = self.transfer_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)
        self.transfer_decals_gui.Layout()
        return

    def evt_get_used_decals(self,event):
        get_used_decals(self, wX, wY).start()
        return

    def decals_to_csv(self, route_name, sets_only, decals):
        if len(decals) == 0:
            self.error_handler(self.lang["list_decals_empty"], self.lang["list_decals_empty_title"])
            return
        if sets_only == True:
            file_name = route_name + " Sets Only.csv"
        else:
            file_name = route_name + ".csv"

        objShell = win32com.client.Dispatch("WScript.Shell")
        self.check_path_exists(objShell.SpecialFolders("AllUsersDesktop") + "\\RailWorks Used Decals\\")
        csv = codecs.open(objShell.SpecialFolders("AllUsersDesktop") + "\\RailWorks Used Decals\\" + file_name, encoding="UTF-8", mode="w")
        if sets_only:
            csv.write("Decal Set,Number of Used Decals in Set\r\n")
        else:
            csv.write("Decal Name,Developer,Product,Path,Hidden/Visible,Tile Reference\r\n")
        for decal in sorted(decals.iterkeys(),key=lambda x: x.lower()):
            if sets_only:
               csv.write(str(decal) + "," + str(decals[decal]) + "\r\n")
            else:
                if decals[decal][3] == True:
                    visability = "Visible"
                else:
                    visability = "Hidden"
                csv.write(str(decal) + "," + str(decals[decal][0]) + "," + str(decals[decal][1]) + "," + str(decals[decal][2]) + "," + visability + "," + str(decals[decal][6]) + "\r\n")
        csv.close()

        self.error_handler(self.lang["list_decals_saved"].replace("~~path~~","\\RailWorks Used Decals\\" + file_name), self.lang["list_decals_saved_title"])


    def evt_list_used_decals(self,event):
        self.list_decals_gui = wx.Dialog(self, title=self.lang["list_decals_window_title"], size=(800,300), style=wx.CAPTION|wx.RESIZE_BORDER)

        self.gauge_panel = wx.Panel(self.list_decals_gui, -1, size=(800,300),style=wx.NO_BORDER|wx.TAB_TRAVERSAL)
        self.gauge = wx.Gauge(self.gauge_panel, -1, 1, pos=(202,150), size=((580),25))
        self.gauge_panel.Show(False)

        logo = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo = wx.StaticBitmap(self.list_decals_gui, -1, logo, (10 + logo.GetWidth(), 5))

        self.title = wx.StaticText(self.list_decals_gui, -1, self.lang["list_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)
        
        description = wx.StaticText(self.list_decals_gui, -1, self.lang["list_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        # route choices
        route_choices = self.get_routes_list()
        route_choices.insert(0,  self.lang["routestart_chooseroute"])
        self.route_choices_combo = wx.ComboBox(self.list_decals_gui, -1, choices=route_choices, style=wx.CB_READONLY)
        self.route_choices_combo.SetToolTip(wx.ToolTip(self.lang["list_decals_chooseroute_tooltip"]))
        self.route_choices_combo.SetSelection(0)

        # decal sets only
        self.decal_sets = wx.CheckBox(self.list_decals_gui, -1, self.lang["list_decals_decal_sets"], wx.DefaultPosition)

        # set it all out
        buttons = self.list_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo, -1, wx.ALL, 5)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1)
        self.content.Add(self.route_choices_combo, -1, wx.ALIGN_CENTER)
        self.content.Add(self.decal_sets, -1, wx.ALIGN_CENTER)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, self.content])
        
        self.list_decals_gui.SetSizer(confirm_sizer)
        self.list_decals_gui.Fit()

        result = self.list_decals_gui.ShowModal()
        self.list_decals_gui.Destroy()

        if result == wx.ID_OK and self.route_choices_combo.GetCurrentSelection() != 0:
            route_name = self.route_choices_combo.GetLabel()
            status = self.lang["transfer_decals_generate_cache"].replace("~~route~~",route_name).replace("~~number~~", "1").replace("~~number_max~~","1")
            route_folder = self.route_details[self.route_choices_combo.GetLabel()][2]
            route_path = self.config["RAILWORKS_PATH"] + "\\Content\\Routes\\" + route_folder  + "\\"
            sets_only = self.decal_sets.IsChecked()
            list_used_decals(self, route_name, route_folder, route_path, sets_only).start()
        return

    def evt_transfer_decals(self,event):
        self.route_check_boxes = list()
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        self.transfer_decals_gui = wx.Dialog(self, title=self.lang["transfer_decals_window_title"], size=(800,-1), style=wx.CAPTION|wx.RESIZE_BORDER)

        self.bulk_select_panel = wx.lib.scrolledpanel.ScrolledPanel(self.transfer_decals_gui, -1, size=(590,100))
        self.bulk_select_panel.SetupScrolling(scroll_x=False, scroll_y=True)

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(self.transfer_decals_gui, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(self.transfer_decals_gui, -1, logo2, (10 + logo2.GetWidth(), 5))
        logo3 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo3 = wx.StaticBitmap(self.transfer_decals_gui, -1, logo3, (10 + logo3.GetWidth(), 5))


        self.title = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)
        
        description = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        warning = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_warning"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        warning.SetFont(font)
        warning.Wrap(580)

        # Specify copy or transfer
        stage_1 = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_stage_1"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_1.SetFont(font)
        copy_or_transfer_list = list()
        copy_or_transfer_list.append(self.lang["transfer_decals_transfer_word"])
        copy_or_transfer_list.append(self.lang["transfer_decals_copy_word"])
        copy_or_transfer = wx.ComboBox(self.transfer_decals_gui, -1, choices=copy_or_transfer_list, style=wx.CB_READONLY)
        copy_or_transfer.SetToolTip(wx.ToolTip(self.lang["transfer_decals_choose_method"]))
        copy_or_transfer.SetSelection(0)

        # Specify "A" Developer / Product
        stage_2 = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_stage_2"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_2.SetFont(font)

        self.gauge = wx.Gauge(self.transfer_decals_gui, -1, 1, size=(550,20))
        self.product_choices_A_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.product_choices_A_sizer.Add(self.gauge, -1, wx.EXPAND)

        # Specify "B" Developer / Product
        stage_3 = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_stage_3"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_3.SetFont(font)

        stage_3_loading = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_stage_3_loading"], style=wx.ALIGN_CENTER)
        self.product_choices_B_sizer = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.product_choices_B_sizer.Add(stage_3_loading, -1, wx.EXPAND)
        

        # select the routes to scan
        stage_4 = wx.StaticText(self.transfer_decals_gui, -1, self.lang["transfer_decals_stage_4"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_4.SetFont(font)

        # check boxes     
        self.check_boxes_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        self.check_boxes_sizer.AddGrowableCol(0)
        self.check_boxes_sizer.AddGrowableCol(1)
        self.check_boxes_sizer.AddGrowableCol(2)
        route_choices = self.get_routes_list()
        route_checkboxes = list()
        for route in route_choices:
            route_checkboxes.append(wx.CheckBox(self.bulk_select_panel, -1, route, wx.DefaultPosition))
                                    
        for item in route_checkboxes:
            self.check_boxes_sizer.Add(item, -1, wx.EXPAND)
        
        self.bulk_select_panel.SetSizer(self.check_boxes_sizer)

        # check control
        self.check_control = wx.FlexGridSizer(cols=3, hgap=4, vgap=2*4)
        check_all = GenBitmapTextButton(self.transfer_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\check_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        uncheck_all = GenBitmapTextButton(self.transfer_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\uncheck_all.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        invert = GenBitmapTextButton(self.transfer_decals_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\\invert.gif"),size=(16,16),style=wx.ALIGN_CENTER)
        # tooltips for check buttons
        check_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_checkall_tooltip"]))
        uncheck_all.SetToolTip(wx.ToolTip(self.lang["bulkselect_uncheckall_tooltip"]))
        invert.SetToolTip(wx.ToolTip(self.lang["bulkselect_invert_tooltip"]))
        # check button actions
        check_all.Bind(wx.EVT_BUTTON, lambda evt, action="check", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), check_all)
        uncheck_all.Bind(wx.EVT_BUTTON, lambda evt, action="uncheck", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), uncheck_all)
        invert.Bind(wx.EVT_BUTTON, lambda evt, action="invert", boxes=route_checkboxes: self.evt_bulk_check_handler(evt, action, boxes), invert)
        #layout check buttons
        self.check_control.Add(check_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(uncheck_all, -1, wx.LEFT|wx.RIGHT, 10)
        self.check_control.Add(invert, -1, wx.LEFT|wx.RIGHT, 10)

        # set it all out
        #buttons = self.transfer_decals_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 10)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 10)
        logos.Add(logo3, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 10)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1)
        self.content.Add(warning, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_1, -1, wx.ALIGN_CENTER)
        self.content.Add(copy_or_transfer, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_2, -1, wx.ALIGN_CENTER)
        self.content.Add(self.product_choices_A_sizer, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_3, -1, wx.ALIGN_CENTER)
        self.content.Add(self.product_choices_B_sizer, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_4, -1, wx.ALIGN_CENTER)
        self.content.Add(self.check_control, -1, wx.ALIGN_CENTER)
        self.content.Add(self.bulk_select_panel, -1, wx.ALIGN_CENTER)
        #self.content.Add(buttons, -1, wx.ALIGN_CENTER)

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, self.content])
        
        self.transfer_decals_gui.SetSizer(confirm_sizer)
        self.transfer_decals_gui.Fit()

        list_products(self).start()

        result = self.transfer_decals_gui.ShowModal()
        self.transfer_decals_gui.Destroy()

        routes_to_search = {}
        if result == wx.ID_OK:
            if self.product_choices_A_combo.GetCurrentSelection() == 0 or self.product_choices_B_combo.GetCurrentSelection() == 0: # ignore first item
                self.error_handler(self.lang["transfer_decals_decal_choice_error"], self.lang["transfer_decals_decal_choice_error_title"])
            else:
                a = self.product_choices_A_combo.GetLabel()
                b = self.product_choices_B_combo.GetLabel()

                for item in route_checkboxes:
                    if item.GetValue() == True:
                        routes_to_search[item.GetLabel()] = self.route_details[item.GetLabel()][2]
                        
                if copy_or_transfer.GetLabel() == self.lang["transfer_decals_copy_word"]:
                    copy_or_transfer = "copy"
                    if len(routes_to_search) != 0:
                        self.error_handler(self.lang["transfer_decals_copy_warning"],self.lang["transfer_decals_copy_warning_title"])
                else:
                    copy_or_transfer = "transfer"
                transfer_decals(self, routes_to_search, re.sub(" \([0-9]+ decals\)$","",a), b, copy_or_transfer).start()

        return

    def evt_kml_path(self,event):
        self.selected_kml_path = False
        # ask the user to confirm the route they want to clean up decals for and how they want to clean up
        self.kml_path_gui = wx.Dialog(self, title=self.lang["kml_path_window_title"], size=(800,450), style=wx.CAPTION|wx.RESIZE_BORDER)

        logo1 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo1 = wx.StaticBitmap(self.kml_path_gui, -1, logo1, (10 + logo1.GetWidth(), 5))
        logo2 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo2 = wx.StaticBitmap(self.kml_path_gui, -1, logo2, (10 + logo2.GetWidth(), 5))
        logo3 = wx.Image(self.config["INSTALL_PATH"] + "\\images\\logo.png",wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        logo3= wx.StaticBitmap(self.kml_path_gui, -1, logo3, (10 + logo3.GetWidth(), 5))

        logos = wx.FlexGridSizer(cols=1)
        logos.Add(logo1, -1, wx.ALL, 5)
        logos.Add(logo2, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)
        logos.Add(logo3, -1, wx.LEFT|wx.RIGHT|wx.BOTTOM, 5)

        self.title = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_title"])
        font = wx.Font(12, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        self.title.SetFont(font)

        description = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_desc"], size=(580,-1))
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.NORMAL, False)
        description.SetFont(font)
        description.Wrap(580)

        # load KML file
        stage_1 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_1"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_1.SetFont(font)
        
        kml_path = wx.Button(self.kml_path_gui, -1, self.lang["kml_path_stage_1_button"])
        kml_path.Bind(wx.EVT_BUTTON, self.evt_select_kml_path)
        kml_path.SetToolTip(wx.ToolTip(self.lang["kml_path_stage_1_button_tooltip"]))

        kml_path_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_path_info.Bind(wx.EVT_BUTTON, lambda evt, temp="kml_path_stage_1_button_tooltip": self.evt_info_button(evt, temp))

        kml_path_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_path_input.Add(kml_path, -1, wx.ALIGN_CENTER)
        kml_path_input.Add(kml_path_info, -1, wx.ALIGN_CENTER)

        self.kml_path_show = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_1_show"], size=(580,-1), style=wx.ALIGN_CENTER)

        # decal name
        stage_2 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_2"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_2.SetFont(font)

        self.kml_decal_name  = wx.TextCtrl(self.kml_path_gui, -1, "", size=(200,-1))
        self.kml_decal_name.SetInsertionPoint(0)
        self.kml_decal_name.SetToolTip(wx.ToolTip(self.lang["tooltip_decalname"]))

        kml_decal_name_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_decal_name_info.Bind(wx.EVT_BUTTON, lambda evt, temp="tooltip_decalname": self.evt_info_button(evt, temp))

        kml_decal_name_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_decal_name_input.Add(self.kml_decal_name, -1, wx.ALIGN_CENTER)
        kml_decal_name_input.Add(kml_decal_name_info, -1, wx.ALIGN_CENTER)

        # Area size
        stage_3 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_3"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_3.SetFont(font)

        self.kml_area_options = self.kml_distance_option_generate()

        self.kml_area_choice = wx.Choice(self.kml_path_gui, -1, choices=self.kml_area_options)
        self.kml_area_choice.SetSelection(int(self.form_settings["KML_AREA"]))
        self.kml_area_choice.SetToolTip(wx.ToolTip(self.lang["kml_path_stage_3_tooltip"]))

        kml_area_choice_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_area_choice_info.Bind(wx.EVT_BUTTON, lambda evt, temp="kml_path_stage_3_tooltip": self.evt_info_button(evt, temp))

        kml_area_choice_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_area_choice_input.Add(self.kml_area_choice, -1, wx.ALIGN_CENTER)
        kml_area_choice_input.Add(kml_area_choice_info, -1, wx.ALIGN_CENTER)

        # Distance from Path
        stage_4 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_4"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_4.SetFont(font)

        self.kml_distance_options = self.kml_distance_option_generate()

        self.kml_distance_choice = wx.Choice(self.kml_path_gui, -1, choices=self.kml_distance_options)
        self.kml_distance_choice.SetSelection(int(self.form_settings["KML_DISTANCE"]))
        self.kml_distance_choice.SetToolTip(wx.ToolTip(self.lang["kml_path_stage_4_tooltip"]))

        kml_distance_options_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_distance_options_info.Bind(wx.EVT_BUTTON, lambda evt, temp="kml_path_stage_4_tooltip": self.evt_info_button(evt, temp))

        kml_distance_options_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_distance_options_input.Add(self.kml_distance_choice, -1, wx.ALIGN_CENTER)
        kml_distance_options_input.Add(kml_distance_options_info, -1, wx.ALIGN_CENTER)

        # altitude options primary
        stage_5 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_5"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_5.SetFont(font)
        
        self.kml_altitude_choice_primary = wx.Choice(self.kml_path_gui, -1, choices=self.altitude_options)
        self.kml_altitude_choice_primary.SetSelection(int(self.form_settings["ALTITUDE_KML_PRIMARY"]))
        self.kml_altitude_choice_primary.SetToolTip(wx.ToolTip(self.lang["kml_path_stage_5_tooltip"]))

        kml_altitude_choice_primary_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_altitude_choice_primary_info.Bind(wx.EVT_BUTTON, lambda evt, temp="kml_path_stage_5_tooltip": self.evt_info_button(evt, temp))

        kml_altitude_choice_primary_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_altitude_choice_primary_input.Add(self.kml_altitude_choice_primary, -1, wx.ALIGN_CENTER)
        kml_altitude_choice_primary_input.Add(kml_altitude_choice_primary_info, -1, wx.ALIGN_CENTER)

        # altitude options secondary
        stage_6 = wx.StaticText(self.kml_path_gui, -1, self.lang["kml_path_stage_6"], style=wx.ALIGN_CENTER)
        font = wx.Font(10, wx.NORMAL, wx.NORMAL, wx.BOLD, False)
        stage_6.SetFont(font)

        self.kml_altitude_choice_secondary = wx.Choice(self.kml_path_gui, -1, choices=self.altitude_options)
        self.kml_altitude_choice_secondary.SetSelection(int(self.form_settings["ALTITUDE_KML_SECONDARY"]))
        self.kml_altitude_choice_secondary.SetToolTip(wx.ToolTip(self.lang["kml_path_stage_6_tooltip"]))

        kml_altitude_choice_secondary_info = GenBitmapTextButton(self.kml_path_gui, 1, wx.Bitmap(self.config["INSTALL_PATH"] + "\\images\info_15.png"),size=(21,21),style=wx.ALIGN_RIGHT)
        kml_altitude_choice_secondary_info.Bind(wx.EVT_BUTTON, lambda evt, temp="kml_path_stage_6_tooltip": self.evt_info_button(evt, temp))

        kml_altitude_choice_secondary_input = wx.FlexGridSizer(cols=2, hgap=4, vgap=0)
        kml_altitude_choice_secondary_input.Add(self.kml_altitude_choice_secondary, -1, wx.ALIGN_CENTER)
        kml_altitude_choice_secondary_input.Add(kml_altitude_choice_secondary_info, -1, wx.ALIGN_CENTER)
        
        # set it all out
        buttons = self.kml_path_gui.CreateButtonSizer(wx.OK|wx.CANCEL)

        self.content = wx.FlexGridSizer(cols=1, hgap=4, vgap=2*4)
        self.content.Add(self.title, -1, wx.ALIGN_CENTER)
        self.content.Add(description, -1,wx.RIGHT, 5)
        self.content.Add(stage_1, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_path_input, -1, wx.ALIGN_CENTER)
        self.content.Add(self.kml_path_show, -1, wx.EXPAND )
        self.content.Add(stage_2, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_decal_name_input, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_3, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_area_choice_input, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_4, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_distance_options_input, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_5, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_altitude_choice_primary_input, -1, wx.ALIGN_CENTER)
        self.content.Add(stage_6, -1, wx.ALIGN_CENTER)
        self.content.Add(kml_altitude_choice_secondary_input, -1, wx.ALIGN_CENTER)
        self.content.Add(buttons, -1, wx.ALIGN_CENTER)
        

        confirm_sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=2*4)
        confirm_sizer.AddMany([logos, self.content])

        self.kml_path_gui.SetSizer(confirm_sizer)
        self.kml_path_gui.Fit()

        result = self.kml_path_gui.ShowModal()
        self.kml_path_gui.Destroy()

        if result == wx.ID_OK:
            if self.selected_kml_path == False:
                self.error_handler(self.lang["missing_kml_path"], self.lang["missing_kml_path_title"])
            elif self.validate_decal_name(re.sub("[ ]+"," ",self.kml_decal_name.GetValue().strip())) == False:
                return
            elif not os.path.exists(self.selected_kml_path):
                self.error_handler(self.lang["invalid_kml_path"], self.lang["invalid_kml_path_title"])
            elif int(self.kml_altitude_choice_secondary.GetSelection()) < int(self.kml_altitude_choice_primary.GetSelection()):
                self.error_handler(self.lang["invalid_secondary_altitude"], self.lang["invalid_secondary_altitude_title"])
            else: # got this far so must be ok
                kml_file = self.selected_kml_path
                decal_name = re.sub("[ ]+"," ",self.kml_decal_name.GetValue().strip())
                area = int(self.kml_area_choice.GetSelection())
                
                self.form_settings["KML_AREA"] = area
                
                if area > 10:
                    area = int(float(self.kml_area_options[area].rstrip("km")) * 1000)
                else:
                    area = int(float(self.kml_area_options[area].rstrip("m")))
                    
                distance = int(self.kml_distance_choice.GetSelection())
                self.form_settings["KML_DISTANCE"] = distance
                
                if distance > 10:
                    distance = int(float(self.kml_distance_options[distance].rstrip("km")) * 1000)
                else:
                    distance = int(float(self.kml_distance_options[distance].rstrip("m")))

                
                    
                primary_alt_index = int(self.kml_altitude_choice_primary.GetSelection())
                self.form_settings["ALTITUDE_KML_PRIMARY"] = primary_alt_index
                
                secondary_alt_index = int(self.kml_altitude_choice_secondary.GetSelection())
                self.form_settings["ALTITUDE_KML_SECONDARY"] = secondary_alt_index
                self.save_form()
                
                self.cancel_clicked = False
                kml_marker_parse(self, kml_file, decal_name, area, distance, primary_alt_index, secondary_alt_index).start()

        return

    def evt_select_kml_path(self,event):
        dialog = wx.FileDialog ( None, message = self.lang["kml_path_stage_1_button_tooltip"],
                                 style = wx.FD_OPEN,
                                 defaultDir=self.form_settings["KML_LAST_DIR"],
                                 wildcard="*.kml")

        if dialog.ShowModal() == wx.ID_OK:   
            # User has selected something, get the path, set the window's title to the path   
            self.selected_kml_path = dialog.GetPath()
            self.kml_path_show.SetLabel(self.lang["kml_path_stage_1_show_selected"].replace("~~file~~",dialog.GetFilename()))
            self.content.Layout()
            self.form_settings["KML_LAST_DIR"] = dialog.GetDirectory()
            self.save_form()
            return True
            
        else:
            dialog.Destroy()
            return False


    def evt_validate_decal_name(self,decal_name):
        if re.match("^[\w\s\[\]\(\)\{\}#]+$",decal_name) == None: # make sure valid string
            message = self.lang["message_baddecalname"]
            title = self.lang["message_baddecalname_title"]
            self.error_handler(message, title)
            return False

        if len(decal_name) > 20:
            message = self.lang["message_toolongdecalname"]
            title = self.lang["message_toolongdecalname_title"]
            self.error_handler(message, title)
            return False
        return True

    def altitude_option_generate(self):
        altitude_options = list()
        i = 25
        while i <= int(self.config["MAX_ALTITUDE"]):
            if i > 1000:
                altitude_options.append(str(i/1000.0).replace(".0","") + "km")
            else:
                altitude_options.append(str(i)+ "m")
            if i < 250: # 10
                i += 25
            elif i < 500: # 5
                i += 50
            elif i < 5000: # 45
                i += 100
            elif i < 10000: # 10
                i += 500
            elif i < 20000: # 10
                i += 1000
            elif i < 30000: # 10
                i += 2000
            elif i < 50000: # 10
                i += 5000
            elif i < 100000: # 10
                i += 10000
            else:
                i += 25000

        return altitude_options

    def box_option_generate(self):
        box_options = list()
        i = 100
        while i <= int(self.config["MAX_BOX"]):
            if i > 1024:
                box_options.append(str(i/1000.0).replace(".0","") + "km")
            else:
                box_options.append(str(i)+ "m")
            if i < 1000:
                i += 100
            elif i == 1000:
                i += 24
            elif i == 1024:
                i += 226
            elif i < 2500:
                i += 250
            elif i < 5000:
                i += 500
            else:
                i += 1000

        return box_options

    def kml_distance_option_generate(self):
        kml_options = list()
        i = 100
        while i <= int(self.config["MAX_KML_DISTANCE"]):
            if i > 1024:
                kml_options.append(str(i/1000.0).replace(".0","") + "km")
            else:
                kml_options.append(str(i)+ "m")
            if i < 1000:
                i += 100
            elif i == 1000:
                i += 24
            elif i == 1024:
                i += 226
            elif i < 2500:
                i += 250
            elif i < 5000:
                i += 500
            else:
                i += 1000

        return kml_options

    def get_language_list(self):
        
        lang_files = os.listdir(self.config["INSTALL_PATH"] + "\\lang\\")
        self.language_options = {}
        self.language_options_code = {}

        # get a list of the lang files
        confirmed_langs = list()
        for lang_file in lang_files:
            lang_file_parts = os.path.splitext(lang_file) # split filename into name + extension
            
            if lang_file_parts[1] == ".lang": # make sure is a bin file
                confirmed_langs.append(lang_file)
        i = 10000
        for lang_file in confirmed_langs:
            lang_file_parts = os.path.splitext(lang_file) # split filename into name + extension

            # open lang file and get first line
            f = codecs.open(self.config["INSTALL_PATH"] + "\\lang\\" + lang_file, encoding="UTF-8", mode="r")
            first_line = f.readline().lstrip(unicode( codecs.BOM_UTF8, "utf8" ))
            breaker = first_line.find('=')
            # skip if line does not contain an equals sign
            if breaker <= 0:
                continue
            name = first_line[1:breaker].strip()
            change_lang = first_line[breaker+1:len(first_line)].strip()

            self.language_options[name] = (i,name,change_lang,lang_file_parts[0])
            self.language_options_code[name] = lang_file_parts[0]
            i = i + 1


    def construct_language_menu(self):                   
        for key in sorted(self.language_options.iterkeys(),key=lambda x: x.lower()):
            lang_file_data = self.language_options[key]
            
            self.language.Append(lang_file_data[0], lang_file_data[1],lang_file_data[2],wx.ITEM_RADIO)
            wx.EVT_MENU(self, lang_file_data[0], self.evt_change_language)
            if self.config["LANGUAGE"] == lang_file_data[3]:
                self.language.Check(lang_file_data[0],True)

    def get_auto_grab_delete_options(self):
        delete_sets = list()
        for key in sorted(self.marker_pairs.iterkeys(),key=lambda x: x.lower()):
            if "AUTO_SET_NAME" in self.marker_pairs[key] and self.marker_pairs[key]["AUTO_SET_NAME"] not in delete_sets:
                delete_sets.append(self.marker_pairs[key]["AUTO_SET_NAME"])

        delete_sets.sort()
        i = 20000
        for item in self.auto_delete.GetMenuItems():
            self.auto_delete.Delete(item.GetId())
            
        for item in delete_sets:
            self.auto_delete.Append(i, item, item)
            wx.EVT_MENU(self, i, lambda evt, temp=item: self.evt_reset_grab_markers_auto(evt, temp))
            i = i + 1



# Frame dimensions
wX = 510
wY = 725

# border width
bW = 20
        

frame = main_window(None, -1, "RWDecal tool for RailWorks/RailSimulator by Nobkins")
frame.Show(True)
_icon = wx.Icon(INSTALL_PATH + "\\rwdecal.ico", wx.BITMAP_TYPE_ICO)
frame.SetIcon(_icon)

app.MainLoop()

sys.exit()
